package com.lifeprediction.widget

import android.content.Context

/**
 * The widget background is no longer a user-configurable color/texture —
 * it's one of 11 real "aerial view of a medieval gemstone mining village"
 * illustrations (supplied images, not generated art), replaced by index:
 *   - every carousel scroll (left/right arrow tap) on ANY placed widget
 *     instance, and
 *   - every time the gem popup (DescriptionActivity) is opened.
 *
 * Deliberately NOT advanced on the periodic/scheduled tick or the manual
 * refresh-button tap — those still only recompute colors, same as before.
 *
 * A single globally-stored index (not per-appWidgetId) is used so that if
 * multiple widget instances are placed, they all show the same image at
 * the same time, and the popup matches whichever one the widget is
 * currently showing.
 */
object VillageBackgroundPrefs {
    private const val PREFS = "village_background_prefs"
    private const val KEY_INDEX = "current_index"

    const val COUNT = 11

    private val drawableIds: List<Int> = listOf(
        R.drawable.bg_village_01, R.drawable.bg_village_02, R.drawable.bg_village_03,
        R.drawable.bg_village_04, R.drawable.bg_village_05, R.drawable.bg_village_06,
        R.drawable.bg_village_07, R.drawable.bg_village_08, R.drawable.bg_village_09,
        R.drawable.bg_village_10, R.drawable.bg_village_11
    )

    /** The currently-active image's drawable resource, without changing it. */
    fun currentDrawableResId(context: Context): Int {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val index = prefs.getInt(KEY_INDEX, 0).coerceIn(0, COUNT - 1)
        return drawableIds[index]
    }

    /**
     * Picks a new random image (never immediately repeating the current
     * one, so a rotation always visibly changes something) and persists
     * it as the new current index. Returns the new drawable resource, so
     * a caller that needs it immediately (e.g. to build RemoteViews right
     * after advancing) doesn't have to make a second call.
     */
    fun advance(context: Context): Int {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val current = prefs.getInt(KEY_INDEX, 0).coerceIn(0, COUNT - 1)
        val next = if (COUNT <= 1) 0 else {
            var candidate = (0 until COUNT).random()
            while (candidate == current) candidate = (0 until COUNT).random()
            candidate
        }
        prefs.edit().putInt(KEY_INDEX, next).apply()
        return drawableIds[next]
    }
}
