package com.lifeprediction.widget

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.time.format.DateTimeFormatter

/**
 * The Share button's actual work. A plain PendingIntent straight to
 * ACTION_SEND (like the old website-link share) can't do this, because
 * sharing an *image* means something has to draw that image first — a
 * RemoteViews widget can't be screenshotted directly, since it's inflated
 * and rendered in the launcher's process, not this app's, so there's
 * nothing here to literally capture. Instead this receiver redraws the
 * reveal slide's look from scratch onto a standalone Bitmap via Canvas,
 * matching its colors/layout, then shares that.
 *
 * exported="false" — same reasoning as TickReceiver/CarouselReceiver, only
 * reachable via this app's own explicit PendingIntent.
 */
class ShareReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_SHARE = "com.lifeprediction.widget.gems.ACTION_SHARE"

        private const val SIZE = 640

        /**
         * Recreates the reveal-slide "card" — background, gold border, the
         * multicolor gem mark (same 5-facet path data as
         * ic_gem_multicolor.xml, redrawn here in Canvas since a static
         * drawable resource can't be pulled apart into a standalone Bitmap
         * without inflating a whole View hierarchy), the big owned-stone
         * count, and the app wordmark. Deliberately NOT using the
         * downloadable Cormorant Garamond font here — resolving a
         * downloadable font synchronously inside a BroadcastReceiver risks
         * a blocking network fetch on first use; Typeface.DEFAULT_BOLD is
         * an intentional, safe fallback for the shared image specifically.
         */
        private fun renderRevealBitmap(count: Int): Bitmap {
            val bmp = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)

            // Card background gradient — same stops as bg_celestial_card.xml.
            val cardRect = RectF(0f, 0f, SIZE.toFloat(), SIZE.toFloat())
            val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = android.graphics.LinearGradient(
                    0f, 0f, 0f, SIZE.toFloat(),
                    intArrayOf(Color.parseColor("#1B1340"), Color.parseColor("#150F30"), Color.parseColor("#0D0920")),
                    floatArrayOf(0f, 0.5f, 1f),
                    android.graphics.Shader.TileMode.CLAMP
                )
            }
            canvas.drawRoundRect(cardRect, 48f, 48f, bgPaint)

            // Gold border ring — same color as the widget's own border.
            val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = 6f
                color = Color.parseColor("#D4AF37")
            }
            canvas.drawRoundRect(RectF(3f, 3f, SIZE - 3f, SIZE - 3f), 46f, 46f, borderPaint)

            // Multicolor gem mark — same facet layout as ic_gem_multicolor.xml
            // (24x24 viewport), scaled up and centered above the number.
            val iconSize = 130f
            val iconLeft = SIZE / 2f - iconSize / 2f - 60f
            val iconTop = SIZE / 2f - iconSize / 2f - 40f
            drawGemIcon(canvas, iconLeft, iconTop, iconSize)

            // Big bold count number, to the right of the icon.
            val numberPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#F5EFE0")
                textSize = 150f
                typeface = Typeface.DEFAULT_BOLD
                textAlign = Paint.Align.LEFT
            }
            val numberText = count.toString()
            val numberX = iconLeft + iconSize + 24f
            val fm = numberPaint.fontMetrics
            val numberBaseline = iconTop + iconSize / 2f - (fm.ascent + fm.descent) / 2f
            canvas.drawText(numberText, numberX, numberBaseline, numberPaint)

            // Wordmark, centered below the icon+number row.
            val wordmarkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#C9BFA0")
                textSize = 30f
                letterSpacing = 0.12f
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText(
                "PLUTO PHASES GEMS", SIZE / 2f, iconTop + iconSize + 90f, wordmarkPaint
            )

            return bmp
        }

        /** Same facet coordinates as ic_gem_multicolor.xml, scaled from its
         *  24x24 viewport to `size` px and translated to (left, top). */
        private fun drawGemIcon(canvas: Canvas, left: Float, top: Float, size: Float) {
            val scale = size / 24f
            fun pt(x: Float, y: Float) = floatArrayOf(left + x * scale, top + y * scale)

            fun facet(color: String, vararg points: FloatArray) {
                val path = Path()
                path.moveTo(points[0][0], points[0][1])
                for (i in 1 until points.size) path.lineTo(points[i][0], points[i][1])
                path.close()
                canvas.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    this.color = Color.parseColor(color)
                    style = Paint.Style.FILL
                })
            }

            facet("#EAF6FF", pt(7f, 4f), pt(17f, 4f), pt(14f, 7f), pt(10f, 7f))      // table (diamond)
            facet("#9B6FC4", pt(7f, 4f), pt(10f, 7f), pt(12f, 10f), pt(2f, 10f))     // crown left (amethyst)
            facet("#4A83D4", pt(17f, 4f), pt(14f, 7f), pt(12f, 10f), pt(22f, 10f))   // crown right (sapphire)
            facet("#1F9D66", pt(2f, 10f), pt(12f, 10f), pt(12f, 22f))                // pavilion left (emerald)
            facet("#C4384F", pt(22f, 10f), pt(12f, 10f), pt(12f, 22f))               // pavilion right (ruby)

            val outline = Path().apply {
                moveTo(pt(7f, 4f)[0], pt(7f, 4f)[1])
                lineTo(pt(17f, 4f)[0], pt(17f, 4f)[1])
                lineTo(pt(22f, 10f)[0], pt(22f, 10f)[1])
                lineTo(pt(12f, 22f)[0], pt(12f, 22f)[1])
                lineTo(pt(2f, 10f)[0], pt(2f, 10f)[1])
                close()
                moveTo(pt(10f, 7f)[0], pt(10f, 7f)[1]); lineTo(pt(14f, 7f)[0], pt(14f, 7f)[1])
                moveTo(pt(2f, 10f)[0], pt(2f, 10f)[1]); lineTo(pt(22f, 10f)[0], pt(22f, 10f)[1])
                moveTo(pt(12f, 10f)[0], pt(12f, 10f)[1]); lineTo(pt(12f, 22f)[0], pt(12f, 22f)[1])
            }
            canvas.drawPath(outline, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#150F28")
                style = Paint.Style.STROKE
                strokeWidth = scale * 0.5f
                strokeJoin = Paint.Join.ROUND
            })
        }

        /**
         * "I have N gems on {date} at {time}!" followed by one line per gem
         * type actually owned today (count > 0 only — a shareable brag post
         * shouldn't list the ones you didn't get), then the app name and
         * website link. Per-gem lines reuse ZodiacWidgetProvider's own
         * eventPhraseFor so the wording matches the interpretation screen
         * exactly, just lowercased per this feature's spec.
         */
        private fun buildCaption(context: Context, snapshot: WidgetSnapshot): String {
            val stoneCount = GemLedger.activeStones(snapshot).size
            val dateStr = snapshot.date.format(DateTimeFormatter.ofPattern("MMMM d, yyyy"))
            val timeStr = snapshot.now.format(DateTimeFormatter.ofPattern("h:mm a"))

            val lines = mutableListOf("I have $stoneCount gems on $dateStr at $timeStr!")
            for (entry in GemLedger.entries(snapshot)) {
                if (entry.count == 0) continue
                val name = entry.gem.countedName(entry.count).lowercase()
                val event = ZodiacWidgetProvider.eventPhraseFor(entry.gem, snapshot)
                lines.add("${entry.count} $name $event")
            }
            lines.add("")
            lines.add(context.getString(R.string.app_name))
            lines.add(context.getString(R.string.website_url))
            return lines.joinToString("\n")
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION_SHARE) return

        val snapshot = LuckCalculator.buildSnapshot(context)
        val stoneCount = GemLedger.activeStones(snapshot).size

        val bmp = renderRevealBitmap(stoneCount)

        val shareDir = File(context.cacheDir, "shared").apply { mkdirs() }
        val file = File(shareDir, "reveal_share.png")
        FileOutputStream(file).use { out -> bmp.compress(Bitmap.CompressFormat.PNG, 100, out) }

        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)

        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, buildCaption(context, snapshot))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(sendIntent, null).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    }
}
