package com.lifeprediction.widget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.view.View
import android.widget.RemoteViews
import java.time.LocalDateTime
import java.time.ZoneId

/**
 * Base widget logic, shared by three separate manifest-declared receivers —
 * ZodiacWidgetProvider1x1/2x1/1x2 — each a trivial subclass with no code of
 * its own, existing purely so the widget picker shows three distinct, fixed-
 * size entries ("like other Android apps") instead of one resizable widget.
 * 1x1 and 2x1 share one layout; 1x2 uses a separate layout — see
 * layoutResFor().
 *
 * The widget's own "refresh now" tick (ACTION_TICK) and carousel arrows
 * (ACTION_SCROLL) are deliberately NOT handled here or in the manifest
 * intent-filter for these three receivers — they live on the separate,
 * non-exported TickReceiver/CarouselReceiver, since these three must stay
 * exported="true" for the system to deliver APPWIDGET_UPDATE, and an
 * exported receiver can always be reached by an explicit intent from any
 * other app regardless of its intent-filter contents. See TickReceiver's doc
 * comment for the full reasoning.
 *
 * Colors are refreshed at the *exact second* they should change, not on a
 * fixed timer: every wake-up computes the earliest of (a) the next top-of-hour
 * (covers the Time box, and Date/Day/Month/Year at midnight since midnight is
 * also an hour boundary), (b) the next Sun-sign crossing, and (c) the next
 * Moon-sign crossing — then schedules a single exact alarm for whichever is
 * soonest, and repeats. Each wake is a handful of milliseconds of work, and
 * there are at most a few dozen of these a day (an hourly one, plus the rare
 * Sun/Moon sign changes), so this stays cheap even though it's precise.
 */
open class ZodiacWidgetProvider : AppWidgetProvider() {

    companion object {

        /** The three concrete, manifest-declared widget types. */
        private val allProviderClasses = listOf(
            ZodiacWidgetProvider1x1::class.java,
            ZodiacWidgetProvider2x1::class.java,
            ZodiacWidgetProvider1x2::class.java
        )

        /** 1x2 is a single column wide, so it uses the stacked layout;
         *  1x1 and 2x1 share the side-by-side layout. */
        private fun layoutResFor(providerClass: Class<out ZodiacWidgetProvider>): Int =
            if (providerClass == ZodiacWidgetProvider1x2::class.java) R.layout.widget_zodiac_tall
            else R.layout.widget_zodiac

        /** Page 0 is always the "You have XX gems!" reveal slide; pages 1+
         *  are the 3-physical-stone-slots-per-page carousel (a page's worth
         *  can be anywhere from 1 to 3 gem *types* depending on how many are
         *  doubled up (count 2), since this pages the flat stone list, not
         *  the element list). With zero stones there are no stone pages at
         *  all — just the reveal slide showing "You have 0 gems!" — so this
         *  is always >= 1, meaning page index 0 is always valid. */
        fun pageCountFor(stones: List<Gem>): Int = 1 + (stones.size + 2) / 3

        /** Short event phrase (with its own preposition baked in) for the
         *  interpretation screen's hero line — "You got {n} {gem} {this}." —
         *  and no zodiac glyphs anywhere, per design. */
        /** Also called from ShareReceiver for the share-caption text, so
         *  the caption's per-gem lines use the exact same wording as the
         *  interpretation screen's hero line — internal rather than
         *  private for that reason. */
        internal fun eventPhraseFor(gem: Gem, snapshot: WidgetSnapshot): String {
            fun monthName(month: java.time.Month) = month.name.lowercase().replaceFirstChar { it.uppercase() }
            return when (gem) {
                Gem.QUARTZ -> "for hour ${snapshot.hour12}"
                Gem.AMETHYST -> "for day ${snapshot.date.dayOfMonth}"
                Gem.TOPAZ -> "for ${snapshot.transitingMoonSign} Moon"
                Gem.JADE -> "for ${snapshot.transitingSunSign} Sun"
                Gem.SAPPHIRE -> "for ${monthName(snapshot.date.month)} month"
                Gem.EMERALD -> "for the date ${snapshot.date.dayOfMonth} ${monthName(snapshot.date.month)}, ${snapshot.date.year}"
                Gem.RUBY -> "for the year ${snapshot.date.year}"
                Gem.DIAMOND -> "for the ${snapshot.phaseEra.label}"
            }
        }

        /** Builds the interpretation screen's PendingIntent, carrying all 8
         *  gems' levels and event phrases (joined into two extras — Intent
         *  extras can't hold a Map, and this stays far simpler than a custom
         *  Parcelable for 8 fixed, known values) plus which tab to open
         *  first. requestCode is per-appWidgetId (see applyCarousel) so
         *  multiple placed widget instances, each possibly on a different
         *  page, don't collide and overwrite each other's PendingIntent. */
        private fun descriptionIntent(context: Context, initialGem: Gem, snapshot: WidgetSnapshot, requestCode: Int): PendingIntent {
            val levels = Gem.values().joinToString(",") { GemLedger.levelFor(it, snapshot).name }
            val events = Gem.values().joinToString("|||") { eventPhraseFor(it, snapshot) }
            val intent = Intent(context, DescriptionActivity::class.java).apply {
                putExtra(DescriptionActivity.EXTRA_INITIAL_GEM, initialGem.name)
                putExtra(DescriptionActivity.EXTRA_LEVELS, levels)
                putExtra(DescriptionActivity.EXTRA_EVENTS, events)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            return PendingIntent.getActivity(
                context, requestCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        private val gemSlotIds = listOf(R.id.widget_gem_slot1, R.id.widget_gem_slot2, R.id.widget_gem_slot3)

        /**
         * Populates the flexible carousel region for one specific widget
         * instance. Page 0 is always the "You have XX gems!" reveal slide;
         * pages 1+ are the 3-stone-slot pages. The reveal slide and the
         * stone-slots row are full-size siblings in the same FrameLayout —
         * never both visible at once.
         *
         * requestCode base is appWidgetId * 100 (+1/2 for left/right arrows,
         * +3 for the reveal-slide tap, +4/5/6 for the 3 individual stone
         * taps), keeping every instance's PendingIntents distinct —
         * necessary now that different placed widgets can show different
         * pages with different tap targets. appWidgetIds are always small
         * positive ints, so this can't collide with the fixed global codes
         * (5/6/7) used for website/share/refresh below.
         */
        private fun applyCarousel(views: RemoteViews, context: Context, appWidgetId: Int, snapshot: WidgetSnapshot) {
            val stones = GemLedger.activeStones(snapshot)
            val pageCount = pageCountFor(stones)
            val storedPage = CarouselPrefs.getPage(context, appWidgetId)
            val page = storedPage.coerceIn(0, pageCount - 1)
            if (page != storedPage) CarouselPrefs.setPage(context, appWidgetId, page)

            val hasMultiplePages = pageCount > 1
            views.setViewVisibility(R.id.widget_gem_left, if (hasMultiplePages) View.VISIBLE else View.INVISIBLE)
            views.setViewVisibility(R.id.widget_gem_right, if (hasMultiplePages) View.VISIBLE else View.INVISIBLE)
            if (hasMultiplePages) {
                views.setOnClickPendingIntent(R.id.widget_gem_left, scrollIntent(context, appWidgetId, -1))
                views.setOnClickPendingIntent(R.id.widget_gem_right, scrollIntent(context, appWidgetId, +1))
            }

            if (page == 0) {
                views.setViewVisibility(R.id.widget_gem_reveal, View.VISIBLE)
                views.setViewVisibility(R.id.widget_gem_slots_row, View.GONE)
                views.setTextViewText(R.id.widget_gem_reveal_count, stones.size.toString())

                // Defaults to the first owned stone (common -> rare order,
                // same as the carousel itself), or Quartz if every reading
                // is Dim today — same fallback DescriptionActivity already
                // uses for a missing/unparseable extra.
                val initialGem = stones.firstOrNull() ?: Gem.QUARTZ
                views.setOnClickPendingIntent(
                    R.id.widget_gem_reveal, descriptionIntent(context, initialGem, snapshot, appWidgetId * 100 + 3)
                )
                return
            }

            views.setViewVisibility(R.id.widget_gem_reveal, View.GONE)
            views.setViewVisibility(R.id.widget_gem_slots_row, View.VISIBLE)

            val stonePage = page - 1
            val pageStones = stones.drop(stonePage * 3).take(3)
            for (i in gemSlotIds.indices) {
                val slotId = gemSlotIds[i]
                if (i < pageStones.size) {
                    views.setViewVisibility(slotId, View.VISIBLE)
                    views.setImageViewResource(slotId, pageStones[i].illustrationRes)
                    // Each stone slot now picks its own tab on the
                    // interpretation screen (3 separate tap targets),
                    // rather than the whole row sharing one — a deliberate
                    // reversal of the earlier "gem appearance over
                    // fine-grained tap targets" call.
                    views.setOnClickPendingIntent(
                        slotId, descriptionIntent(context, pageStones[i], snapshot, appWidgetId * 100 + 4 + i)
                    )
                } else {
                    // INVISIBLE, not GONE: keeps this slot's width share so
                    // the other stone(s) on a partial last page don't
                    // stretch to fill the gap.
                    views.setViewVisibility(slotId, View.INVISIBLE)
                }
            }
        }

        private fun scrollIntent(context: Context, appWidgetId: Int, direction: Int): PendingIntent {
            val intent = Intent(CarouselReceiver.ACTION_SCROLL, null, context, CarouselReceiver::class.java).apply {
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
                putExtra(CarouselReceiver.EXTRA_DIRECTION, direction)
            }
            val requestCode = appWidgetId * 100 + (if (direction < 0) 1 else 2)
            return PendingIntent.getBroadcast(
                context, requestCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        fun buildRemoteViews(context: Context, providerClass: Class<out ZodiacWidgetProvider>, appWidgetId: Int): RemoteViews {
            val views = RemoteViews(context.packageName, layoutResFor(providerClass))
            val snapshot = LuckCalculator.buildSnapshot(context)

            // Background: current rotating "aerial mining village" image
            // (VillageBackgroundPrefs) — replaces the old user-chosen flat
            // color/texture. Rotated by CarouselReceiver (page scroll) and
            // DescriptionActivity (popup open), NOT by this periodic/manual
            // tick path, so setInt below just reads the current index
            // rather than advancing it.
            views.setInt(R.id.widget_root, "setBackgroundResource", VillageBackgroundPrefs.currentDrawableResId(context))

            // BORDER — user's chosen color from Settings (default: gold),
            // restored as a Settings option. bg_widget_border is a plain
            // white-ish ring shape, so setColorFilter tints it.
            views.setInt(R.id.widget_border, "setColorFilter", context.getColor(BorderPrefs.get(context).colorRes))

            // TOTAL VALUE — sum of all 8 gems' (value x count) for this snapshot.
            val total = GemLedger.totalValue(snapshot)
            views.setTextViewText(R.id.widget_total_text, "\u25C6 $" + "%,d".format(total))

            // GEM COUNT — total owned stone count today (not a dollar
            // value), shown in the small pill between the clock and the
            // Total Value pill.
            val stoneCount = GemLedger.activeStones(snapshot).size
            views.setTextViewText(R.id.widget_gem_count_text, stoneCount.toString())

            applyCarousel(views, context, appWidgetId, snapshot)

            // Website -> opens the browser (no INTERNET permission needed here;
            // the browser app does the actual network fetch, not us)
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse(context.getString(R.string.website_url)))
            val webPending = PendingIntent.getActivity(
                context, 5, webIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_website, webPending)

            // Share -> ShareReceiver draws the reveal-slide image and
            // launches the system share sheet with it + the gem caption.
            // getBroadcast, not getActivity: unlike the old plain-text
            // share, this needs actual code to run first (drawing the
            // bitmap, building the caption) before a share sheet can even
            // be launched — a PendingIntent straight to ACTION_SEND can't
            // do that. Same exported=false receiver pattern as the arrows.
            val shareIntent = Intent(context, ShareReceiver::class.java).apply {
                action = ShareReceiver.ACTION_SHARE
            }
            val sharePending = PendingIntent.getBroadcast(
                context, 7, shareIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_share, sharePending)

            // Refresh button -> broadcasts ACTION_TICK to TickReceiver, the
            // same non-exported component the scheduled alarm targets (see
            // TickReceiver's doc comment for why this isn't sent to the
            // widget provider classes themselves). Explicitly targeted by
            // component so delivery doesn't depend on any intent-filter
            // matching. EXTRA_MANUAL flags this as a user tap so
            // TickReceiver can show a one-off confirmation, since colors
            // only visibly change at an actual hour/sign boundary and a
            // silent recompute can otherwise look like the button did
            // nothing. (A single global request code is fine here — unlike
            // the carousel, refresh has no per-instance state.)
            val refreshIntent = Intent(TickReceiver.ACTION_TICK, null, context, TickReceiver::class.java)
                .putExtra(TickReceiver.EXTRA_MANUAL, true)
            val refreshPending = PendingIntent.getBroadcast(
                context, 6, refreshIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_refresh, refreshPending)

            return views
        }

        /**
         * Rebuilds and pushes fresh RemoteViews to every placed instance of
         * all three widget types (1x1, 2x1, 1x2) — a user could have any
         * combination of them placed at once, and each instance is built
         * individually now (not one shared RemoteViews per type) since each
         * can be on its own carousel page.
         */
        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            for (cls in allProviderClasses) {
                for (id in manager.getAppWidgetIds(ComponentName(context, cls))) {
                    manager.updateAppWidget(id, buildRemoteViews(context, cls, id))
                }
            }
        }

        /** Rebuilds just one widget instance — used by CarouselReceiver after
         *  a scroll, so paging one placed widget doesn't touch any others.
         *  AppWidgetManager doesn't expose "which of my 3 classes is this id"
         *  directly, but getAppWidgetInfo(id).provider gives the manifest
         *  component that owns it, which is matched against the 3 known
         *  classes below. */
        fun updateInstance(context: Context, appWidgetId: Int) {
            val manager = AppWidgetManager.getInstance(context)
            val info = manager.getAppWidgetInfo(appWidgetId) ?: return
            val cls = allProviderClasses.firstOrNull { it.name == info.provider.className } ?: return
            manager.updateAppWidget(appWidgetId, buildRemoteViews(context, cls, appWidgetId))
        }

        /**
         * Schedules a single exact alarm for the earliest moment any displayed
         * color would actually change: the next top-of-hour *in the device's
         * local time zone* (not UTC — the hour/date used for coloring comes
         * from the device's local clock, so scheduling by UTC hour boundaries
         * would fire up to ~30-60 minutes off for any zone with a non-whole-hour
         * UTC offset, e.g. India at UTC+5:30), or, if sooner, the exact instant
         * the Sun or Moon crosses into a new sign today (that part of the
         * ephemeris math is inherently UTC-based, which is fine — it's
         * converted to an absolute instant either way before comparing).
         *
         * The alarm targets TickReceiver explicitly (see its doc comment) —
         * a single component regardless of which of the three widget types
         * is actually placed, since TickReceiver.onReceive calls
         * ZodiacWidgetProvider.updateAll(), which itself loops over all
         * three and only pushes updates to the ones with placed instances.
         */
        fun scheduleNextTick(context: Context) {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return

            val localZone = ZoneId.systemDefault()
            val nowLocal = LocalDateTime.now(localZone)
            val nextLocalHour = nowLocal.withMinute(0).withSecond(0).withNano(0).plusHours(1)
            val nextHourMillis = nextLocalHour.atZone(localZone).toInstant().toEpochMilli()

            val nowUtc = LocalDateTime.now(ZoneId.of("UTC"))
            val sunCrossingMillis = EphemerisRepository.nextSignCrossing(context, nowUtc) { it.sunDegrees }
                ?.atZone(ZoneId.of("UTC"))?.toInstant()?.toEpochMilli()
            val moonCrossingMillis = EphemerisRepository.nextSignCrossing(context, nowUtc) { it.moonDegrees }
                ?.atZone(ZoneId.of("UTC"))?.toInstant()?.toEpochMilli()

            // nextHourMillis is always present, so this list is never empty —
            // minOrNull()!! is used instead of the plain min() extension,
            // which has had inconsistent availability across Kotlin stdlib
            // versions (deprecated as an error in some releases).
            val triggerAt = listOfNotNull(nextHourMillis, sunCrossingMillis, moonCrossingMillis).minOrNull()!!

            val intent = Intent(TickReceiver.ACTION_TICK, null, context, TickReceiver::class.java)
            val pending = PendingIntent.getBroadcast(
                context, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val canScheduleExact = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                alarmManager.canScheduleExactAlarms()
            } else {
                true
            }

            if (canScheduleExact) {
                runCatching {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC, triggerAt, pending)
                }.onFailure {
                    alarmManager.set(AlarmManager.RTC, triggerAt, pending)
                }
            } else {
                // User hasn't granted the "Alarms & reminders" special access on
                // Android 13+. Fall back to an inexact wake — the widget still
                // refreshes, just without to-the-second precision, and it'll
                // catch up fully once the permission is granted (SettingsActivity
                // offers a shortcut to do that).
                alarmManager.set(AlarmManager.RTC, triggerAt, pending)
            }
        }
    }

    /**
     * appWidgetIds.forEach { updateAppWidget(...) } used to run this
     * synchronously on the main thread — fine on every *subsequent* update,
     * but the very first onUpdate() after a fresh install is also the very
     * first time EphemerisRepository.load() runs, which synchronously
     * parses a ~45,000-row bundled TSV. On a cold app process right after
     * install (cold classes, cold disk cache, no warm JIT), that parse can
     * take long enough that the widget host times out waiting for this
     * onUpdate to return and falls back to a blank/placeholder widget —
     * which then never gets nudged again until the next onUpdate a re-add
     * triggers (by which point the ephemeris cache is already warm from
     * the earlier attempt, so it succeeds instantly and looks "fixed").
     *
     * goAsync() defers the system's deadline: it lets onUpdate return
     * immediately (so the host never waits on the parse) while the actual
     * work — including that first-ever parse — runs on a background
     * thread, with finish() called once the real RemoteViews have been
     * pushed. This doesn't touch how EphemerisRepository itself works;
     * it just stops the app's first-run cost from ever sitting in the
     * widget host's synchronous update path.
     */
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val pendingResult = goAsync()
        Thread {
            try {
                appWidgetIds.forEach { id ->
                    appWidgetManager.updateAppWidget(id, buildRemoteViews(context, javaClass, id))
                }
                scheduleNextTick(context)
            } finally {
                pendingResult.finish()
            }
        }.start()
    }

    override fun onEnabled(context: Context) {
        scheduleNextTick(context)
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        appWidgetIds.forEach { id -> CarouselPrefs.clear(context, id) }
    }

    // No onReceive override needed anymore — ACTION_TICK/ACTION_SCROLL now
    // live entirely on TickReceiver/CarouselReceiver (see their doc
    // comments), so this class only ever needs AppWidgetProvider's own
    // default handling of APPWIDGET_UPDATE/ENABLED/DELETED/etc., which the
    // overrides above already hook into normally.
}
