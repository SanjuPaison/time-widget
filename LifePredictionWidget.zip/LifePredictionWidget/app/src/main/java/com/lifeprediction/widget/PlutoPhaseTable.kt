package com.lifeprediction.widget

data class PlutoPhaseEra(val startYear: Int, val endYear: Int, val signIndex: Int) {
    val signName: String get() = ZODIAC_SIGNS[signIndex]
    val label: String get() = "$signName Phase ($startYear-$endYear)"
}

/**
 * The Pluto Phases system (Sanju Paison, 2015), reproduced verbatim from
 * PlutoPhaseTable_source.txt: the journey of "transiting Pluto minus 135
 * degrees" through the signs in ~15-30 year eras. The Book of Luck's
 * lucky/unlucky tables are indexed 1:1 against these eras (1868-1898 onward).
 */
object PlutoPhaseTable {

    val eras: List<PlutoPhaseEra> = listOf(
        PlutoPhaseEra(1838, 1867, signIndexOf("Sagittarius")),
        PlutoPhaseEra(1868, 1898, signIndexOf("Capricorn")),
        PlutoPhaseEra(1899, 1927, signIndexOf("Aquarius")),
        PlutoPhaseEra(1928, 1948, signIndexOf("Pisces")),
        PlutoPhaseEra(1949, 1964, signIndexOf("Aries")),
        PlutoPhaseEra(1965, 1978, signIndexOf("Taurus")),
        PlutoPhaseEra(1979, 1989, signIndexOf("Gemini")),
        PlutoPhaseEra(1990, 2002, signIndexOf("Cancer")),
        PlutoPhaseEra(2003, 2016, signIndexOf("Leo")),
        PlutoPhaseEra(2017, 2032, signIndexOf("Virgo")),
        PlutoPhaseEra(2033, 2054, signIndexOf("Libra")),
        PlutoPhaseEra(2055, 2082, signIndexOf("Scorpio")),
        PlutoPhaseEra(2083, 2111, signIndexOf("Sagittarius"))
    )

    /** Index into [eras] for the era containing the given year, clamped to the table range. */
    fun eraIndexForYear(year: Int): Int {
        val idx = eras.indexOfFirst { year in it.startYear..it.endYear }
        return when {
            idx >= 0 -> idx
            year < eras.first().startYear -> 0
            else -> eras.size - 1
        }
    }

    /**
     * Maps an [eras] index to the 0-11 "book era index" used by [BookOfLuck].
     * Only the very first (1838-1867) era falls outside the book's coverage.
     */
    fun bookEraIndex(erasIndex: Int): Int? {
        val bookIdx = erasIndex - 1
        return if (bookIdx in 0..11) bookIdx else null
    }

    /** Convenience: book era index for a calendar year, clamped into the book's range. */
    fun bookEraIndexForYear(year: Int): Int {
        val erasIdx = eraIndexForYear(year)
        return bookEraIndex(erasIdx) ?: 0
    }
}
