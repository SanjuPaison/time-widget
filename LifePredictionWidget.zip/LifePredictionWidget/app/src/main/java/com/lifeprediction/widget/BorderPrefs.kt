package com.lifeprediction.widget

import android.content.Context

/**
 * The widget border's color — a user-facing Settings choice again. (This
 * had briefly been collapsed to a single fixed gold tint, on the reasoning
 * that it was a redundant second color control alongside the old background
 * color/texture picker; now that the background is a rotating photographic
 * scene rather than a flat color, the border is the only remaining accent
 * color a user can actually pick, so it's back.)
 *
 * bg_widget_border is a plain white-ish ring shape, tinted via
 * setColorFilter with whichever color this resolves to — same mechanism as
 * before, just driven by a stored preference instead of a hardcoded color.
 */
enum class BorderColor(val label: String, val colorRes: Int) {
    GOLD("Gold", R.color.border_gold),
    SILVER("Silver", R.color.border_silver),
    BLUE("Blue", R.color.border_blue),
    GREEN("Green", R.color.border_green)
}

object BorderPrefs {
    private const val PREFS = "border_prefs"
    private const val KEY_COLOR = "border_color"

    private val DEFAULT = BorderColor.GOLD

    fun get(context: Context): BorderColor {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return runCatching { BorderColor.valueOf(prefs.getString(KEY_COLOR, null) ?: "") }
            .getOrDefault(DEFAULT)
    }

    fun save(context: Context, color: BorderColor) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_COLOR, color.name)
            .apply()
    }
}
