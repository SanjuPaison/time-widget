package com.lifeprediction.widget

import kotlin.math.abs

object Numerology {
    /** Repeatedly sums digits until a single digit (1-9) remains. 0 maps to 9. */
    fun reduceToSingleDigit(number: Int): Int {
        var n = abs(number)
        if (n == 0) return 9
        while (n > 9) {
            var sum = 0
            var x = n
            while (x > 0) {
                sum += x % 10
                x /= 10
            }
            n = sum
        }
        return n
    }

    /**
     * Reduces a full calendar date (day + month + year) to a single digit by
     * summing every individual digit of all three together, then reducing
     * that sum — e.g. 16 Aug 2026 -> digits of 16, 8, 2026 -> 1+6+8+2+0+2+6
     * = 25 -> 2+5 = 7. This is distinct from reducing the day number alone,
     * which is what day/month/year's own individual colors use.
     */
    fun reduceDateToSingleDigit(day: Int, month: Int, year: Int): Int {
        val digitSum = "$day$month$year".sumOf { it.digitToInt() }
        return reduceToSingleDigit(digitSum)
    }
}
