plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.lifeprediction.widget"
    compileSdk = 34

    defaultConfig {
        // Deliberately different from the namespace above: this keeps the
        // Kotlin package (com.lifeprediction.widget) unchanged everywhere in
        // the source, while giving the app a distinct install identity —
        // applicationId, not namespace, is what Android uses to tell apps
        // apart at install time — so this "Lucky Stars" build and the
        // original app can be installed side by side on the same device.
        applicationId = "com.lifeprediction.luckystars"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    // The ephemeris data file is plain text; make sure AAPT doesn't try to compress
    // it away oddly and that it is packaged as-is.
    androidResources {
        noCompress += "tsv"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
}
