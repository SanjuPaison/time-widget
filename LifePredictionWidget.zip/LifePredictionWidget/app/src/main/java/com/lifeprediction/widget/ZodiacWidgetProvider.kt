package com.lifeprediction.widget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.widget.RemoteViews
import android.widget.Toast
import java.time.LocalDateTime
import java.time.ZoneId

/**
 * Base widget logic, shared by three separate manifest-declared receivers —
 * ZodiacWidgetProvider1x1/2x1/1x2 — each a trivial subclass with no code of
 * its own, existing purely so the widget picker shows three distinct, fixed-
 * size entries ("like other Android apps") instead of one resizable widget.
 * 1x1 and 2x1 share one layout (Sun/Moon side by side); 1x2 uses a separate
 * layout (Sun/Moon stacked vertically, since it's a single column wide) —
 * see layoutResFor().
 *
 * Colors are refreshed at the *exact second* they should change, not on a
 * fixed timer: every wake-up computes the earliest of (a) the next top-of-hour
 * (covers the Time box, and Date/Day/Month/Year at midnight since midnight is
 * also an hour boundary), (b) the next Sun-sign crossing, and (c) the next
 * Moon-sign crossing — then schedules a single exact alarm for whichever is
 * soonest, and repeats. Each wake is a handful of milliseconds of work, and
 * there are at most a few dozen of these a day (an hourly one, plus the rare
 * Sun/Moon sign changes), so this stays cheap even though it's precise.
 */
open class ZodiacWidgetProvider : AppWidgetProvider() {

    companion object {
        const val ACTION_TICK = "com.lifeprediction.widget.ACTION_TICK"

        /** Set on the refresh button's tap intent only, so onReceive can show a
         *  one-off "Refreshed" confirmation for manual taps without doing so on
         *  every silent scheduled tick. */
        private const val EXTRA_MANUAL = "manual"

        /** The three concrete, manifest-declared widget types. */
        private val allProviderClasses = listOf(
            ZodiacWidgetProvider1x1::class.java,
            ZodiacWidgetProvider2x1::class.java,
            ZodiacWidgetProvider1x2::class.java
        )

        /** 1x2 is a single column wide, so it uses the stacked-Sun/Moon layout;
         *  1x1 and 2x1 share the side-by-side layout. */
        private fun layoutResFor(providerClass: Class<out ZodiacWidgetProvider>): Int =
            if (providerClass == ZodiacWidgetProvider1x2::class.java) R.layout.widget_zodiac_tall
            else R.layout.widget_zodiac

        private fun colorFor(level: LuckLevel, context: Context): Int = when (level) {
            LuckLevel.LUCKY -> context.getColor(R.color.luck_lucky)
            LuckLevel.UNLUCKY -> context.getColor(R.color.luck_unlucky)
            LuckLevel.AVERAGE -> context.getColor(R.color.luck_average)
        }

        /**
         * "● 1 JUL 2026" as a single string (so it shares Time's exact font,
         * weight, and auto-size behavior instead of being split into three
         * independently-sized cells). The leading dot is colored by the
         * overall Date verdict (dateLevel, the full-date digit reduction) —
         * this is the widget's only visual indicator for that value now that
         * there's no date box background anymore; day/month/year keep their
         * own separate lucky/unlucky/average colors via spans.
         */
        private fun buildDateSpannable(snapshot: WidgetSnapshot, context: Context): SpannableString {
            val day = snapshot.date.dayOfMonth.toString()
            val month = snapshot.date.month.name.take(3)
            val year = snapshot.date.year.toString()
            val full = "\u25CF $day $month $year"
            val spannable = SpannableString(full)

            spannable.setSpan(
                ForegroundColorSpan(colorFor(snapshot.dateLevel, context)),
                0, 1,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )

            var cursor = 2 // skip the dot + its separating space
            fun colorSegment(segment: String, level: LuckLevel) {
                val start = cursor
                val end = start + segment.length
                spannable.setSpan(
                    ForegroundColorSpan(colorFor(level, context)),
                    start, end,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
                cursor = end + 1 // skip the separating space
            }
            colorSegment(day, snapshot.dayLevel)
            colorSegment(month, snapshot.monthLevel)
            colorSegment(year, snapshot.yearLevel)

            return spannable
        }

        fun buildRemoteViews(context: Context, providerClass: Class<out ZodiacWidgetProvider>): RemoteViews {
            val views = RemoteViews(context.packageName, layoutResFor(providerClass))
            val snapshot = LuckCalculator.buildSnapshot(context)

            // Background: user's chosen color+texture from Settings (default:
            // brown translucent). setInt(...,"setBackgroundResource",...) swaps
            // the whole drawable, not just a tint, since Parchment/Stars are
            // fundamentally different shapes/layers, not just recolors.
            views.setInt(R.id.widget_root, "setBackgroundResource", BackgroundPrefs.drawableResId(context))

            // BORDER — whole-widget ring tinted by the day's overall luck
            // (dateLevel), same setColorFilter technique as the Sun/Moon boxes.
            views.setInt(R.id.widget_border, "setColorFilter", colorFor(snapshot.dateLevel, context))

            // TIME — no box anymore; color goes straight on the text (celestial redesign)
            views.setTextColor(R.id.widget_time, colorFor(snapshot.timeLevel, context))

            // SUN box
            views.setTextViewText(
                R.id.widget_sun_text,
                "\u2600 " + symbolFor(snapshot.transitingSunSign)
            )
            views.setInt(R.id.widget_sun_bg, "setColorFilter", colorFor(snapshot.sunLevel, context))

            // MOON box
            views.setTextViewText(
                R.id.widget_moon_text,
                "\uD83C\uDF19 " + symbolFor(snapshot.transitingMoonSign)
            )
            views.setInt(R.id.widget_moon_bg, "setColorFilter", colorFor(snapshot.moonLevel, context))

            // DATE — no box anymore; day/month/year keep their own
            // lucky/unlucky/average color via spans on a single string.
            views.setTextViewText(R.id.widget_date_text, buildDateSpannable(snapshot, context))

            // Click targets -> description popups
            views.setOnClickPendingIntent(R.id.widget_time, descriptionIntent(context, Section.TIME, snapshot.timeLevel, 1))
            views.setOnClickPendingIntent(R.id.widget_sun_box, descriptionIntent(context, Section.SUN, snapshot.sunLevel, 2))
            views.setOnClickPendingIntent(R.id.widget_moon_box, descriptionIntent(context, Section.MOON, snapshot.moonLevel, 3))
            views.setOnClickPendingIntent(R.id.widget_date_text, descriptionIntent(context, Section.DATE, snapshot.dateLevel, 4))

            // Website -> opens the browser (no INTERNET permission needed here;
            // the browser app does the actual network fetch, not us)
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse(context.getString(R.string.website_url)))
            val webPending = PendingIntent.getActivity(
                context, 5, webIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_website, webPending)

            // Instagram -> opens the browser to the Instagram profile
            val instagramIntent = Intent(Intent.ACTION_VIEW, Uri.parse(context.getString(R.string.instagram_url)))
            val instagramPending = PendingIntent.getActivity(
                context, 7, instagramIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_instagram, instagramPending)

            // Refresh button -> broadcasts ACTION_TICK the same way the
            // scheduled alarm does, so tapping it does exactly what a normal
            // tick does: recompute every color right now and reschedule the
            // next one. Explicitly targeted at this specific provider class
            // (rather than only an implicit, package-scoped intent) so
            // resolution doesn't depend on the OS matching an implicit action
            // across three same-action manifest receivers — more reliable
            // across devices/launchers. EXTRA_MANUAL flags this as a user tap
            // so onReceive can show a one-off confirmation, since colors only
            // visibly change at an actual hour/sign boundary and a silent
            // recompute can otherwise look like the button did nothing.
            val refreshIntent = Intent(ACTION_TICK, null, context, providerClass)
                .putExtra(EXTRA_MANUAL, true)
            val refreshPending = PendingIntent.getBroadcast(
                context, 6, refreshIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_refresh, refreshPending)

            return views
        }

        private fun descriptionIntent(context: Context, section: Section, level: LuckLevel, requestCode: Int): PendingIntent {
            val intent = Intent(context, DescriptionActivity::class.java).apply {
                putExtra(DescriptionActivity.EXTRA_SECTION, section.name)
                putExtra(DescriptionActivity.EXTRA_LEVEL, level.name)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            return PendingIntent.getActivity(
                context, requestCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        /**
         * Rebuilds and pushes fresh RemoteViews to every placed instance of
         * all three widget types (1x1, 2x1, 1x2) — a user could have any
         * combination of them placed at once. Each type gets its own
         * buildRemoteViews() call since 1x2 uses a different layout.
         */
        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            for (cls in allProviderClasses) {
                val ids = manager.getAppWidgetIds(ComponentName(context, cls))
                if (ids.isNotEmpty()) {
                    manager.updateAppWidget(ids, buildRemoteViews(context, cls))
                }
            }
        }

        /**
         * Schedules a single exact alarm for the earliest moment any displayed
         * color would actually change: the next top-of-hour *in the device's
         * local time zone* (not UTC — the hour/date used for coloring comes
         * from the device's local clock, so scheduling by UTC hour boundaries
         * would fire up to ~30-60 minutes off for any zone with a non-whole-hour
         * UTC offset, e.g. India at UTC+5:30), or, if sooner, the exact instant
         * the Sun or Moon crosses into a new sign today (that part of the
         * ephemeris math is inherently UTC-based, which is fine — it's
         * converted to an absolute instant either way before comparing).
         *
         * The alarm's intent is implicit (action only, package-scoped) rather
         * than targeting one specific provider class, since any of the three
         * widget types' manifest intent-filters can be the one that's actually
         * placed — an implicit, package-scoped broadcast reaches whichever of
         * them are registered without needing to know which ones in advance.
         */
        fun scheduleNextTick(context: Context) {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return

            val localZone = ZoneId.systemDefault()
            val nowLocal = LocalDateTime.now(localZone)
            val nextLocalHour = nowLocal.withMinute(0).withSecond(0).withNano(0).plusHours(1)
            val nextHourMillis = nextLocalHour.atZone(localZone).toInstant().toEpochMilli()

            val nowUtc = LocalDateTime.now(ZoneId.of("UTC"))
            val sunCrossingMillis = EphemerisRepository.nextSignCrossing(context, nowUtc) { it.sunDegrees }
                ?.atZone(ZoneId.of("UTC"))?.toInstant()?.toEpochMilli()
            val moonCrossingMillis = EphemerisRepository.nextSignCrossing(context, nowUtc) { it.moonDegrees }
                ?.atZone(ZoneId.of("UTC"))?.toInstant()?.toEpochMilli()

            // nextHourMillis is always present, so this list is never empty —
            // minOrNull()!! is used instead of the plain min() extension,
            // which has had inconsistent availability across Kotlin stdlib
            // versions (deprecated as an error in some releases).
            val triggerAt = listOfNotNull(nextHourMillis, sunCrossingMillis, moonCrossingMillis).minOrNull()!!

            val intent = Intent(ACTION_TICK).setPackage(context.packageName)
            val pending = PendingIntent.getBroadcast(
                context, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val canScheduleExact = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                alarmManager.canScheduleExactAlarms()
            } else {
                true
            }

            if (canScheduleExact) {
                runCatching {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC, triggerAt, pending)
                }.onFailure {
                    alarmManager.set(AlarmManager.RTC, triggerAt, pending)
                }
            } else {
                // User hasn't granted the "Alarms & reminders" special access on
                // Android 13+. Fall back to an inexact wake — the widget still
                // refreshes, just without to-the-second precision, and it'll
                // catch up fully once the permission is granted (SettingsActivity
                // offers a shortcut to do that).
                alarmManager.set(AlarmManager.RTC, triggerAt, pending)
            }
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val views = buildRemoteViews(context, javaClass)
        appWidgetIds.forEach { id -> appWidgetManager.updateAppWidget(id, views) }
        scheduleNextTick(context)
    }

    override fun onEnabled(context: Context) {
        scheduleNextTick(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_TICK) {
            updateAll(context)
            scheduleNextTick(context)
            // Manual refresh-button tap: colors only actually change at a real
            // hour/sign boundary, so a silent recompute can look like the
            // button did nothing. A short Toast confirms the tap registered.
            if (intent.getBooleanExtra(EXTRA_MANUAL, false)) {
                Toast.makeText(context, R.string.refreshed_toast, Toast.LENGTH_SHORT).show()
            }
        }
    }
}
