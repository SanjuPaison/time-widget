package com.lifeprediction.widget

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

class SettingsActivity : AppCompatActivity() {

    private var pickedDate: LocalDate = LocalDate.of(1990, 1, 1)
    private var pickedTime: LocalTime = LocalTime.of(12, 0)
    private var pickedZoneId: String = ZoneId.systemDefault().id

    private val dateFormat = DateTimeFormatter.ofPattern("d MMMM yyyy")
    private val timeFormat = DateTimeFormatter.ofPattern("h:mm a")

    // Sorted once; used for the time-zone picker list.
    private val allZoneIds: List<String> by lazy { ZoneId.getAvailableZoneIds().sorted() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val current = BirthPrefs.get(this)
        pickedDate = current.date
        pickedTime = current.time
        pickedZoneId = current.zoneId

        val dateView = findViewById<TextView>(R.id.settings_date_value)
        val timeView = findViewById<TextView>(R.id.settings_time_value)
        val timezoneView = findViewById<TextView>(R.id.settings_timezone_value)
        val placeInput = findViewById<AutoCompleteTextView>(R.id.settings_place_input)

        dateView.text = pickedDate.format(dateFormat)
        timeView.text = pickedTime.format(timeFormat)
        timezoneView.text = zoneLabel(pickedZoneId)
        placeInput.setText(current.placeName)

        // City auto-suggest, backed by Android's own IANA timezone city list —
        // picking a suggestion fills in the time zone for you automatically.
        val cityAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_dropdown_item_1line,
            CityTimeZoneRepository.all.map { it.label }
        )
        placeInput.setAdapter(cityAdapter)
        placeInput.setOnItemClickListener { parent, _, position, _ ->
            val label = parent.getItemAtPosition(position) as String
            CityTimeZoneRepository.zoneIdForLabel(label)?.let { zone ->
                pickedZoneId = zone
                timezoneView.text = zoneLabel(zone)
            }
        }

        val genderGroup = findViewById<RadioGroup>(R.id.settings_gender_group)
        val maleRadio = findViewById<RadioButton>(R.id.settings_gender_male)
        val femaleRadio = findViewById<RadioButton>(R.id.settings_gender_female)
        if (current.gender == Gender.FEMALE) femaleRadio.isChecked = true else maleRadio.isChecked = true

        dateView.setOnClickListener {
            DatePickerDialog(
                this,
                { _, year, month, dayOfMonth ->
                    pickedDate = LocalDate.of(year, month + 1, dayOfMonth)
                    dateView.text = pickedDate.format(dateFormat)
                },
                pickedDate.year, pickedDate.monthValue - 1, pickedDate.dayOfMonth
            ).show()
        }

        timeView.setOnClickListener {
            TimePickerDialog(
                this,
                { _, hourOfDay, minute ->
                    pickedTime = LocalTime.of(hourOfDay, minute)
                    timeView.text = pickedTime.format(timeFormat)
                },
                pickedTime.hour, pickedTime.minute, false
            ).show()
        }

        timezoneView.setOnClickListener {
            val labels = allZoneIds.map { zoneLabel(it) }.toTypedArray()
            val preselect = allZoneIds.indexOf(pickedZoneId).coerceAtLeast(0)
            AlertDialog.Builder(this)
                .setTitle(R.string.birth_timezone_label)
                .setSingleChoiceItems(labels, preselect) { dialog, which ->
                    pickedZoneId = allZoneIds[which]
                    timezoneView.text = zoneLabel(pickedZoneId)
                    dialog.dismiss()
                }
                .show()
        }

        findViewById<TextView>(R.id.settings_save).setOnClickListener {
            val gender = if (genderGroup.checkedRadioButtonId == R.id.settings_gender_female) Gender.FEMALE else Gender.MALE
            BirthPrefs.save(
                this,
                BirthData(
                    date = pickedDate,
                    time = pickedTime,
                    placeName = placeInput.text?.toString()?.trim().orEmpty(),
                    zoneId = pickedZoneId,
                    gender = gender
                )
            )
            ZodiacWidgetProvider.updateAll(this)
            finish()
        }
    }

    private fun zoneLabel(id: String): String {
        val offset = runCatching {
            ZoneId.of(id).rules.getOffset(java.time.Instant.now()).id.replace("Z", "+00:00")
        }.getOrDefault("")
        return if (offset.isNotEmpty()) "$id (UTC$offset)" else id
    }
}
