package com.lifeprediction.widget

import android.content.Context

enum class BorderColor(val label: String, val colorRes: Int) {
    GOLD("Gold", R.color.border_gold),
    SILVER("Silver", R.color.border_silver),
    BLUE("Blue", R.color.border_blue),
    BROWN("Brown", R.color.border_brown)
}

/**
 * The widget border's color — a static Settings choice, not derived from the
 * day's luck (that's what it did before this became configurable; see
 * ZodiacWidgetProvider's border-tinting line for where it's applied).
 */
object BorderPrefs {
    private const val PREFS = "border_prefs"
    private const val KEY_COLOR = "border_color"

    private val DEFAULT = BorderColor.GOLD

    fun get(context: Context): BorderColor {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return runCatching { BorderColor.valueOf(prefs.getString(KEY_COLOR, null) ?: "") }.getOrDefault(DEFAULT)
    }

    fun save(context: Context, color: BorderColor) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_COLOR, color.name)
            .apply()
    }
}
