package com.lifeprediction.widget

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class DescriptionActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_GEM = "extra_gem"
        const val EXTRA_LEVEL = "extra_level"
        /** Short live context line, e.g. "Sun in Leo" or "Virgo Phase (2017-2032)" —
         *  computed in ZodiacWidgetProvider, which has the snapshot. */
        const val EXTRA_SUBTITLE = "extra_subtitle"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_description)

        val gem = runCatching {
            Gem.valueOf(intent.getStringExtra(EXTRA_GEM) ?: Gem.SAPPHIRE.name)
        }.getOrDefault(Gem.SAPPHIRE)
        val level = runCatching {
            LuckLevel.valueOf(intent.getStringExtra(EXTRA_LEVEL) ?: LuckLevel.AVERAGE.name)
        }.getOrDefault(LuckLevel.AVERAGE)
        val subtitle = intent.getStringExtra(EXTRA_SUBTITLE).orEmpty()

        val count = level.gemCount()
        val value = gem.valueUsd * count

        findViewById<TextView>(R.id.desc_title).text =
            "${gem.displayName} \u2022 ${level.tierWord()}"

        findViewById<TextView>(R.id.desc_subtitle).apply {
            if (subtitle.isNotEmpty()) {
                text = "${gem.elementLabel}: $subtitle"
                this.visibility = View.VISIBLE
            } else {
                this.visibility = View.GONE
            }
        }

        findViewById<TextView>(R.id.desc_value).text =
            "$${gem.valueUsd} \u00d7 $count stone${if (count == 1) "" else "s"} = $${value}"

        findViewById<TextView>(R.id.desc_body).text = Descriptions.text(gem, level)

        findViewById<View>(R.id.desc_badge).setBackgroundColor(
            when (level) {
                LuckLevel.LUCKY -> getColor(R.color.luck_lucky)
                LuckLevel.UNLUCKY -> getColor(R.color.luck_unlucky)
                LuckLevel.AVERAGE -> getColor(R.color.luck_average)
            }
        )

        findViewById<TextView>(R.id.desc_settings_link).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
            finish()
        }

        findViewById<View>(android.R.id.content).setOnClickListener { finish() }
    }
}
