package com.lifeprediction.widget

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class DescriptionActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_SECTION = "extra_section"
        const val EXTRA_LEVEL = "extra_level"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_description)

        val section = runCatching {
            Section.valueOf(intent.getStringExtra(EXTRA_SECTION) ?: Section.DATE.name)
        }.getOrDefault(Section.DATE)
        val level = runCatching {
            LuckLevel.valueOf(intent.getStringExtra(EXTRA_LEVEL) ?: LuckLevel.AVERAGE.name)
        }.getOrDefault(LuckLevel.AVERAGE)

        findViewById<TextView>(R.id.desc_title).text = "${Descriptions.title(section)} \u2022 ${level.name}"
        findViewById<TextView>(R.id.desc_body).text = Descriptions.text(section, level)
        findViewById<View>(R.id.desc_badge).setBackgroundColor(
            when (level) {
                LuckLevel.LUCKY -> getColor(R.color.luck_lucky)
                LuckLevel.UNLUCKY -> getColor(R.color.luck_unlucky)
                LuckLevel.AVERAGE -> getColor(R.color.luck_average)
            }
        )

        findViewById<TextView>(R.id.desc_settings_link).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
            finish()
        }

        findViewById<View>(android.R.id.content).setOnClickListener { finish() }
    }
}
