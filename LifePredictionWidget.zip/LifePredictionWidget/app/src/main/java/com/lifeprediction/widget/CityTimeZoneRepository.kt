package com.lifeprediction.widget

import java.time.ZoneId

/**
 * Turns Android's built-in IANA time zone database into a searchable "city"
 * list, instead of shipping a separate hand-maintained city->timezone
 * dataset. Most zone IDs are literally named after a real city already
 * (e.g. "Asia/Kolkata", "America/New_York", "Australia/Sydney"), so this is
 * both more accurate than a hand-typed table and needs no asset file, no
 * network access, and no extra permission — it's the same data
 * `ZoneId.of(...)` already uses everywhere else in this app.
 */
object CityTimeZoneRepository {

    data class CityZone(val label: String, val zoneId: String)

    /** All zone IDs Android knows about, reformatted as "City (Region)". */
    val all: List<CityZone> by lazy {
        ZoneId.getAvailableZoneIds()
            .filter { it.contains('/') && !it.startsWith("Etc/") && !it.startsWith("SystemV/") }
            .map { id ->
                val parts = id.split('/')
                val city = parts.last().replace('_', ' ')
                // For 3-part IDs like "America/Argentina/Buenos_Aires" the middle
                // segment ("Argentina") is more useful as the region label than
                // the top-level "America" continent.
                val region = (if (parts.size >= 3) parts[1] else parts[0]).replace('_', ' ')
                CityZone("$city ($region)", id)
            }
            .sortedBy { it.label }
    }

    private val labelToZoneId: Map<String, String> by lazy { all.associate { it.label to it.zoneId } }

    fun zoneIdForLabel(label: String): String? = labelToZoneId[label]
}
