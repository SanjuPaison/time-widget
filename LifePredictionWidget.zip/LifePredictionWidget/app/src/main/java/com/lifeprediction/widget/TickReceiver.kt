package com.lifeprediction.widget

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast

/**
 * Handles the widget's own "refresh now" tick — recomputing every color and
 * rescheduling the next exact alarm.
 *
 * Deliberately a SEPARATE component from the three widget-provider
 * receivers, and android:exported="false": those must stay exported="true"
 * so the launcher/AppWidgetManager can deliver APPWIDGET_UPDATE, but an
 * exported component can always be reached by an explicit intent from any
 * other app, regardless of what's declared in its intent-filter — a filter
 * only gates *implicit* intent matching. ACTION_TICK is an app-defined
 * action, not a protected system broadcast like BOOT_COMPLETED, so keeping
 * it on the same exported receivers would let any other installed app force
 * a recompute (and spoof the "Refreshed" toast) just by knowing the action
 * string, which is visible in the manifest either way. Putting it on its
 * own exported="false" receiver instead means the OS itself refuses
 * delivery from any other app's UID — a real boundary, not just an
 * unlisted intent-filter.
 */
class TickReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_TICK = "com.lifeprediction.widget.ACTION_TICK"

        /** Set on the refresh button's tap intent only, so a manual tap gets
         *  a one-off "Refreshed" confirmation without showing it on every
         *  silent scheduled tick. */
        const val EXTRA_MANUAL = "manual"
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION_TICK) return

        ZodiacWidgetProvider.updateAll(context)
        ZodiacWidgetProvider.scheduleNextTick(context)

        // Manual refresh-button tap: colors only actually change at a real
        // hour/sign boundary, so a silent recompute can look like the
        // button did nothing. A short Toast confirms the tap registered.
        if (intent.getBooleanExtra(EXTRA_MANUAL, false)) {
            Toast.makeText(context, R.string.refreshed_toast, Toast.LENGTH_SHORT).show()
        }
    }
}
