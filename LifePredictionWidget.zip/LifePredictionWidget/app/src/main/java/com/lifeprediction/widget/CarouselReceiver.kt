package com.lifeprediction.widget

import android.appwidget.AppWidgetManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Handles the widget's left/right gem-carousel arrows — same shape as
 * TickReceiver, and for the same reason (see its doc comment): ACTION_SCROLL
 * is an app-defined action with no protected-broadcast status, so this stays
 * on its own android:exported="false" receiver rather than the exported
 * widget-provider receivers, which any other app could otherwise reach with
 * an explicit intent regardless of intent-filter contents.
 */
class CarouselReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_SCROLL = "com.lifeprediction.widget.ACTION_SCROLL"
        /** -1 = back a page, +1 = forward a page. */
        const val EXTRA_DIRECTION = "direction"
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION_SCROLL) return
        val appWidgetId = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) return
        val direction = intent.getIntExtra(EXTRA_DIRECTION, 0)
        if (direction == 0) return

        val snapshot = LuckCalculator.buildSnapshot(context)
        val pageCount = ZodiacWidgetProvider.pageCountFor(GemLedger.activeStones(snapshot))
        if (pageCount <= 1) return // nothing to scroll to

        val current = CarouselPrefs.getPage(context, appWidgetId)
        // Wraps around in both directions — Kotlin's % can return negative,
        // hence the extra "+ pageCount" before the final modulo.
        val next = ((current + direction) % pageCount + pageCount) % pageCount
        CarouselPrefs.setPage(context, appWidgetId, next)

        // Rotates the shared background image on every scroll. Advances the
        // one global stored index (not per-instance), then rebuilds EVERY
        // placed widget instance (not just this one) via updateAll — each
        // instance's own carousel page is untouched (still read from its
        // own CarouselPrefs entry), only the background changes for all of
        // them together, so multiple placed widgets never show two
        // different images at once.
        VillageBackgroundPrefs.advance(context)

        ZodiacWidgetProvider.updateAll(context)
    }
}
