package com.lifeprediction.widget

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class DescriptionActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_INITIAL_GEM = "extra_initial_gem"
        /** 8 comma-joined LuckLevel names, in Gem.values() order. */
        const val EXTRA_LEVELS = "extra_levels"
        /** 8 "|||"-joined event phrases (preposition already included, e.g.
         *  "in 2026"), in Gem.values() order — see
         *  ZodiacWidgetProvider.eventPhraseFor. */
        const val EXTRA_EVENTS = "extra_events"
    }

    private lateinit var levels: Map<Gem, LuckLevel>
    private lateinit var events: Map<Gem, String>
    private var currentGem: Gem = Gem.QUARTZ

    /** Gem -> (tab column id, count TextView id, color bar View id). */
    private val tabIds: Map<Gem, Triple<Int, Int, Int>> = mapOf(
        Gem.QUARTZ to Triple(R.id.desc_tab_quartz, R.id.desc_tab_count_quartz, R.id.desc_tab_bar_quartz),
        Gem.AMETHYST to Triple(R.id.desc_tab_amethyst, R.id.desc_tab_count_amethyst, R.id.desc_tab_bar_amethyst),
        Gem.TOPAZ to Triple(R.id.desc_tab_topaz, R.id.desc_tab_count_topaz, R.id.desc_tab_bar_topaz),
        Gem.JADE to Triple(R.id.desc_tab_jade, R.id.desc_tab_count_jade, R.id.desc_tab_bar_jade),
        Gem.SAPPHIRE to Triple(R.id.desc_tab_sapphire, R.id.desc_tab_count_sapphire, R.id.desc_tab_bar_sapphire),
        Gem.EMERALD to Triple(R.id.desc_tab_emerald, R.id.desc_tab_count_emerald, R.id.desc_tab_bar_emerald),
        Gem.RUBY to Triple(R.id.desc_tab_ruby, R.id.desc_tab_count_ruby, R.id.desc_tab_bar_ruby),
        Gem.DIAMOND to Triple(R.id.desc_tab_diamond, R.id.desc_tab_count_diamond, R.id.desc_tab_bar_diamond)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_description)

        // Background: shows whichever image is CURRENTLY active (shared
        // with the widget) — no longer advances on its own. The ONLY thing
        // that rotates the background now is the widget's own refresh
        // button (see VillageBackgroundPrefs's doc comment). centerCrop on
        // desc_bg_image keeps the real photo aspect ratio, filling the
        // screen without distortion, rather than the old
        // setBackgroundResource stretch.
        findViewById<ImageView>(R.id.desc_bg_image).setImageResource(VillageBackgroundPrefs.currentDrawableResId(this))

        // Ornate border: same color the person picked for the widget's own
        // border in Settings (BorderPrefs) — one setColorFilter per piece,
        // same mechanism ZodiacWidgetProvider uses for the widget's ring.
        val borderArgb = getColor(BorderPrefs.get(this).colorRes)
        findViewById<View>(R.id.desc_border_frame).background.setTint(borderArgb)
        for (id in listOf(R.id.desc_border_corner_tl, R.id.desc_border_corner_tr, R.id.desc_border_corner_br, R.id.desc_border_corner_bl)) {
            findViewById<ImageView>(id).setColorFilter(borderArgb)
        }

        val gems = Gem.values()
        val levelNames = intent.getStringExtra(EXTRA_LEVELS)?.split(",").orEmpty()
        val eventList = intent.getStringExtra(EXTRA_EVENTS)?.split("|||").orEmpty()

        levels = gems.indices.associate { i ->
            gems[i] to (levelNames.getOrNull(i)
                ?.let { name -> runCatching { LuckLevel.valueOf(name) }.getOrNull() }
                ?: LuckLevel.AVERAGE)
        }
        events = gems.indices.associate { i -> gems[i] to eventList.getOrNull(i).orEmpty() }

        val initialGem = runCatching {
            Gem.valueOf(intent.getStringExtra(EXTRA_INITIAL_GEM) ?: Gem.QUARTZ.name)
        }.getOrDefault(Gem.QUARTZ)

        // Counts are set once — they don't change as tabs are tapped.
        for ((gem, ids) in tabIds) {
            findViewById<TextView>(ids.second).text = levels.getValue(gem).gemCount().toString()
        }
        for ((gem, ids) in tabIds) {
            findViewById<View>(ids.first).setOnClickListener { showGem(gem) }
        }

        findViewById<TextView>(R.id.desc_settings_link).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
            finish()
        }
        findViewById<View>(android.R.id.content).setOnClickListener { finish() }
        findViewById<View>(R.id.desc_share).setOnClickListener { shareGem() }

        showGem(initialGem)
    }

    private fun showGem(gem: Gem) {
        currentGem = gem
        val level = levels.getValue(gem)
        val count = level.gemCount()
        val name = gem.countedName(count)

        for ((g, ids) in tabIds) {
            findViewById<View>(ids.third).alpha = if (g == gem) 1f else 0.4f
        }

        findViewById<ImageView>(R.id.desc_illustration).setImageResource(gem.illustrationRes)

        findViewById<TextView>(R.id.desc_hero).text =
            "You got $count $name ${events.getValue(gem)}."

        findViewById<TextView>(R.id.desc_calc).text =
            "$${gem.valueUsd} \u00d7 $count $name = $${gem.valueUsd * count}"

        findViewById<TextView>(R.id.desc_body).text = Descriptions.text(gem, level)
    }

    /**
     * Renders this gem's share card (big illustration + stone-theme card,
     * matching the popup's own restyled look) and launches the system
     * share sheet with it plus the "I got ## (gem name) on Pluto Phases
     * Gems!" caption — a separate feature from the widget's own reveal
     * share, which shares the day's total instead of one specific gem.
     */
    private fun shareGem() {
        val gem = currentGem
        val level = levels.getValue(gem)
        val count = level.gemCount()
        val name = gem.countedName(count)

        val borderArgb = getColor(BorderPrefs.get(this).colorRes)
        val bmp = ShareReceiver.renderGemCardBitmap(this, gem.illustrationRes, borderArgb)

        val shareDir = java.io.File(cacheDir, "shared").apply { mkdirs() }
        val file = java.io.File(shareDir, "gem_share.png")
        java.io.FileOutputStream(file).use { out -> bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, out) }

        val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.fileprovider", file)

        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, ShareReceiver.buildGemCaption(this@DescriptionActivity, count, name))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(sendIntent, null))
    }
}
