package com.lifeprediction.widget

/**
 * The eight elements are recast as gemstones for display. Each gem has a
 * fixed identity color (never changes) and a fixed dollar value; only the
 * *count* (0/1/2, from the day's LuckLevel) and the surrounding box border
 * change per refresh. Ordered here by ascending value, which also drives the
 * grid's reading order (see widget layout files) so the eye moves from the
 * common stones toward the rare Diamond.
 */
enum class Gem(
    val displayName: String,
    /** What this gem measures — shown as context in the tap-through screen. */
    val elementLabel: String,
    val valueUsd: Int,
    val colorRes: Int,
    val illustrationRes: Int
) {
    QUARTZ("Quartz", "Time", 10, R.color.gem_quartz, R.drawable.ic_gem_quartz),
    AMETHYST("Amethyst", "Day", 50, R.color.gem_amethyst, R.drawable.ic_gem_amethyst),
    TOPAZ("Topaz", "Moon Sign", 100, R.color.gem_topaz, R.drawable.ic_gem_topaz),
    JADE("Jade", "Sun Sign", 300, R.color.gem_jade, R.drawable.ic_gem_jade),
    SAPPHIRE("Sapphire", "Month", 300, R.color.gem_sapphire, R.drawable.ic_gem_sapphire),
    EMERALD("Emerald", "Date", 400, R.color.gem_emerald, R.drawable.ic_gem_emerald),
    RUBY("Ruby", "Year", 600, R.color.gem_ruby, R.drawable.ic_gem_ruby),
    DIAMOND("Diamond", "Phase", 5000, R.color.gem_diamond, R.drawable.ic_gem_diamond)
}

/** How this gem's name reads in a sentence for a given count. Quartz and
 *  Jade are treated as mass nouns ("2 Quartz"), matching how they're
 *  normally referred to in trade/mineral contexts; the rest take a standard
 *  English plural ("2 Rubies", "2 Sapphires", "2 Topazes"). */
fun Gem.countedName(count: Int): String {
    if (count == 1) return displayName
    return when (this) {
        Gem.QUARTZ, Gem.JADE -> displayName
        Gem.RUBY -> "Rubies"
        Gem.TOPAZ -> "Topazes"
        else -> "${displayName}s"
    }
}

/** 0 stones for Dim (unlucky), 1 for Dormant (average), 2 for Charged (lucky). */
fun LuckLevel.gemCount(): Int = when (this) {
    LuckLevel.UNLUCKY -> 0
    LuckLevel.AVERAGE -> 1
    LuckLevel.LUCKY -> 2
}

data class GemEntry(val gem: Gem, val level: LuckLevel) {
    val count: Int get() = level.gemCount()
    val value: Int get() = gem.valueUsd * count
}

object GemLedger {

    /** One entry per gem, in element order (Time->Diamond/Phase), matching
     *  the corrected element-to-gem mapping: Time-Quartz, Day-Amethyst,
     *  Moon-Topaz, Sun-Jade, Month-Sapphire, Date-Emerald, Year-Ruby,
     *  Phase-Diamond. */
    fun entries(snapshot: WidgetSnapshot): List<GemEntry> = listOf(
        GemEntry(Gem.QUARTZ, snapshot.timeLevel),
        GemEntry(Gem.AMETHYST, snapshot.dayLevel),
        GemEntry(Gem.TOPAZ, snapshot.moonLevel),
        GemEntry(Gem.JADE, snapshot.sunLevel),
        GemEntry(Gem.SAPPHIRE, snapshot.monthLevel),
        GemEntry(Gem.EMERALD, snapshot.dateLevel),
        GemEntry(Gem.RUBY, snapshot.yearLevel),
        GemEntry(Gem.DIAMOND, snapshot.phaseLevel)
    )

    fun totalValue(snapshot: WidgetSnapshot): Int = entries(snapshot).sumOf { it.value }

    fun levelFor(gem: Gem, snapshot: WidgetSnapshot): LuckLevel =
        entries(snapshot).first { it.gem == gem }.level

    /**
     * A flat list of the gems actually "owned" today — every count-0 (Dim)
     * gem is skipped entirely, and a count-2 gem appears TWICE, so this is a
     * list of physical stones, not elements: e.g. [RUBY, RUBY, DIAMOND,
     * SAPPHIRE] for 2 Rubies + 1 Diamond + 1 Sapphire. Ordered by ascending
     * gem value (ties broken by entries()'s element order), so paging
     * through it moves from common to rare. This is what the widget-face
     * carousel (3 physical slots per page) and its page-count are built from.
     */
    fun activeStones(snapshot: WidgetSnapshot): List<Gem> =
        entries(snapshot)
            .sortedBy { it.gem.valueUsd }
            .flatMap { entry -> List(entry.count) { entry.gem } }
}
