package com.lifeprediction.widget

import android.content.Context

/**
 * Which page (0-based) of the gem carousel each individual PLACED widget is
 * currently showing — keyed by appWidgetId, so if the user has placed more
 * than one widget instance, each can be scrolled independently rather than
 * all of them sharing one global page.
 */
object CarouselPrefs {
    private const val PREFS = "carousel_prefs"
    private fun key(appWidgetId: Int) = "page_$appWidgetId"

    fun getPage(context: Context, appWidgetId: Int): Int =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(key(appWidgetId), 0)

    fun setPage(context: Context, appWidgetId: Int, page: Int) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt(key(appWidgetId), page)
            .apply()
    }

    /** Called from onDeleted so a removed widget instance's stored page
     *  doesn't sit around indefinitely if that same numeric id is ever
     *  reused for a future widget placement. */
    fun clear(context: Context, appWidgetId: Int) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .remove(key(appWidgetId))
            .apply()
    }

    /** Resets EVERY placed instance back to page 0 (the reveal slide) —
     *  used by the manual refresh-button tap. Clearing the whole prefs file
     *  is equivalent to removing each individual key, since a missing key
     *  already defaults to page 0 in getPage() above. */
    fun resetAll(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .clear()
            .apply()
    }
}
