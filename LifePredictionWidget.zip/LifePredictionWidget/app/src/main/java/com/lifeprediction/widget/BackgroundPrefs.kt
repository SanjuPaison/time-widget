package com.lifeprediction.widget

import android.content.Context

enum class BgColor(val label: String) {
    NAVY("Navy"),
    BLUE("Blue"),
    CHARCOAL("Charcoal"),
    FOREST("Forest"),
    BURGUNDY("Burgundy"),
    BROWN("Brown")
}

enum class BgTexture(val label: String) {
    SOLID("Solid"),
    TRANSLUCENT("Translucent"),
    PARCHMENT("Parchment"),
    STARS("Stars")
}

data class BackgroundChoice(val color: BgColor, val texture: BgTexture)

/**
 * The widget's background is one of 5 colors x 4 textures — except Parchment
 * and Stars are each a single fixed, self-contained look (a literal light
 * parchment or a starfield doesn't make sense recolored to, say, "burgundy"),
 * so the color picker in Settings only actually changes anything when the
 * texture is Solid or Translucent.
 */
object BackgroundPrefs {
    private const val PREFS = "background_prefs"
    private const val KEY_COLOR = "bg_color"
    private const val KEY_TEXTURE = "bg_texture"

    private val DEFAULT = BackgroundChoice(BgColor.BROWN, BgTexture.TRANSLUCENT)

    fun get(context: Context): BackgroundChoice {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val color = runCatching { BgColor.valueOf(prefs.getString(KEY_COLOR, null) ?: "") }.getOrDefault(DEFAULT.color)
        val texture = runCatching { BgTexture.valueOf(prefs.getString(KEY_TEXTURE, null) ?: "") }.getOrDefault(DEFAULT.texture)
        return BackgroundChoice(color, texture)
    }

    fun save(context: Context, choice: BackgroundChoice) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_COLOR, choice.color.name)
            .putString(KEY_TEXTURE, choice.texture.name)
            .apply()
    }

    /** Resolves the current choice to the actual drawable resource to use as the widget's background. */
    fun drawableResId(context: Context, choice: BackgroundChoice = get(context)): Int {
        return when (choice.texture) {
            BgTexture.PARCHMENT -> R.drawable.bg_theme_parchment
            BgTexture.STARS -> R.drawable.bg_theme_stars
            BgTexture.SOLID -> solidResId(choice.color)
            BgTexture.TRANSLUCENT -> translucentResId(choice.color)
        }
    }

    private fun solidResId(color: BgColor): Int = when (color) {
        BgColor.NAVY -> R.drawable.bg_theme_navy_solid
        BgColor.BLUE -> R.drawable.bg_theme_blue_solid
        BgColor.CHARCOAL -> R.drawable.bg_theme_charcoal_solid
        BgColor.FOREST -> R.drawable.bg_theme_forest_solid
        BgColor.BURGUNDY -> R.drawable.bg_theme_burgundy_solid
        BgColor.BROWN -> R.drawable.bg_theme_brown_solid
    }

    private fun translucentResId(color: BgColor): Int = when (color) {
        BgColor.NAVY -> R.drawable.bg_theme_navy_translucent
        BgColor.BLUE -> R.drawable.bg_theme_blue_translucent
        BgColor.CHARCOAL -> R.drawable.bg_theme_charcoal_translucent
        BgColor.FOREST -> R.drawable.bg_theme_forest_translucent
        BgColor.BURGUNDY -> R.drawable.bg_theme_burgundy_translucent
        BgColor.BROWN -> R.drawable.bg_theme_brown_translucent
    }
}
