package com.lifeprediction.widget

/**
 * Exists purely to give the 1x1 widget its own manifest component, so it
 * shows as a separate, distinct entry in the widget picker. No logic of its
 * own — everything is inherited from ZodiacWidgetProvider.
 */
class ZodiacWidgetProvider1x1 : ZodiacWidgetProvider()
