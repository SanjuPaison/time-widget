package com.lifeprediction.widget

/**
 * Exists purely to give the 2x2 widget its own manifest component, so it
 * shows as a separate, distinct entry in the widget picker. No logic of its
 * own — everything is inherited from ZodiacWidgetProvider.
 */
class ZodiacWidgetProvider2x2 : ZodiacWidgetProvider()
