package com.lifeprediction.widget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.widget.RemoteViews
import java.time.LocalDateTime
import java.time.ZoneId
import kotlin.math.floor

/**
 * Base widget logic, shared by three separate manifest-declared receivers —
 * ZodiacWidgetProvider1x1/2x1/1x2 — each a trivial subclass with no code of
 * its own, existing purely so the widget picker shows three distinct, fixed-
 * size entries ("like other Android apps") instead of one resizable widget.
 * 1x1 and 2x1 share one layout (Sun/Moon side by side); 1x2 uses a separate
 * layout (Sun/Moon stacked vertically, since it's a single column wide) —
 * see layoutResFor().
 *
 * Colors are refreshed at the *exact second* they should change, not on a
 * fixed timer: every wake-up computes the earliest of (a) the next top-of-hour
 * (covers the Time box, and Date/Day/Month/Year at midnight since midnight is
 * also an hour boundary), (b) the next Sun-sign crossing, and (c) the next
 * Moon-sign crossing — then schedules a single exact alarm for whichever is
 * soonest, and repeats. Each wake is a handful of milliseconds of work, and
 * there are at most a few dozen of these a day (an hourly one, plus the rare
 * Sun/Moon sign changes), so this stays cheap even though it's precise.
 */
open class ZodiacWidgetProvider : AppWidgetProvider() {

    companion object {
        /** Handled by TickReceiver, not this class — see its own file and
         *  AndroidManifest.xml for why ACTION_TICK was split out into its
         *  own permission-protected receiver. */
        const val ACTION_TICK = "com.lifeprediction.widget.ACTION_TICK"

        /** Set on the refresh button's tap intent only, so TickReceiver can show
         *  a one-off "Refreshed" confirmation for manual taps without doing so on
         *  every silent scheduled tick. */
        const val EXTRA_MANUAL = "manual"

        /** The three concrete, manifest-declared widget types. */
        private val allProviderClasses = listOf(
            ZodiacWidgetProvider1x1::class.java,
            ZodiacWidgetProvider2x1::class.java,
            ZodiacWidgetProvider1x2::class.java
        )

        /** 1x2 is a single column wide, so it uses the stacked-Sun/Moon layout;
         *  1x1 and 2x1 share the side-by-side layout. */
        private fun layoutResFor(providerClass: Class<out ZodiacWidgetProvider>): Int =
            if (providerClass == ZodiacWidgetProvider1x2::class.java) R.layout.widget_zodiac_tall
            else R.layout.widget_zodiac

        private fun colorFor(level: LuckLevel, context: Context): Int = when (level) {
            LuckLevel.LUCKY -> context.getColor(R.color.luck_lucky)
            LuckLevel.UNLUCKY -> context.getColor(R.color.luck_unlucky)
            LuckLevel.AVERAGE -> context.getColor(R.color.luck_average)
        }

        /**
         * "● 1 JUL 2026" as a single string (so it shares Time's exact font,
         * weight, and auto-size behavior instead of being split into three
         * independently-sized cells). The leading dot is colored by the
         * overall Date verdict (dateLevel, the full-date digit reduction) —
         * this is the widget's only visual indicator for that value now that
         * there's no date box background anymore; day/month/year keep their
         * own separate lucky/unlucky/average colors via spans.
         */
        private fun buildDateSpannable(snapshot: WidgetSnapshot, context: Context): SpannableString {
            val day = snapshot.date.dayOfMonth.toString()
            val month = snapshot.date.month.name.take(3)
            val year = snapshot.date.year.toString()
            val full = "\u25CF $day $month $year"
            val spannable = SpannableString(full)

            spannable.setSpan(
                ForegroundColorSpan(colorFor(snapshot.dateLevel, context)),
                0, 1,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )

            var cursor = 2 // skip the dot + its separating space
            fun colorSegment(segment: String, level: LuckLevel) {
                val start = cursor
                val end = start + segment.length
                spannable.setSpan(
                    ForegroundColorSpan(colorFor(level, context)),
                    start, end,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
                cursor = end + 1 // skip the separating space
            }
            colorSegment(day, snapshot.dayLevel)
            colorSegment(month, snapshot.monthLevel)
            colorSegment(year, snapshot.yearLevel)

            return spannable
        }

        private const val STAR_COUNT = 14

        private fun luckValue(level: LuckLevel): Int = when (level) {
            LuckLevel.LUCKY -> 2
            LuckLevel.AVERAGE -> 1
            LuckLevel.UNLUCKY -> 0
        }

        /**
         * Combines all 7 tracked categories into one weighted score (weights
         * sum to 100 — Time 20, Date 25, Day 5, Month 10, Year 15, Sun 15,
         * Moon 10 — each valued Lucky=2/Average=1/Unlucky=0, so weightedSum
         * ranges 0..200). That score's share of the max, scaled to 14 stars
         * and floored (decimal ignored), is how many of the 14 displayed
         * stars are bright: all-unlucky -> 0 bright, all-lucky -> 14 bright,
         * an even mix -> 7 bright.
         */
        private fun brightStarCount(snapshot: WidgetSnapshot): Int {
            val weightedSum =
                20 * luckValue(snapshot.timeLevel) +
                25 * luckValue(snapshot.dateLevel) +
                5 * luckValue(snapshot.dayLevel) +
                10 * luckValue(snapshot.monthLevel) +
                15 * luckValue(snapshot.yearLevel) +
                15 * luckValue(snapshot.sunLevel) +
                10 * luckValue(snapshot.moonLevel)
            val score = weightedSum / 100.0 // 0..2
            return floor(score / 2.0 * STAR_COUNT).toInt().coerceIn(0, STAR_COUNT)
        }

        /**
         * 14 star glyphs as a single string (single-line, auto-sizing, same
         * technique as the Date line), with `brightCount` of the 14 positions
         * randomly chosen to be bright (white) — reshuffled on every build,
         * i.e. every refresh — so there's no fixed, learnable position-to-
         * category mapping; the rest stay dim (grey).
         */
        private fun buildStarsSpannable(brightCount: Int, context: Context): SpannableString {
            val full = "\u2605 ".repeat(STAR_COUNT).trimEnd() // "★ ★ ★ ... ★" (14 stars)
            val spannable = SpannableString(full)
            val brightPositions = (0 until STAR_COUNT).shuffled().take(brightCount).toSet()

            val brightColor = context.getColor(R.color.star_bright)
            val dimColor = context.getColor(R.color.star_dim)

            for (i in 0 until STAR_COUNT) {
                val start = i * 2 // each star is 1 char + 1 separating space, except the last
                val end = start + 1
                spannable.setSpan(
                    ForegroundColorSpan(if (i in brightPositions) brightColor else dimColor),
                    start, end,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
            }
            return spannable
        }

        fun buildRemoteViews(context: Context, providerClass: Class<out ZodiacWidgetProvider>): RemoteViews {
            val views = RemoteViews(context.packageName, layoutResFor(providerClass))
            val snapshot = LuckCalculator.buildSnapshot(context)

            // Background is no longer configurable — widget_root just shows
            // its fixed XML-declared bg_celestial_card, unmodified here.

            // BORDER — user-picked color from Settings (BorderPrefs), tinted
            // the same setColorFilter way the Sun/Moon boxes already are;
            // no longer auto-tinted by the day's luck level.
            views.setInt(R.id.widget_border, "setColorFilter", Color.parseColor(BorderPrefs.get(context).hex))

            // TIME — no box anymore; color goes straight on the text (celestial redesign)
            views.setTextColor(R.id.widget_time, colorFor(snapshot.timeLevel, context))

            // SUN box
            views.setTextViewText(
                R.id.widget_sun_text,
                "\u2600 " + symbolFor(snapshot.transitingSunSign)
            )
            views.setInt(R.id.widget_sun_bg, "setColorFilter", colorFor(snapshot.sunLevel, context))

            // MOON box
            views.setTextViewText(
                R.id.widget_moon_text,
                "\uD83C\uDF19 " + symbolFor(snapshot.transitingMoonSign)
            )
            views.setInt(R.id.widget_moon_bg, "setColorFilter", colorFor(snapshot.moonLevel, context))

            // DATE — no box anymore; day/month/year keep their own
            // lucky/unlucky/average color via spans on a single string.
            views.setTextViewText(R.id.widget_date_text, buildDateSpannable(snapshot, context))

            // STARS — replaces the old plain percentage: 14 stars, with
            // brightStarCount(snapshot) of them lit at random positions
            // (see buildStarsSpannable) each time this is built.
            views.setTextViewText(R.id.widget_stars, buildStarsSpannable(brightStarCount(snapshot), context))

            // Whole widget is now a single tap target -> the combined reading
            // screen (all 7 categories at once). There are no more separate
            // per-element popups, so Time/Sun/Moon/Date no longer get their
            // own setOnClickPendingIntent. Set on both widget_root and
            // widget_border (a sibling layered on top covering the same
            // area) so the tap registers regardless of which one the widget
            // host happens to hit-test first.
            val readingPending = allSectionsIntent(context, snapshot, 1)
            views.setOnClickPendingIntent(R.id.widget_root, readingPending)
            views.setOnClickPendingIntent(R.id.widget_border, readingPending)

            // Website -> opens the browser (no INTERNET permission needed here;
            // the browser app does the actual network fetch, not us)
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse(context.getString(R.string.website_url)))
            val webPending = PendingIntent.getActivity(
                context, 5, webIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_website, webPending)

            // Instagram -> opens the browser to the Instagram profile
            val instagramIntent = Intent(Intent.ACTION_VIEW, Uri.parse(context.getString(R.string.instagram_url)))
            val instagramPending = PendingIntent.getActivity(
                context, 7, instagramIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_instagram, instagramPending)

            // Refresh button -> broadcasts ACTION_TICK the same way the
            // scheduled alarm does, so tapping it does exactly what a normal
            // tick does: recompute every color right now and reschedule the
            // next one. Explicitly targeted at TickReceiver (rather than an
            // implicit, package-scoped intent) both for reliable resolution
            // and because TickReceiver requires the signature-level TICK
            // permission — an implicit intent wouldn't resolve to it any
            // more predictably than an explicit one here, and explicit is
            // clearer about which receiver actually owns this action now.
            val refreshIntent = Intent(ACTION_TICK, null, context, TickReceiver::class.java)
                .putExtra(EXTRA_MANUAL, true)
            val refreshPending = PendingIntent.getBroadcast(
                context, 6, refreshIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_refresh, refreshPending)

            return views
        }

        private fun allSectionsIntent(context: Context, snapshot: WidgetSnapshot, requestCode: Int): PendingIntent {
            val intent = Intent(context, DescriptionActivity::class.java).apply {
                putExtra(DescriptionActivity.EXTRA_TIME_LEVEL, snapshot.timeLevel.name)
                putExtra(DescriptionActivity.EXTRA_DATE_LEVEL, snapshot.dateLevel.name)
                putExtra(DescriptionActivity.EXTRA_DAY_LEVEL, snapshot.dayLevel.name)
                putExtra(DescriptionActivity.EXTRA_MONTH_LEVEL, snapshot.monthLevel.name)
                putExtra(DescriptionActivity.EXTRA_YEAR_LEVEL, snapshot.yearLevel.name)
                putExtra(DescriptionActivity.EXTRA_SUN_LEVEL, snapshot.sunLevel.name)
                putExtra(DescriptionActivity.EXTRA_MOON_LEVEL, snapshot.moonLevel.name)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            return PendingIntent.getActivity(
                context, requestCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        /**
         * Rebuilds and pushes fresh RemoteViews to every placed instance of
         * all three widget types (1x1, 2x1, 1x2) — a user could have any
         * combination of them placed at once. Each type gets its own
         * buildRemoteViews() call since 1x2 uses a different layout.
         */
        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            for (cls in allProviderClasses) {
                val ids = manager.getAppWidgetIds(ComponentName(context, cls))
                if (ids.isNotEmpty()) {
                    manager.updateAppWidget(ids, buildRemoteViews(context, cls))
                }
            }
        }

        /**
         * Schedules a single exact alarm for the earliest moment any displayed
         * color would actually change: the next top-of-hour *in the device's
         * local time zone* (not UTC — the hour/date used for coloring comes
         * from the device's local clock, so scheduling by UTC hour boundaries
         * would fire up to ~30-60 minutes off for any zone with a non-whole-hour
         * UTC offset, e.g. India at UTC+5:30), or, if sooner, the exact instant
         * the Sun or Moon crosses into a new sign today (that part of the
         * ephemeris math is inherently UTC-based, which is fine — it's
         * converted to an absolute instant either way before comparing).
         *
         * The alarm's intent explicitly targets TickReceiver, the sole
         * ACTION_TICK receiver now (previously this was implicit/package-
         * scoped since any of the three widget types' own receivers could
         * be the one registered — that's no longer the case now that
         * ACTION_TICK lives on its own dedicated, permission-protected
         * receiver rather than on the widget receivers themselves; see
         * TickReceiver and AndroidManifest.xml).
         */
        fun scheduleNextTick(context: Context) {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return

            val localZone = ZoneId.systemDefault()
            val nowLocal = LocalDateTime.now(localZone)
            val nextLocalHour = nowLocal.withMinute(0).withSecond(0).withNano(0).plusHours(1)
            val nextHourMillis = nextLocalHour.atZone(localZone).toInstant().toEpochMilli()

            val nowUtc = LocalDateTime.now(ZoneId.of("UTC"))
            val sunCrossingMillis = EphemerisRepository.nextSignCrossing(context, nowUtc) { it.sunDegrees }
                ?.atZone(ZoneId.of("UTC"))?.toInstant()?.toEpochMilli()
            val moonCrossingMillis = EphemerisRepository.nextSignCrossing(context, nowUtc) { it.moonDegrees }
                ?.atZone(ZoneId.of("UTC"))?.toInstant()?.toEpochMilli()

            // nextHourMillis is always present, so this list is never empty —
            // minOrNull()!! is used instead of the plain min() extension,
            // which has had inconsistent availability across Kotlin stdlib
            // versions (deprecated as an error in some releases).
            val triggerAt = listOfNotNull(nextHourMillis, sunCrossingMillis, moonCrossingMillis).minOrNull()!!

            val intent = Intent(ACTION_TICK, null, context, TickReceiver::class.java)
            val pending = PendingIntent.getBroadcast(
                context, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val canScheduleExact = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                alarmManager.canScheduleExactAlarms()
            } else {
                true
            }

            if (canScheduleExact) {
                runCatching {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC, triggerAt, pending)
                }.onFailure {
                    alarmManager.set(AlarmManager.RTC, triggerAt, pending)
                }
            } else {
                // User hasn't granted the "Alarms & reminders" special access on
                // Android 13+. Fall back to an inexact wake — the widget still
                // refreshes, just without to-the-second precision, and it'll
                // catch up fully once the permission is granted (SettingsActivity
                // offers a shortcut to do that).
                alarmManager.set(AlarmManager.RTC, triggerAt, pending)
            }
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val views = buildRemoteViews(context, javaClass)
        appWidgetIds.forEach { id -> appWidgetManager.updateAppWidget(id, views) }
        scheduleNextTick(context)
    }

    override fun onEnabled(context: Context) {
        scheduleNextTick(context)
    }
    // No onReceive override needed anymore — ACTION_TICK no longer reaches
    // this class at all (see TickReceiver, and AndroidManifest.xml), so the
    // default AppWidgetProvider dispatch (onUpdate/onEnabled/etc.) is enough.
}
