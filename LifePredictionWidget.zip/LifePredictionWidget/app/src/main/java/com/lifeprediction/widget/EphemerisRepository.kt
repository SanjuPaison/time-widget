package com.lifeprediction.widget

import android.content.Context
import java.time.LocalDate
import java.time.LocalDateTime

data class SunMoonLongitude(val sunDegrees: Double, val moonDegrees: Double)

/**
 * Reads assets/sun_moon_1940_2060.tsv (Date, Sun, Moon ecliptic longitude in
 * degrees, one row per UTC midnight), trimmed from the supplied
 * ephemeris_1940_2060.txt down to just the two columns this app needs.
 * 1940-01-01 .. 2060-12-31.
 */
object EphemerisRepository {

    private const val ASSET_NAME = "sun_moon_1940_2060.tsv"
    private var cache: HashMap<LocalDate, SunMoonLongitude>? = null

    @Synchronized
    private fun load(context: Context): HashMap<LocalDate, SunMoonLongitude> {
        cache?.let { return it }
        val map = HashMap<LocalDate, SunMoonLongitude>(45000)
        context.assets.open(ASSET_NAME).bufferedReader().useLines { lines ->
            lines.forEachIndexed { index, line ->
                if (index == 0 || line.isBlank()) return@forEachIndexed
                val parts = line.split('\t')
                if (parts.size < 3) return@forEachIndexed
                val date = runCatching { LocalDate.parse(parts[0]) }.getOrNull() ?: return@forEachIndexed
                val sun = parts[1].toDoubleOrNull() ?: return@forEachIndexed
                val moon = parts[2].toDoubleOrNull() ?: return@forEachIndexed
                map[date] = SunMoonLongitude(sun, moon)
            }
        }
        cache = map
        return map
    }

    /** Exact midnight-UTC row for [date] if it falls in the bundled 1940-2060 table, else null. */
    fun lookup(context: Context, date: LocalDate): SunMoonLongitude? = load(context)[date]

    /** Shortest angular distance from [from] to [to], in the range (-180, 180]. */
    private fun angularDelta(from: Double, to: Double): Double {
        var d = (to - from) % 360.0
        if (d > 180.0) d -= 360.0
        if (d <= -180.0) d += 360.0
        return d
    }

    private fun normalize(deg: Double): Double {
        var d = deg % 360.0
        if (d < 0) d += 360.0
        return d
    }

    /**
     * Sun/Moon longitude at an exact UTC instant, linearly interpolated between
     * the bundled midnight-UTC rows for that day and the next (wraparound-safe
     * at the 0/360 boundary). This is what makes the Moon sign accurate for a
     * specific birth *time*, not just a birth date — the Moon moves roughly
     * 13 degrees a day, enough to change sign within a single day.
     */
    fun interpolatedLongitude(context: Context, utc: LocalDateTime): SunMoonLongitude? {
        val day0 = utc.toLocalDate()
        val day1 = day0.plusDays(1)
        val row0 = lookup(context, day0) ?: return null
        val row1 = lookup(context, day1) ?: row0 // last day in table: hold flat rather than fail

        val fraction = (utc.hour * 3600 + utc.minute * 60 + utc.second) / 86400.0

        val sun = normalize(row0.sunDegrees + angularDelta(row0.sunDegrees, row1.sunDegrees) * fraction)
        val moon = normalize(row0.moonDegrees + angularDelta(row0.moonDegrees, row1.moonDegrees) * fraction)
        return SunMoonLongitude(sun, moon)
    }

    fun sunSign(context: Context, date: LocalDate): String {
        lookup(context, date)?.let { return signForDegree(it.sunDegrees) }
        return sunSignForCalendarDate(date.monthValue, date.dayOfMonth)
    }

    fun moonSign(context: Context, date: LocalDate): String {
        lookup(context, date)?.let { return signForDegree(it.moonDegrees) }
        // Outside the bundled table the Moon can't be approximated sensibly
        // (it changes sign every ~2.5 days); fall back to the Sun sign rather
        // than showing a wrong value with false confidence.
        return sunSignForCalendarDate(date.monthValue, date.dayOfMonth)
    }

    /** Exact-time sign lookups, given a UTC instant. Falls back to date-only if out of table range. */
    fun sunSignAt(context: Context, utc: LocalDateTime): String {
        interpolatedLongitude(context, utc)?.let { return signForDegree(it.sunDegrees) }
        return sunSignForCalendarDate(utc.monthValue, utc.dayOfMonth)
    }

    fun moonSignAt(context: Context, utc: LocalDateTime): String {
        interpolatedLongitude(context, utc)?.let { return signForDegree(it.moonDegrees) }
        return sunSignForCalendarDate(utc.monthValue, utc.dayOfMonth)
    }
}
