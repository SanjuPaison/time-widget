package com.lifeprediction.widget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.widget.RemoteViews
import java.time.LocalDateTime
import java.time.ZoneId

/**
 * Base widget logic, shared by three separate manifest-declared receivers —
 * ZodiacWidgetProvider1x1/2x1/1x2 — each a trivial subclass with no code of
 * its own, existing purely so the widget picker shows three distinct, fixed-
 * size entries ("like other Android apps") instead of one resizable widget.
 * 1x1 and 2x1 share one layout (Sun/Moon side by side); 1x2 uses a separate
 * layout (Sun/Moon stacked vertically, since it's a single column wide) —
 * see layoutResFor().
 *
 * The widget's own "refresh now" tick (ACTION_TICK) is deliberately NOT
 * handled here or in the manifest intent-filter for these three receivers —
 * it lives entirely on the separate, non-exported TickReceiver, since these
 * three must stay exported="true" for the system to deliver
 * APPWIDGET_UPDATE, and an exported receiver can always be reached by an
 * explicit intent from any other app regardless of its intent-filter
 * contents. See TickReceiver's doc comment for the full reasoning.
 *
 * Colors are refreshed at the *exact second* they should change, not on a
 * fixed timer: every wake-up computes the earliest of (a) the next top-of-hour
 * (covers the Time box, and Date/Day/Month/Year at midnight since midnight is
 * also an hour boundary), (b) the next Sun-sign crossing, and (c) the next
 * Moon-sign crossing — then schedules a single exact alarm for whichever is
 * soonest, and repeats. Each wake is a handful of milliseconds of work, and
 * there are at most a few dozen of these a day (an hourly one, plus the rare
 * Sun/Moon sign changes), so this stays cheap even though it's precise.
 */
open class ZodiacWidgetProvider : AppWidgetProvider() {

    companion object {

        /** The three concrete, manifest-declared widget types. */
        private val allProviderClasses = listOf(
            ZodiacWidgetProvider1x1::class.java,
            ZodiacWidgetProvider2x1::class.java,
            ZodiacWidgetProvider1x2::class.java
        )

        /** 1x2 is a single column wide, so it uses the stacked-Sun/Moon layout;
         *  1x1 and 2x1 share the side-by-side layout. */
        private fun layoutResFor(providerClass: Class<out ZodiacWidgetProvider>): Int =
            if (providerClass == ZodiacWidgetProvider1x2::class.java) R.layout.widget_zodiac_tall
            else R.layout.widget_zodiac

        private fun colorFor(level: LuckLevel, context: Context): Int = when (level) {
            LuckLevel.LUCKY -> context.getColor(R.color.luck_lucky)
            LuckLevel.UNLUCKY -> context.getColor(R.color.luck_unlucky)
            LuckLevel.AVERAGE -> context.getColor(R.color.luck_average)
        }

        /** Short live context line shown under the gem's name/tier on the
         *  tap-through screen — the specific reading each gem measures. */
        private fun subtitleFor(gem: Gem, snapshot: WidgetSnapshot): String = when (gem) {
            Gem.QUARTZ -> "${snapshot.hour12} o'clock"
            Gem.AMETHYST -> "Day ${snapshot.date.dayOfMonth}"
            Gem.TOPAZ -> "Moon in ${snapshot.transitingMoonSign} ${symbolFor(snapshot.transitingMoonSign)}"
            Gem.JADE -> "Sun in ${snapshot.transitingSunSign} ${symbolFor(snapshot.transitingSunSign)}"
            Gem.SAPPHIRE -> snapshot.date.month.name.lowercase().replaceFirstChar { it.uppercase() }
            Gem.EMERALD -> {
                val day = snapshot.date.dayOfMonth
                val month = snapshot.date.month.name.take(3)
                val year = snapshot.date.year
                "$day $month $year"
            }
            Gem.RUBY -> snapshot.date.year.toString()
            Gem.DIAMOND -> snapshot.phaseEra.label
        }

        /** Sets the ring border, glyph+count text (fixed gem color), and tap
         *  target for one gem box — called once per gem in buildRemoteViews. */
        private fun applyGem(
            views: RemoteViews,
            context: Context,
            gem: Gem,
            boxId: Int,
            bgId: Int,
            textId: Int,
            requestCode: Int,
            snapshot: WidgetSnapshot
        ) {
            val level = GemLedger.levelFor(gem, snapshot)
            val count = level.gemCount()
            views.setTextViewText(textId, "\u25C6 $count")
            views.setTextColor(textId, context.getColor(gem.colorRes))
            views.setInt(bgId, "setColorFilter", colorFor(level, context))
            views.setOnClickPendingIntent(boxId, descriptionIntent(context, gem, level, subtitleFor(gem, snapshot), requestCode))
        }

        fun buildRemoteViews(context: Context, providerClass: Class<out ZodiacWidgetProvider>): RemoteViews {
            val views = RemoteViews(context.packageName, layoutResFor(providerClass))
            val snapshot = LuckCalculator.buildSnapshot(context)

            // Background: user's chosen color+texture from Settings (default:
            // brown translucent). setInt(...,"setBackgroundResource",...) swaps
            // the whole drawable, not just a tint, since Parchment/Stars are
            // fundamentally different shapes/layers, not just recolors.
            views.setInt(R.id.widget_root, "setBackgroundResource", BackgroundPrefs.drawableResId(context))

            // BORDER — whole-widget ring tinted by the day's overall luck
            // (dateLevel), same setColorFilter technique as the Sun/Moon boxes.
            views.setInt(R.id.widget_border, "setColorFilter", colorFor(snapshot.dateLevel, context))

            // TOTAL VALUE — sum of all 8 gems' (value x count) for this snapshot.
            val total = GemLedger.totalValue(snapshot)
            views.setTextViewText(R.id.widget_total_text, "\u25C6 $" + "%,d".format(total))

            // GEM GRID — 8 boxes, each: fixed gem-colored glyph+count, ring
            // border tinted per level, tap -> description popup for that gem.
            applyGem(views, context, Gem.QUARTZ, R.id.widget_gem_quartz_box, R.id.widget_gem_quartz_bg, R.id.widget_gem_quartz_text, 10, snapshot)
            applyGem(views, context, Gem.AMETHYST, R.id.widget_gem_amethyst_box, R.id.widget_gem_amethyst_bg, R.id.widget_gem_amethyst_text, 11, snapshot)
            applyGem(views, context, Gem.TOPAZ, R.id.widget_gem_topaz_box, R.id.widget_gem_topaz_bg, R.id.widget_gem_topaz_text, 12, snapshot)
            applyGem(views, context, Gem.JADE, R.id.widget_gem_jade_box, R.id.widget_gem_jade_bg, R.id.widget_gem_jade_text, 13, snapshot)
            applyGem(views, context, Gem.SAPPHIRE, R.id.widget_gem_sapphire_box, R.id.widget_gem_sapphire_bg, R.id.widget_gem_sapphire_text, 14, snapshot)
            applyGem(views, context, Gem.EMERALD, R.id.widget_gem_emerald_box, R.id.widget_gem_emerald_bg, R.id.widget_gem_emerald_text, 15, snapshot)
            applyGem(views, context, Gem.RUBY, R.id.widget_gem_ruby_box, R.id.widget_gem_ruby_bg, R.id.widget_gem_ruby_text, 16, snapshot)
            applyGem(views, context, Gem.DIAMOND, R.id.widget_gem_diamond_box, R.id.widget_gem_diamond_bg, R.id.widget_gem_diamond_text, 17, snapshot)

            // Website -> opens the browser (no INTERNET permission needed here;
            // the browser app does the actual network fetch, not us)
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse(context.getString(R.string.website_url)))
            val webPending = PendingIntent.getActivity(
                context, 5, webIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_website, webPending)

            // Instagram -> opens the browser to the Instagram profile
            val instagramIntent = Intent(Intent.ACTION_VIEW, Uri.parse(context.getString(R.string.instagram_url)))
            val instagramPending = PendingIntent.getActivity(
                context, 7, instagramIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_instagram, instagramPending)

            // Refresh button -> broadcasts ACTION_TICK to TickReceiver, the
            // same non-exported component the scheduled alarm targets (see
            // TickReceiver's doc comment for why this isn't sent to the
            // widget provider classes themselves). Explicitly targeted by
            // component so delivery doesn't depend on any intent-filter
            // matching. EXTRA_MANUAL flags this as a user tap so
            // TickReceiver can show a one-off confirmation, since colors
            // only visibly change at an actual hour/sign boundary and a
            // silent recompute can otherwise look like the button did
            // nothing.
            val refreshIntent = Intent(TickReceiver.ACTION_TICK, null, context, TickReceiver::class.java)
                .putExtra(TickReceiver.EXTRA_MANUAL, true)
            val refreshPending = PendingIntent.getBroadcast(
                context, 6, refreshIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_refresh, refreshPending)

            return views
        }

        private fun descriptionIntent(context: Context, gem: Gem, level: LuckLevel, subtitle: String, requestCode: Int): PendingIntent {
            val intent = Intent(context, DescriptionActivity::class.java).apply {
                putExtra(DescriptionActivity.EXTRA_GEM, gem.name)
                putExtra(DescriptionActivity.EXTRA_LEVEL, level.name)
                putExtra(DescriptionActivity.EXTRA_SUBTITLE, subtitle)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            return PendingIntent.getActivity(
                context, requestCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        /**
         * Rebuilds and pushes fresh RemoteViews to every placed instance of
         * all three widget types (1x1, 2x1, 1x2) — a user could have any
         * combination of them placed at once. Each type gets its own
         * buildRemoteViews() call since 1x2 uses a different layout.
         */
        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            for (cls in allProviderClasses) {
                val ids = manager.getAppWidgetIds(ComponentName(context, cls))
                if (ids.isNotEmpty()) {
                    manager.updateAppWidget(ids, buildRemoteViews(context, cls))
                }
            }
        }

        /**
         * Schedules a single exact alarm for the earliest moment any displayed
         * color would actually change: the next top-of-hour *in the device's
         * local time zone* (not UTC — the hour/date used for coloring comes
         * from the device's local clock, so scheduling by UTC hour boundaries
         * would fire up to ~30-60 minutes off for any zone with a non-whole-hour
         * UTC offset, e.g. India at UTC+5:30), or, if sooner, the exact instant
         * the Sun or Moon crosses into a new sign today (that part of the
         * ephemeris math is inherently UTC-based, which is fine — it's
         * converted to an absolute instant either way before comparing).
         *
         * The alarm targets TickReceiver explicitly (see its doc comment) —
         * a single component regardless of which of the three widget types
         * is actually placed, since TickReceiver.onReceive calls
         * ZodiacWidgetProvider.updateAll(), which itself loops over all
         * three and only pushes updates to the ones with placed instances.
         */
        fun scheduleNextTick(context: Context) {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return

            val localZone = ZoneId.systemDefault()
            val nowLocal = LocalDateTime.now(localZone)
            val nextLocalHour = nowLocal.withMinute(0).withSecond(0).withNano(0).plusHours(1)
            val nextHourMillis = nextLocalHour.atZone(localZone).toInstant().toEpochMilli()

            val nowUtc = LocalDateTime.now(ZoneId.of("UTC"))
            val sunCrossingMillis = EphemerisRepository.nextSignCrossing(context, nowUtc) { it.sunDegrees }
                ?.atZone(ZoneId.of("UTC"))?.toInstant()?.toEpochMilli()
            val moonCrossingMillis = EphemerisRepository.nextSignCrossing(context, nowUtc) { it.moonDegrees }
                ?.atZone(ZoneId.of("UTC"))?.toInstant()?.toEpochMilli()

            // nextHourMillis is always present, so this list is never empty —
            // minOrNull()!! is used instead of the plain min() extension,
            // which has had inconsistent availability across Kotlin stdlib
            // versions (deprecated as an error in some releases).
            val triggerAt = listOfNotNull(nextHourMillis, sunCrossingMillis, moonCrossingMillis).minOrNull()!!

            val intent = Intent(TickReceiver.ACTION_TICK, null, context, TickReceiver::class.java)
            val pending = PendingIntent.getBroadcast(
                context, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val canScheduleExact = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                alarmManager.canScheduleExactAlarms()
            } else {
                true
            }

            if (canScheduleExact) {
                runCatching {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC, triggerAt, pending)
                }.onFailure {
                    alarmManager.set(AlarmManager.RTC, triggerAt, pending)
                }
            } else {
                // User hasn't granted the "Alarms & reminders" special access on
                // Android 13+. Fall back to an inexact wake — the widget still
                // refreshes, just without to-the-second precision, and it'll
                // catch up fully once the permission is granted (SettingsActivity
                // offers a shortcut to do that).
                alarmManager.set(AlarmManager.RTC, triggerAt, pending)
            }
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val views = buildRemoteViews(context, javaClass)
        appWidgetIds.forEach { id -> appWidgetManager.updateAppWidget(id, views) }
        scheduleNextTick(context)
    }

    override fun onEnabled(context: Context) {
        scheduleNextTick(context)
    }

    // No onReceive override needed anymore — ACTION_TICK now lives entirely
    // on TickReceiver (see its doc comment for why), so this class only
    // ever needs AppWidgetProvider's own default handling of
    // APPWIDGET_UPDATE/ENABLED/etc., which onUpdate/onEnabled above already
    // hook into normally.
}
