package com.lifeprediction.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.RemoteViews

/**
 * No AlarmManager / exact-alarm scheduling here on purpose: the colors on this
 * widget only need to be roughly right (hour/day granularity), so it relies
 * entirely on the ordinary widget update cycle declared in
 * res/xml/widget_zodiac_info.xml (updatePeriodMillis). That needs no special
 * permission at all — SCHEDULE_EXACT_ALARM / USE_EXACT_ALARM would be
 * overkill for this and are the kind of permission Play Store review pushes
 * back on unless the app is genuinely an alarm/clock/calendar app.
 */
class ZodiacWidgetProvider : AppWidgetProvider() {

    companion object {

        private fun colorFor(level: LuckLevel, context: Context): Int = when (level) {
            LuckLevel.LUCKY -> context.getColor(R.color.luck_lucky)
            LuckLevel.UNLUCKY -> context.getColor(R.color.luck_unlucky)
            LuckLevel.AVERAGE -> context.getColor(R.color.luck_average)
        }

        fun buildRemoteViews(context: Context): RemoteViews {
            val views = RemoteViews(context.packageName, R.layout.widget_zodiac)
            val snapshot = LuckCalculator.buildSnapshot(context)

            // TIME — its own colored box (by hour), text always white
            views.setInt(R.id.widget_time_bg, "setColorFilter", colorFor(snapshot.timeLevel, context))

            // SUN box
            views.setTextViewText(
                R.id.widget_sun_text,
                "\u2600 " + symbolFor(snapshot.transitingSunSign)
            )
            views.setInt(R.id.widget_sun_bg, "setColorFilter", colorFor(snapshot.sunLevel, context))

            // MOON box
            views.setTextViewText(
                R.id.widget_moon_text,
                "\uD83C\uDF19 " + symbolFor(snapshot.transitingMoonSign)
            )
            views.setInt(R.id.widget_moon_bg, "setColorFilter", colorFor(snapshot.moonLevel, context))

            // DATE box + day/month/year text, each colored per its own reduced digit
            views.setInt(R.id.widget_date_bg, "setColorFilter", colorFor(snapshot.dateLevel, context))
            views.setTextViewText(R.id.widget_date_day, snapshot.date.dayOfMonth.toString())
            views.setTextColor(R.id.widget_date_day, colorFor(snapshot.dayLevel, context))
            views.setTextViewText(R.id.widget_date_month, snapshot.date.month.name.take(3))
            views.setTextColor(R.id.widget_date_month, colorFor(snapshot.monthLevel, context))
            views.setTextViewText(R.id.widget_date_year, snapshot.date.year.toString())
            views.setTextColor(R.id.widget_date_year, colorFor(snapshot.yearLevel, context))

            // Click targets -> description popups
            views.setOnClickPendingIntent(R.id.widget_time_box, descriptionIntent(context, Section.TIME, snapshot.timeLevel, 1))
            views.setOnClickPendingIntent(R.id.widget_sun_box, descriptionIntent(context, Section.SUN, snapshot.sunLevel, 2))
            views.setOnClickPendingIntent(R.id.widget_moon_box, descriptionIntent(context, Section.MOON, snapshot.moonLevel, 3))
            views.setOnClickPendingIntent(R.id.widget_date_box, descriptionIntent(context, Section.DATE, snapshot.dateLevel, 4))

            // Website -> opens the browser (no INTERNET permission needed here;
            // the browser app does the actual network fetch, not us)
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse(context.getString(R.string.website_url)))
            val webPending = PendingIntent.getActivity(
                context, 5, webIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_website, webPending)

            return views
        }

        private fun descriptionIntent(context: Context, section: Section, level: LuckLevel, requestCode: Int): PendingIntent {
            val intent = Intent(context, DescriptionActivity::class.java).apply {
                putExtra(DescriptionActivity.EXTRA_SECTION, section.name)
                putExtra(DescriptionActivity.EXTRA_LEVEL, level.name)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            return PendingIntent.getActivity(
                context, requestCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        /** Rebuilds and pushes fresh RemoteViews to every placed instance of this widget. */
        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, ZodiacWidgetProvider::class.java))
            if (ids.isEmpty()) return
            val views = buildRemoteViews(context)
            manager.updateAppWidget(ids, views)
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val views = buildRemoteViews(context)
        appWidgetIds.forEach { id -> appWidgetManager.updateAppWidget(id, views) }
    }
}
