# Lucky Stars

A home-screen widget (1x1, 2x1, and 1x2 sizes) showing the current time,
transiting Sun/Moon zodiac signs, today's date, and a 14-star luck field,
all color-coded lucky/average/unlucky per the Book of Luck / Pluto Phases
system, based on your birth date, time, place, and gender (Settings screen).
Tap anywhere on the widget for the full reading (Hour, Date, Day, Month,
Year, Sun, Moon).

This build's applicationId (`com.lifeprediction.luckystars`) is deliberately
different from the original app (`com.lifeprediction.widget`), so installing
this one won't overwrite or conflict with it — they run side by side as two
separate apps.

## Building this on a tablet (no computer needed)

You can't run Android Studio on a tablet, but GitHub can build the APK for
you for free. This repo includes `.github/workflows/build.yml` set up to do
that.

1. **Create a GitHub account** if you don't have one (github.com, works fine
   in a tablet browser).
2. **Create a new repository** (any name, e.g. `lucky-stars-widget`).
   Choose "Add files" → **"Upload files"**, then upload everything from this
   unzipped folder (or use the GitHub mobile app / a file manager with a Git
   client like Working Copy on iPad, or Termux + git on Android, if you'd
   rather push via command line).
3. Once the files are in the repo, go to the **"Actions"** tab. A workflow
   run should start automatically (or click **"Run workflow"** if it
   doesn't).
4. Wait for the green checkmark (a few minutes).
5. Open the finished run, scroll to **"Artifacts"**, and download
   **`LuckyStars-debug-apk`**. It downloads as a `.zip` containing
   `app-debug.apk`.
6. On your tablet, open that zip with your file manager, extract
   `app-debug.apk`, and tap it to install (Android will prompt you to allow
   installs from this source the first time — that's normal for an app not
   from the Play Store).
7. Long-press your home screen → **Widgets** → **Lucky Stars** → drag your
   preferred size onto your home screen.
8. Tap anywhere on the widget → **Settings** (link at the bottom of the
   reading screen) to enter your birth date, time, place, and gender.

## What's inside

- `app/src/main/java/com/lifeprediction/widget/` — all the Kotlin logic
  (ephemeris lookup, Book of Luck / Pluto Phase tables, numerology, the
  widget provider, the internal-tick receiver, Settings, and the reading
  screen).
- `app/src/main/res/` — widget layouts (portrait/landscape × normal/tall),
  colors, strings.
- `app/src/main/assets/sun_moon_1940_2060.tsv` — daily Sun/Moon ecliptic
  longitude table (1940-2060), trimmed from the ephemeris file you provided.
- `.github/workflows/build.yml` — the cloud build described above.

No Gradle wrapper jar is bundled (couldn't be generated offline), so the CI
workflow installs Gradle directly rather than using `./gradlew`. If you later
build this on an actual computer with Android Studio, just open the folder
there — Android Studio will regenerate the wrapper for you automatically.

## Permissions

- `SCHEDULE_EXACT_ALARM` — refreshes are scheduled for the *exact* moment a
  color would change (top of the hour, or a Sun/Moon sign crossing), not on
  a fixed timer. Auto-granted on Android 12-12L; needs a one-time toggle on
  Android 13+ (Settings screen offers a shortcut, and the app falls back to
  an inexact refresh if it's not granted, rather than nagging).
- `RECEIVE_BOOT_COMPLETED` — re-arms that alarm after a restart, since
  AlarmManager alarms don't survive a reboot on their own.
- `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS` — lets the app show the system's
  standard opt-in dialog for exemption (it can't silently exempt itself);
  Google Play's policy explicitly allows this for widgets that regularly
  update their content.
- A custom, app-only signature-level permission gates the internal refresh
  broadcast so no other installed app can trigger it.

No network permission is requested — tapping the website/Instagram lines
just hands the URL to your browser, which does its own networking.
