package com.lifeprediction.widget

enum class Section { TIME, DATE, SUN, MOON }

object Descriptions {

    fun title(section: Section): String = when (section) {
        Section.TIME -> "This hour"
        Section.DATE -> "Today"
        Section.SUN -> "Sun sign"
        Section.MOON -> "Moon sign"
    }

    fun text(section: Section, level: LuckLevel): String = when (section) {
        Section.DATE -> when (level) {
            LuckLevel.LUCKY -> "Today supports steady career and financial progress. It's the time to increase income, finalize agreements, or move forward with projects that have clear value."
            LuckLevel.AVERAGE -> "Today carries strong energy for action, communication, and ideas, which can express through creativity, collaboration or confrontation depending on caution and restraint."
            LuckLevel.UNLUCKY -> "This day favors caution, privacy, and consolidation rather than outward progress. Be wary of bad luck, deception and manage emotional turmoil."
        }
        Section.TIME -> when (level) {
            LuckLevel.LUCKY -> "This hour falls on one of your lucky numbers for the current era. A good hour to act, ask, or move something forward."
            LuckLevel.AVERAGE -> "This hour isn't one of your marked lucky or unlucky numbers right now. A neutral hour — neither favored nor disfavored."
            LuckLevel.UNLUCKY -> "This hour falls on one of your unlucky numbers for the current era. Better to wait than to push forward right now."
        }
        Section.SUN -> when (level) {
            LuckLevel.LUCKY -> "Today's Sun sign is one of your lucky signs for the current era. A favorable day to put yourself forward or start something new."
            LuckLevel.AVERAGE -> "Today's Sun sign isn't among your marked lucky or unlucky signs right now. A neutral day — neither favored nor disfavored."
            LuckLevel.UNLUCKY -> "Today's Sun sign is one of your unlucky signs for the current era. Favor caution over bold moves today."
        }
        Section.MOON -> when (level) {
            LuckLevel.LUCKY -> "Today's Moon sign is one of your lucky signs for the current era. A favorable day for close relationships and personal matters."
            LuckLevel.AVERAGE -> "Today's Moon sign isn't among your marked lucky or unlucky signs right now. A neutral day — neither favored nor disfavored."
            LuckLevel.UNLUCKY -> "Today's Moon sign is one of your unlucky signs for the current era. Be careful with emotional decisions today."
        }
    }
}
