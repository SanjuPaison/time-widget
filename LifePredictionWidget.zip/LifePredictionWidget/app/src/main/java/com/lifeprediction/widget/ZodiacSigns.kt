package com.lifeprediction.widget

/** The 12 zodiac signs, Aries=0 .. Pisces=11 — matches the source files exactly. */
val ZODIAC_SIGNS = listOf(
    "Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo",
    "Libra", "Scorpio", "Sagittarius", "Capricorn", "Aquarius", "Pisces"
)

fun signIndexOf(signName: String): Int = ZODIAC_SIGNS.indexOf(signName)

/**
 * Ecliptic longitude (0-360 degrees) -> tropical zodiac sign, 30 degrees per sign
 * starting at Aries 0°.
 */
fun signForDegree(longitude: Double): String {
    var deg = longitude % 360.0
    if (deg < 0) deg += 360.0
    val idx = (deg / 30.0).toInt().coerceIn(0, 11)
    return ZODIAC_SIGNS[idx]
}

/**
 * Fallback tropical Sun sign purely from a calendar month/day, used when there is
 * no ephemeris row for a date (e.g. a birth date far outside the bundled table).
 * Boundaries are the conventional ones; the ephemeris table is used whenever
 * available since it is exact for any given day rather than approximate.
 */
fun sunSignForCalendarDate(month: Int, day: Int): String = when {
    (month == 3 && day >= 21) || (month == 4 && day <= 19) -> "Aries"
    (month == 4 && day >= 20) || (month == 5 && day <= 20) -> "Taurus"
    (month == 5 && day >= 21) || (month == 6 && day <= 20) -> "Gemini"
    (month == 6 && day >= 21) || (month == 7 && day <= 22) -> "Cancer"
    (month == 7 && day >= 23) || (month == 8 && day <= 22) -> "Leo"
    (month == 8 && day >= 23) || (month == 9 && day <= 22) -> "Virgo"
    (month == 9 && day >= 23) || (month == 10 && day <= 22) -> "Libra"
    (month == 10 && day >= 23) || (month == 11 && day <= 21) -> "Scorpio"
    (month == 11 && day >= 22) || (month == 12 && day <= 21) -> "Sagittarius"
    (month == 12 && day >= 22) || (month == 1 && day <= 19) -> "Capricorn"
    (month == 1 && day >= 20) || (month == 2 && day <= 18) -> "Aquarius"
    else -> "Pisces"
}
