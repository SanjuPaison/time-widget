package com.lifeprediction.widget

data class LuckTriple<T>(val first: T, val second: T, val third: T) {
    fun toList(): List<T> = listOf(first, second, third)
}

/**
 * Reproduces the "Book of Luck" (Sanju Paison) tables for lucky/unlucky colors,
 * numbers, and people, keyed by zodiac sign and Pluto Phase era. Verbatim from
 * BookOfLuck_source.txt.
 */
object BookOfLuck {

    private val colorCycle: List<LuckTriple<String>> = listOf(
        LuckTriple("red", "gold", "purple"),
        LuckTriple("aquamarine", "white", "black"),
        LuckTriple("blue", "yellow", "pink"),
        LuckTriple("brown", "green", "tan"),
        LuckTriple("purple", "gold", "red"),
        LuckTriple("black", "aquamarine", "white"),
        LuckTriple("pink", "blue", "yellow"),
        LuckTriple("tan", "brown", "green"),
        LuckTriple("gold", "purple", "red"),
        LuckTriple("white", "black", "aquamarine"),
        LuckTriple("yellow", "pink", "blue"),
        LuckTriple("green", "tan", "brown")
    )

    private val numberCycle: List<LuckTriple<Int>> = listOf(
        LuckTriple(1, 5, 9),
        LuckTriple(12, 4, 8),
        LuckTriple(11, 3, 7),
        LuckTriple(10, 2, 6),
        LuckTriple(9, 1, 5),
        LuckTriple(8, 12, 4),
        LuckTriple(7, 11, 3),
        LuckTriple(6, 10, 2),
        LuckTriple(5, 9, 1),
        LuckTriple(4, 8, 12),
        LuckTriple(3, 7, 11),
        LuckTriple(2, 6, 10)
    )

    private val peopleCycle: List<LuckTriple<String>> = listOf(
        LuckTriple("Aries", "Leo", "Sagittarius"),
        LuckTriple("Pisces", "Cancer", "Scorpio"),
        LuckTriple("Aquarius", "Gemini", "Libra"),
        LuckTriple("Capricorn", "Taurus", "Virgo"),
        LuckTriple("Sagittarius", "Aries", "Leo"),
        LuckTriple("Scorpio", "Pisces", "Cancer"),
        LuckTriple("Libra", "Aquarius", "Gemini"),
        LuckTriple("Virgo", "Capricorn", "Taurus"),
        LuckTriple("Leo", "Sagittarius", "Aries"),
        LuckTriple("Cancer", "Scorpio", "Pisces"),
        LuckTriple("Gemini", "Libra", "Aquarius"),
        LuckTriple("Taurus", "Virgo", "Capricorn")
    )

    private fun cycleIndex(signIndex: Int, bookEraIndex: Int, offset: Int = 0): Int {
        var i = (bookEraIndex - signIndex + offset) % 12
        if (i < 0) i += 12
        return i
    }

    data class LuckProfile(
        val colors: List<String>,
        val numbers: List<Int>,
        val people: List<String>
    )

    fun lucky(signIndex: Int, bookEraIndex: Int): LuckProfile {
        val idx = cycleIndex(signIndex, bookEraIndex)
        return LuckProfile(colorCycle[idx].toList(), numberCycle[idx].toList(), peopleCycle[idx].toList())
    }

    fun unlucky(signIndex: Int, bookEraIndex: Int): LuckProfile {
        val idx = cycleIndex(signIndex, bookEraIndex, offset = 2)
        return LuckProfile(colorCycle[idx].toList(), numberCycle[idx].toList(), peopleCycle[idx].toList())
    }
}
