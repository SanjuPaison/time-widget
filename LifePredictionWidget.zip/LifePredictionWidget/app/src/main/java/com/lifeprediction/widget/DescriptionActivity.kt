package com.lifeprediction.widget

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * Combined reading screen. The whole widget is a single tap target now (see
 * ZodiacWidgetProvider) — there's no more per-section popup — so this always
 * shows all 7 tracked categories at once, each level passed in as its own
 * extra by the widget (computed once, at the moment of the tap, rather than
 * recomputed here, so what's shown always matches what was on-screen).
 */
class DescriptionActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_TIME_LEVEL = "extra_time_level"
        const val EXTRA_DATE_LEVEL = "extra_date_level"
        const val EXTRA_DAY_LEVEL = "extra_day_level"
        const val EXTRA_MONTH_LEVEL = "extra_month_level"
        const val EXTRA_YEAR_LEVEL = "extra_year_level"
        const val EXTRA_SUN_LEVEL = "extra_sun_level"
        const val EXTRA_MOON_LEVEL = "extra_moon_level"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_description)

        fun levelFrom(key: String): LuckLevel =
            runCatching { LuckLevel.valueOf(intent.getStringExtra(key) ?: LuckLevel.AVERAGE.name) }
                .getOrDefault(LuckLevel.AVERAGE)

        // Fixed display order: Hour, Date, Day, Month, Year, Sun, Moon.
        val sections = listOf(
            Section.TIME to levelFrom(EXTRA_TIME_LEVEL),
            Section.DATE to levelFrom(EXTRA_DATE_LEVEL),
            Section.DAY to levelFrom(EXTRA_DAY_LEVEL),
            Section.MONTH to levelFrom(EXTRA_MONTH_LEVEL),
            Section.YEAR to levelFrom(EXTRA_YEAR_LEVEL),
            Section.SUN to levelFrom(EXTRA_SUN_LEVEL),
            Section.MOON to levelFrom(EXTRA_MOON_LEVEL)
        )

        val container = findViewById<LinearLayout>(R.id.desc_sections_container)
        val inflater = LayoutInflater.from(this)
        val rowSpacingPx = (18 * resources.displayMetrics.density).toInt()

        sections.forEachIndexed { index, (section, level) ->
            val row = inflater.inflate(R.layout.item_description_row, container, false)
            row.findViewById<View>(R.id.row_badge).setBackgroundColor(colorFor(level))
            row.findViewById<TextView>(R.id.row_title).text = Descriptions.title(section)
            row.findViewById<TextView>(R.id.row_body).text = Descriptions.text(section, level)
            if (index > 0) {
                (row.layoutParams as? LinearLayout.LayoutParams)?.topMargin = rowSpacingPx
            }
            container.addView(row)
        }

        findViewById<TextView>(R.id.desc_settings_link).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
            finish()
        }

        findViewById<View>(android.R.id.content).setOnClickListener { finish() }
    }

    private fun colorFor(level: LuckLevel): Int = when (level) {
        LuckLevel.LUCKY -> getColor(R.color.luck_lucky)
        LuckLevel.UNLUCKY -> getColor(R.color.luck_unlucky)
        LuckLevel.AVERAGE -> getColor(R.color.luck_average)
    }
}
