package com.lifeprediction.widget

import kotlin.math.abs

object Numerology {
    /** Repeatedly sums digits until a single digit (1-9) remains. 0 maps to 9. */
    fun reduceToSingleDigit(number: Int): Int {
        var n = abs(number)
        if (n == 0) return 9
        while (n > 9) {
            var sum = 0
            var x = n
            while (x > 0) {
                sum += x % 10
                x /= 10
            }
            n = sum
        }
        return n
    }
}
