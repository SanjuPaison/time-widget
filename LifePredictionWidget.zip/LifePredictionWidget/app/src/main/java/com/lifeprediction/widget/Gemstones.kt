package com.lifeprediction.widget

/**
 * The eight elements are recast as gemstones for display. Each gem has a
 * fixed identity color (never changes) and a fixed dollar value; only the
 * *count* (0/1/2, from the day's LuckLevel) and the surrounding box border
 * change per refresh. Ordered here by ascending value, which also drives the
 * grid's reading order (see widget layout files) so the eye moves from the
 * common stones toward the rare Diamond.
 */
enum class Gem(
    val displayName: String,
    /** What this gem measures — shown as context in the tap-through screen. */
    val elementLabel: String,
    val valueUsd: Int,
    val colorRes: Int
) {
    QUARTZ("Quartz", "Time", 10, R.color.gem_quartz),
    AMETHYST("Amethyst", "Day", 50, R.color.gem_amethyst),
    TOPAZ("Topaz", "Moon Sign", 100, R.color.gem_topaz),
    JADE("Jade", "Sun Sign", 300, R.color.gem_jade),
    SAPPHIRE("Sapphire", "Month", 300, R.color.gem_sapphire),
    EMERALD("Emerald", "Date", 400, R.color.gem_emerald),
    RUBY("Ruby", "Year", 600, R.color.gem_ruby),
    DIAMOND("Diamond", "Phase", 5000, R.color.gem_diamond)
}

/** 0 stones for Dim (unlucky), 1 for Dormant (average), 2 for Charged (lucky). */
fun LuckLevel.gemCount(): Int = when (this) {
    LuckLevel.UNLUCKY -> 0
    LuckLevel.AVERAGE -> 1
    LuckLevel.LUCKY -> 2
}

data class GemEntry(val gem: Gem, val level: LuckLevel) {
    val count: Int get() = level.gemCount()
    val value: Int get() = gem.valueUsd * count
}

object GemLedger {

    /** One entry per gem, in element order (Time->Diamond/Phase), matching
     *  the corrected element-to-gem mapping: Time-Quartz, Day-Amethyst,
     *  Moon-Topaz, Sun-Jade, Month-Sapphire, Date-Emerald, Year-Ruby,
     *  Phase-Diamond. */
    fun entries(snapshot: WidgetSnapshot): List<GemEntry> = listOf(
        GemEntry(Gem.QUARTZ, snapshot.timeLevel),
        GemEntry(Gem.AMETHYST, snapshot.dayLevel),
        GemEntry(Gem.TOPAZ, snapshot.moonLevel),
        GemEntry(Gem.JADE, snapshot.sunLevel),
        GemEntry(Gem.SAPPHIRE, snapshot.monthLevel),
        GemEntry(Gem.EMERALD, snapshot.dateLevel),
        GemEntry(Gem.RUBY, snapshot.yearLevel),
        GemEntry(Gem.DIAMOND, snapshot.phaseLevel)
    )

    /** Same entries, sorted by ascending gem value — the grid's reading order. */
    fun gridOrder(snapshot: WidgetSnapshot): List<GemEntry> = entries(snapshot).sortedBy { it.gem.valueUsd }

    fun totalValue(snapshot: WidgetSnapshot): Int = entries(snapshot).sumOf { it.value }

    fun levelFor(gem: Gem, snapshot: WidgetSnapshot): LuckLevel =
        entries(snapshot).first { it.gem == gem }.level
}
