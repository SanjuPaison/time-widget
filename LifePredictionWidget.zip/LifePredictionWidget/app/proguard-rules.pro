# Add project specific ProGuard rules here.

# --- Manifest components ---
# The Android Gradle Plugin auto-generates an equivalent keep file from the
# merged manifest, so these are largely belt-and-suspenders — but explicit
# costs nothing and documents which classes the system instantiates by name
# (widget providers via AppWidgetManager, BootReceiver via BOOT_COMPLETED,
# activities via their manifest entries) rather than via normal Kotlin calls.
-keep public class com.lifeprediction.widget.ZodiacWidgetProvider1x1
-keep public class com.lifeprediction.widget.ZodiacWidgetProvider2x1
-keep public class com.lifeprediction.widget.ZodiacWidgetProvider1x2
-keep public class com.lifeprediction.widget.TickReceiver
-keep public class com.lifeprediction.widget.CarouselReceiver
-keep public class com.lifeprediction.widget.BootReceiver
-keep public class com.lifeprediction.widget.DescriptionActivity
-keep public class com.lifeprediction.widget.SettingsActivity

# --- Enum round-trips through Intent extras ---
# DescriptionActivity reads Gem/LuckLevel back out of Intent extras via
# valueOf(gem.name) — keep values()/valueOf() so that survives renaming.
# (proguard-android-optimize.txt already keeps this for all enums; scoped
# here to this app's package just to document the actual dependency.)
-keepclassmembers enum com.lifeprediction.widget.** {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

