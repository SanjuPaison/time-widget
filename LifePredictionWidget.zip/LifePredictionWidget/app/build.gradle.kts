plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.lifeprediction.widget"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.lifeprediction.widget.gems"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            // Renames classes/methods/fields to short meaningless names and
            // strips unused code — raises the bar against casual decompile
            // inspection, though it doesn't hide data (string/int literals,
            // like the BookOfLuck/PlutoPhaseTable tables, survive renaming
            // unchanged; only identifiers are obfuscated). See
            // proguard-rules.pro for what's explicitly kept and why.
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    // The ephemeris data file is plain text; make sure AAPT doesn't try to compress
    // it away oddly and that it is packaged as-is.
    androidResources {
        noCompress += "tsv"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
}
