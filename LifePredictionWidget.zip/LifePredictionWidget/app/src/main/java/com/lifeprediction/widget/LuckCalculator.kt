package com.lifeprediction.widget

import android.content.Context
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

enum class LuckLevel { LUCKY, UNLUCKY, AVERAGE }

/**
 * Everything the widget (and the description screens) need for "right now",
 * computed once per refresh so every view reads off the same snapshot.
 *
 * The whole system is anchored on the user's *natal* sign (Sun sign for men,
 * Moon sign for women, per Settings) combined with today's Pluto-Phase era.
 * That pair yields one [BookOfLuck.LuckProfile] for "lucky" and one for
 * "unlucky" — every colored element below is just a lookup against those two
 * profiles:
 *   - Sun / Moon boxes: is *today's transiting* Sun/Moon sign in the natal
 *     profile's lucky "people" list, the unlucky one, or neither?
 *   - Day / Month / Year: each calendar value is reduced to a single digit
 *     on its own (day 14 -> 5, month 12 -> 3, year 2026 -> 1), then checked
 *     as-is against the era's *unreduced* lucky/unlucky number lists (which
 *     run 1-12) — a match only happens if the reduced digit and a raw
 *     lucky/unlucky number are literally the same number, so a lucky number
 *     like 10, 11, or 12 can never match a day/month/year (only Time, below,
 *     can reach those).
 *   - Date (the overall day, used for its own description popup): a
 *     genuinely distinct value from Day above — every digit of day, month,
 *     and year is summed together and *that* combined sum is reduced to a
 *     single digit, the same way a full-date numerology reading works,
 *     rather than just reusing the day's own digit.
 *   - Time: is the hour (1-12, unreduced — it already matches the book's
 *     1-12 number range) in the lucky/unlucky number lists, or neither?
 */
data class WidgetSnapshot(
    val now: LocalTime,
    val date: LocalDate,
    val hour12: Int,
    val transitingSunSign: String,
    val transitingMoonSign: String,
    val natalSign: String,
    val timeLevel: LuckLevel,
    val sunLevel: LuckLevel,
    val moonLevel: LuckLevel,
    val dateLevel: LuckLevel,
    val dayLevel: LuckLevel,
    val monthLevel: LuckLevel,
    val yearLevel: LuckLevel
)

object LuckCalculator {

    private fun classifyNumber(value: Int, lucky: List<Int>, unlucky: List<Int>): LuckLevel = when {
        value in lucky -> LuckLevel.LUCKY
        value in unlucky -> LuckLevel.UNLUCKY
        else -> LuckLevel.AVERAGE
    }

    private fun classifySign(sign: String, luckyPeople: List<String>, unluckyPeople: List<String>): LuckLevel = when {
        sign in luckyPeople -> LuckLevel.LUCKY
        sign in unluckyPeople -> LuckLevel.UNLUCKY
        else -> LuckLevel.AVERAGE
    }

    fun buildSnapshot(context: Context, at: LocalDate = LocalDate.now(), time: LocalTime = LocalTime.now()): WidgetSnapshot {
        val natalSign = BirthPrefs.natalSign(context)
        val natalIndex = signIndexOf(natalSign).coerceIn(0, 11)
        val bookEra = PlutoPhaseTable.bookEraIndexForYear(at.year)

        val lucky = BookOfLuck.lucky(natalIndex, bookEra)
        val unlucky = BookOfLuck.unlucky(natalIndex, bookEra)

        val utcNow = LocalDateTime.of(at, time).atZone(ZoneId.systemDefault()).withZoneSameInstant(ZoneId.of("UTC")).toLocalDateTime()
        val sunSign = EphemerisRepository.sunSignAt(context, utcNow)
        val moonSign = EphemerisRepository.moonSignAt(context, utcNow)

        val hour24 = time.hour
        val hour12 = ((hour24 + 11) % 12) + 1 // 0->12, 13->1, etc.

        val dayDigit = Numerology.reduceToSingleDigit(at.dayOfMonth)
        val monthDigit = Numerology.reduceToSingleDigit(at.monthValue)
        val yearDigit = Numerology.reduceToSingleDigit(at.year)
        val fullDateDigit = Numerology.reduceDateToSingleDigit(at.dayOfMonth, at.monthValue, at.year)

        return WidgetSnapshot(
            now = time,
            date = at,
            hour12 = hour12,
            transitingSunSign = sunSign,
            transitingMoonSign = moonSign,
            natalSign = natalSign,
            timeLevel = classifyNumber(hour12, lucky.numbers, unlucky.numbers),
            sunLevel = classifySign(sunSign, lucky.people, unlucky.people),
            moonLevel = classifySign(moonSign, lucky.people, unlucky.people),
            dateLevel = classifyNumber(fullDateDigit, lucky.numbers, unlucky.numbers),
            dayLevel = classifyNumber(dayDigit, lucky.numbers, unlucky.numbers),
            monthLevel = classifyNumber(monthDigit, lucky.numbers, unlucky.numbers),
            yearLevel = classifyNumber(yearDigit, lucky.numbers, unlucky.numbers)
        )
    }
}
