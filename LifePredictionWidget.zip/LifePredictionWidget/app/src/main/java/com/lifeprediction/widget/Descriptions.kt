package com.lifeprediction.widget

/** The tap-through screen's tier word, replacing "lucky/unlucky/average"
 *  everywhere in the UI — the count (0/1/2) still carries the real meaning,
 *  this is just how it reads. */
fun LuckLevel.tierWord(): String = when (this) {
    LuckLevel.LUCKY -> "Charged"
    LuckLevel.AVERAGE -> "Dormant"
    LuckLevel.UNLUCKY -> "Dim"
}

/**
 * Mystical, game-flavored interpretation text for each gem's three states.
 * Each gem keeps its own imagery, matched to what it now measures: Quartz =
 * pulse/light (Time), Amethyst = shadow (Day), Topaz = tide (Moon Sign),
 * Jade = flame (Sun Sign), Sapphire = root (Month), Emerald = current
 * (Date), Ruby = ember (Year), Diamond = the era itself (Phase) — so the
 * eight read as distinct voices rather than one template with the noun
 * swapped.
 */
object Descriptions {

    fun text(gem: Gem, level: LuckLevel): String = when (gem) {
        Gem.QUARTZ -> when (level) {
            LuckLevel.LUCKY -> "The hour hums clear. Whatever you set in motion now moves with the current, not against it."
            LuckLevel.AVERAGE -> "The hour holds still. Neither push nor pull \u2014 a pause between pulses."
            LuckLevel.UNLUCKY -> "The hour flickers low. Let it pass before you strike."
        }
        Gem.AMETHYST -> when (level) {
            LuckLevel.LUCKY -> "The day's shadow falls in your favor. Quiet work done now settles deep and holds."
            LuckLevel.AVERAGE -> "The day's shadow rests neutral. Nothing hidden stirs, nothing hidden threatens."
            LuckLevel.UNLUCKY -> "The day's shadow thickens. Guard what you'd rather keep unseen."
        }
        Gem.TOPAZ -> when (level) {
            LuckLevel.LUCKY -> "The tide answers you tonight. What you feel now, trust \u2014 it's reading true."
            LuckLevel.AVERAGE -> "The tide runs level. Emotion neither rises to meet you nor pulls away."
            LuckLevel.UNLUCKY -> "The tide turns against reading. Let feeling settle before you act on it."
        }
        Gem.JADE -> when (level) {
            LuckLevel.LUCKY -> "The flame burns toward you. Step forward \u2014 this is a day built to be seen."
            LuckLevel.AVERAGE -> "The flame holds steady, unaligned. Presence neither draws nor deflects attention."
            LuckLevel.UNLUCKY -> "The flame turns inward. Better to hold ground than to reach for the light."
        }
        Gem.SAPPHIRE -> when (level) {
            LuckLevel.LUCKY -> "The root grows in your direction this month. What you plant now has real reach to take hold."
            LuckLevel.AVERAGE -> "The root holds its depth. This month neither feeds nor starves what you're building."
            LuckLevel.UNLUCKY -> "The root strains this month. Tend what's already growing before starting anything new."
        }
        Gem.EMERALD -> when (level) {
            LuckLevel.LUCKY -> "The current runs with you today. Momentum favors motion \u2014 go with it, not around it."
            LuckLevel.AVERAGE -> "The current runs even. Today asks for balance, not a bold current either way."
            LuckLevel.UNLUCKY -> "The current runs against you today. Move carefully, and don't fight the pull."
        }
        Gem.RUBY -> when (level) {
            LuckLevel.LUCKY -> "The ember carries this year. Long plans laid now have fuel behind them."
            LuckLevel.AVERAGE -> "The ember burns low and steady. The year holds its shape without pushing you either way."
            LuckLevel.UNLUCKY -> "The ember cools this year. Guard what's already lit rather than striking new flame."
        }
        Gem.DIAMOND -> when (level) {
            LuckLevel.LUCKY -> "The era itself bends toward you. This is a rare, slow-turning alignment \u2014 few decades carry it."
            LuckLevel.AVERAGE -> "The era holds its distance. Its long turn neither favors nor opposes you right now."
            LuckLevel.UNLUCKY -> "The era turns away. This is a long season to build quietly and wait it out."
        }
    }
}
