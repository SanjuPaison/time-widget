package com.lifeprediction.widget

import android.content.Context
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

enum class Gender { MALE, FEMALE }

/**
 * Birth date + time + time zone. The time zone (not a place name) is what's
 * actually needed to convert the locally-entered birth time into UTC for an
 * accurate ephemeris lookup — the Sun/Moon's ecliptic longitude itself
 * doesn't depend on *where* on Earth you were born, only on the UTC instant.
 */
data class BirthData(
    val date: LocalDate,
    val time: LocalTime,
    val zoneId: String,
    val gender: Gender
) {
    /** The birth instant converted to UTC — this is what the ephemeris lookup actually uses. */
    fun utcDateTime(): LocalDateTime {
        val zone = runCatching { ZoneId.of(zoneId) }.getOrDefault(ZoneId.systemDefault())
        return LocalDateTime.of(date, time).atZone(zone).withZoneSameInstant(ZoneId.of("UTC")).toLocalDateTime()
    }
}

object BirthPrefs {
    private const val PREFS = "birth_prefs"
    private const val KEY_DATE = "birth_date_iso"
    private const val KEY_TIME = "birth_time_iso"
    private const val KEY_ZONE = "birth_zone"
    private const val KEY_GENDER = "gender"

    // Sensible default so the widget renders something meaningful before the
    // user opens Settings for the first time.
    private val DEFAULT = BirthData(
        date = LocalDate.of(1990, 1, 1),
        time = LocalTime.of(12, 0),
        zoneId = ZoneId.systemDefault().id,
        gender = Gender.MALE
    )

    fun get(context: Context): BirthData {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val iso = prefs.getString(KEY_DATE, null) ?: return DEFAULT
        val date = runCatching { LocalDate.parse(iso) }.getOrDefault(DEFAULT.date)
        val time = runCatching { LocalTime.parse(prefs.getString(KEY_TIME, null)) }.getOrDefault(DEFAULT.time)
        val zone = prefs.getString(KEY_ZONE, null) ?: DEFAULT.zoneId
        val gender = if (prefs.getString(KEY_GENDER, "MALE") == "FEMALE") Gender.FEMALE else Gender.MALE
        return BirthData(date, time, zone, gender)
    }

    fun save(context: Context, data: BirthData) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_DATE, data.date.toString())
            .putString(KEY_TIME, data.time.toString())
            .putString(KEY_ZONE, data.zoneId)
            .putString(KEY_GENDER, data.gender.name)
            .apply()
    }

    /**
     * Natal sign used for all luck calculations: Sun sign for men, Moon sign
     * for women — computed from the exact birth instant (date + time,
     * converted from the birth time zone to UTC), not just the date.
     */
    fun natalSign(context: Context, data: BirthData = get(context)): String {
        val utc = data.utcDateTime()
        return when (data.gender) {
            Gender.MALE -> EphemerisRepository.sunSignAt(context, utc)
            Gender.FEMALE -> EphemerisRepository.moonSignAt(context, utc)
        }
    }
}
