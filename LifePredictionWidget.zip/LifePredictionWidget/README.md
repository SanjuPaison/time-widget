# Life Prediction Widget

A 1x1 Android home-screen widget showing the current time, transiting Sun/Moon
zodiac signs, and today's date, all color-coded lucky/average/unlucky per the
Book of Luck / Pluto Phases system, based on your birth date, time, place, and
gender (Settings screen).

## Building this on a tablet (no computer needed)

You can't run Android Studio on a tablet, but GitHub can build the APK for
you for free. This repo already includes `.github/workflows/build.yml` set
up to do that.

1. **Create a GitHub account** if you don't have one (github.com, works fine
   in a tablet browser).
2. **Create a new repository** (any name, e.g. `life-prediction-widget`).
   Choose "Add files" → **"Upload files"**, then upload everything from this
   unzipped folder (or use the GitHub mobile app / a file manager with a Git
   client like Working Copy on iPad, or Termux + git on Android, if you'd
   rather push via command line).
3. Once the files are in the repo, go to the **"Actions"** tab. A workflow
   run should start automatically (or click **"Run workflow"** if it
   doesn't).
4. Wait for the green checkmark (a few minutes).
5. Open the finished run, scroll to **"Artifacts"**, and download
   **`LifePredictionWidget-debug-apk`**. It downloads as a `.zip` containing
   `app-debug.apk`.
6. On your tablet, open that zip with your file manager, extract
   `app-debug.apk`, and tap it to install (Android will prompt you to allow
   installs from this source the first time — that's normal for an app not
   from the Play Store).
7. Long-press your home screen → **Widgets** → **Life Prediction** → drag the
   1x1 widget onto your home screen.
8. Tap the date box (or any section) → **Settings** to enter your birth date,
   time, place, and gender.

## What's inside

- `app/src/main/java/com/lifeprediction/widget/` — all the Kotlin logic
  (ephemeris lookup, Book of Luck / Pluto Phase tables, numerology, the
  widget provider, Settings, and the description popups).
- `app/src/main/res/` — widget layout, colors, strings.
- `app/src/main/assets/sun_moon_1940_2060.tsv` — daily Sun/Moon ecliptic
  longitude table (1940-2060), trimmed from the ephemeris file you provided.
- `.github/workflows/build.yml` — the cloud build described above.

No Gradle wrapper jar is bundled (couldn't be generated offline), so the CI
workflow installs Gradle directly rather than using `./gradlew`. If you later
build this on an actual computer with Android Studio, just open the folder
there — Android Studio will regenerate the wrapper for you automatically.

## Permissions

The app requests **no permissions at all**. It doesn't make network calls
(tapping the website line just hands the URL to your browser, which does its
own networking), and widget color refreshes rely on Android's normal widget
update cycle (`updatePeriodMillis`, 30 minutes — the system's own floor for
this) rather than exact alarms, so no alarm-scheduling permission is needed
either.
