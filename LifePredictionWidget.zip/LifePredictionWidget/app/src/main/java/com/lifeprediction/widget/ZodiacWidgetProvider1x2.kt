package com.lifeprediction.widget

/**
 * Exists purely to give the 1x2 (tall) widget its own manifest component, so
 * it shows as a separate, distinct entry in the widget picker. No logic of
 * its own — everything is inherited from ZodiacWidgetProvider. Uses a
 * different layout (@layout/widget_zodiac_tall, with Sun/Moon stacked
 * vertically) since it's a single column wide — see
 * ZodiacWidgetProvider.layoutResFor().
 */
class ZodiacWidgetProvider1x2 : ZodiacWidgetProvider()
