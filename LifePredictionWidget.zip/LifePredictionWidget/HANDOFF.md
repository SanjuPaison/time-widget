# LifePredictionWidget — Project Handoff (updated)

An Android home-screen widget showing time-of-day, date, and Sun/Moon zodiac
readings, scored via a personal numerology/astrology system tied to the
person's birth data. Recast this session as a "gemstone" theme: each of 8
scored elements maps to a gem (value $10–$5,000), and the widget/interpretation
screens now show gems, not colored boxes. Built entirely through Claude
conversation, deployed via GitHub Actions (the person doesn't have Android
Studio — they build on a tablet).

**Two apps now coexist on the same device, same repo:**
- **"Life Prediction"** (`applicationId com.lifeprediction.widget`) — the
  original app, box-grid widget face. Not touched this session except for one
  earlier turn (receiver-exposure fix + R8 minification — see below). Frozen
  as-is; this repo no longer builds updates for this `applicationId`.
- **"Pluto Phases Gems"** (`applicationId com.lifeprediction.widget.gems`) —
  the active line of work, same Kotlin package (`com.lifeprediction.widget`)
  and same repo, different `applicationId`/label/icon so it installs
  side-by-side rather than overwriting the original. **This is what the zip
  in this repo currently builds.**

**To continue this project**: paste this whole document into a new chat, then
attach the current project zip (already delivered this session — the person
has it in their GitHub repo; no new zip needed unless code changes further).
No memory/project files carry over between chats automatically.

## How the person works (important context)

- Non-coder, works entirely from a tablet, no Android Studio.
- Workflow: Claude edits code in `/home/claude/work/proj/LifePredictionWidget`
  → zips it (only when explicitly asked "zip it"/"create zip"/or a natural
  "start"/"continue" on already-agreed work) → person uploads the zip to
  their GitHub repo root (single-file upload, overwriting the previous one)
  → GitHub Actions (`.github/workflows/build.yml`, **not** included in the
  zip — added once, separately, via GitHub's web "create file" editor)
  builds a debug APK → person downloads the artifact, installs, tests.
- Person often pastes back real build errors — these have caught genuine bugs
  before. Always fix root cause, verify with
  `python3 -c "import xml.etree.ElementTree as ET; ET.parse(...)"` for XML
  and brace/paren balance checks for Kotlin, since there's no local
  Kotlin/Android compiler in this sandbox (no network, no SDK). **This
  session's entire redesign (see below) has never been through a real
  Gradle build** — only static checks were possible. Treat the next reported
  build result as the first real signal.
- After most code-change turns, the person separately asks "Are there any
  security vulnerabilities, memory leaks, or dangerous permission requests in
  this code?" — expects a genuine, freshly-checked answer each time, scoped
  to what actually changed, not a copy-paste of the previous answer.
- The person plans out large changes carefully before building: expect
  multi-turn "here's my proposal" → Claude flags ambiguities/risks → person
  answers → "start"/"continue" sequences. **Do not build ahead of an
  explicit go-ahead** — this person has enforced "Do not create or change
  anything until I say" more than once, and has also gotten frustrated when
  told "yes, start" was interpreted as covering more than the specific thing
  most recently confirmed (a "start" only covers what was just laid out and
  confirmed, not the whole backlog of previously-discussed ideas).
- Verify rigorously after every layout change: XML validity, ID parity
  across **all four** widget layout files (`layout/widget_zodiac.xml`,
  `layout-land/widget_zodiac.xml`, `layout/widget_zodiac_tall.xml`,
  `layout-land/widget_zodiac_tall.xml` — all four must have an identical
  view ID set, since the same Kotlin populates all of them), every
  `R.id.*` referenced in Kotlin actually exists in the layouts, and only
  `RemoteViews`-safe view types are used (see below). Also sweep for
  genuinely dead code (unused dimens/strings/drawables/colors/functions)
  whenever asked — this has turned up real leftovers almost every time it's
  been run, including this session (dead `gridOrder()`, three dead colors,
  a dead dimen, `ZODIAC_SYMBOLS`/`symbolFor` after the "no zodiac glyphs
  anywhere" requirement removed their only callers).

## Hard-won lessons (don't repeat these mistakes)

1. **`RemoteViews` only supports a small allow-list of view classes**:
   `FrameLayout`, `LinearLayout`, `RelativeLayout`, `GridLayout`, `TextView`,
   `ImageView`, `ImageButton`, `Button`, `ProgressBar`, `TextClock`, `ListView`,
   `GridView`, `StackView`, `AdapterViewFlipper`, `ViewFlipper`, `ViewStub`.
   **`Space` and plain `View` are NOT supported** in most contexts — except
   the interpretation screen's tab bars (`desc_tab_bar_*`), which use plain
   `View` deliberately: that screen is a normal `Activity`
   (`activity_description.xml`), not a `RemoteViews`-hosted layout, so the
   restriction doesn't apply there. Only widget-face layouts
   (`widget_zodiac*.xml`) need to stay within the allow-list.
2. **A `wrap_content`-sized `FrameLayout` containing a `match_parent`
   `ImageView` background nested inside ANOTHER `wrap_content` wrapper is
   unreliable** on real widget hosts. Fix: never nest more than one extra
   level of wrap-content-around-match-parent; a `match_parent`-on-
   `match_parent` `FrameLayout` containing a `match_parent` child (used for
   the whole-widget border overlay, and this session for the gem-carousel/
   empty-text overlap) is fine — both sides are match_parent, not
   wrap_content-around-match_parent.
3. **Width-based `layout_weight` + `0dp` is safe; vertical is normally
   risky** — BUT this session deliberately introduced ONE vertical use: the
   gem carousel row (`layout_height="0dp"` + `layout_weight="1"`) filling the
   space between the fixed top (date/time) and bottom (links/refresh) rows,
   per explicit request ("gems have to resize or there will be empty
   space"). This is architecturally the textbook-correct use of vertical
   weight (one flexible region between two `wrap_content` ends in an
   otherwise-plain vertical `LinearLayout`, not weight on individual leaf
   items inside a row) and is expected to work on mainstream launchers — but
   **it has never been tested on a real device/launcher**, and the earlier
   caution about vertical weight in this exact project came from real
   failures. If gems come back too small, clipped, or with dead empty
   space, this is the first place to look. All within-row splits (arrows
   vs. stone slots, the old bottom icon row) still use the proven-safe
   width-based weight only.
4. **AAPT2 gotchas that broke real builds**: (a) `<item type="dimen"
   format="float">` throws `IllegalStateException: Can not extract
   resource` — inline the literal value in XML instead. (b) Unescaped
   apostrophes in `<string>` resources throw a parse error — always escape
   as `\'` or avoid apostrophes.
5. **Kotlin `.min()`/`.max()` on collections have had inconsistent stdlib
   availability across Kotlin versions** — always use `.minOrNull()!!` /
   `.maxOrNull()!!` instead.
6. **A widget host doesn't always give an exact height even at declared
   size.** Current mitigation: `wrap_content` on fixed rows,
   `layout-land/` variants as separate, more compact files (Android
   auto-selects them by orientation qualifier).
7. **The device's local timezone offset matters for alarm scheduling.**
   Always compute hour/day boundaries in `ZoneId.systemDefault()`, not UTC.
8. **PendingIntents**: always `FLAG_IMMUTABLE`, always explicit
   component/target when the target is known.
9. **Exported `BroadcastReceiver`s and custom actions don't mix safely.**
   An `android:exported="true"` receiver (required for
   `ZodiacWidgetProvider1x1/2x1/1x2` to receive `APPWIDGET_UPDATE` from the
   system) can ALWAYS be reached by an explicit intent from any other app,
   regardless of what's declared in its `<intent-filter>` — the filter only
   gates *implicit* intent matching, not explicit component targeting. Any
   app-defined action (not a system "protected broadcast" like
   `BOOT_COMPLETED`) handled by an exported receiver is therefore reachable
   by any other installed app. Fix pattern used twice now: put the custom
   action on its own dedicated, **`android:exported="false"`** receiver
   instead (`TickReceiver` for `ACTION_TICK`, `CarouselReceiver` for
   `ACTION_SCROLL`), and have the exported widget-provider receivers only
   list `APPWIDGET_UPDATE`. `BootReceiver` stays exported (required) but is
   genuinely safe, since `BOOT_COMPLETED` **is** a protected broadcast — the
   OS itself refuses to let a non-system app send it, explicit intent or
   not, so it's not subject to this issue.
10. **R8/ProGuard needs `proguardFiles(getDefaultProguardFile(...), ...)`
    explicitly** — `isMinifyEnabled = true` alone runs R8 with no baseline
    ruleset. Now enabled for release builds; see Build process below for
    what's kept and why.

## Current architecture

### Widget sizing — THREE separate fixed-size picker entries (not resizable)
- `ZodiacWidgetProvider` (open class) — all shared logic lives here.
- `ZodiacWidgetProvider1x1` / `2x1` / `1x2` — trivial subclasses, each its
  own manifest `<receiver>`, `exported="true"` (required), intent-filter
  only lists `APPWIDGET_UPDATE` (see lesson 9). 1x2 uses the stacked/tall
  layout (`widget_zodiac_tall.xml`); 1x1/2x1 share `widget_zodiac.xml`.
- **Per-instance state, new this session**: since the gem carousel can be on
  a different page per placed widget, `buildRemoteViews(context,
  providerClass, appWidgetId)` now takes an `appWidgetId` and builds each
  instance individually — `updateAll()` loops every placed id of all three
  classes; `updateInstance(context, appWidgetId)` rebuilds just one (used
  after a carousel scroll, via `AppWidgetManager.getAppWidgetInfo(id)
  .provider` to find which of the 3 classes owns that id).
  `onDeleted` clears that instance's stored carousel page.

### The gemstone system (`Gemstones.kt`, `Descriptions.kt`)
8 elements, each mapped to a gem, each gem with a fixed value and a fixed
identity color (baked into its own vector drawable, never runtime-tinted).
**Exact final mapping — this was corrected mid-session, verify against this,
not against memory:**

| Element (what's scored)     | Gem      | Value  |
|------------------------------|----------|--------|
| Time (current hour)          | Quartz   | $10    |
| Day (day of month)           | Amethyst | $50    |
| Moon Sign (transiting)       | Topaz    | $100   |
| Sun Sign (transiting)        | Jade     | $300   |
| Month                        | Sapphire | $300   |
| Date (day+month+year digest) | Emerald  | $400   |
| Year                         | Ruby     | $600   |
| Phase (Pluto-phase era)      | Diamond  | $5,000 |

Each element's `LuckLevel` (LUCKY/AVERAGE/UNLUCKY, from the pre-existing
`LuckCalculator`/`BookOfLuck` numerology system — untouched this session)
maps to a **count**: 0 stones (unlucky/"Dim"), 1 (average/"Dormant"), 2
(lucky/"Charged") — see `LuckLevel.gemCount()`. The words
Charged/Dormant/Dim were removed from all UI text this session; only the
count and gem itself communicate the reading now. `Descriptions.text(gem,
level)` still picks between 3 mystical paragraph variants per gem based on
the underlying `LuckLevel` — that per-level paragraph selection is
unchanged, only its old tier-word label was removed.

**Phase luck** (`PlutoPhaseTable.kt`): the Diamond/Phase element compares
the person's *natal* sign directly against explicit lucky/unlucky lists for
4 eras (independent of the older per-sign Book-of-Luck cycle the other 7
elements use):
- 1990–2002 Cancer Phase: lucky Aries/Leo/Sagittarius, unlucky
  Gemini/Libra/Aquarius
- 2003–2016 Leo Phase: lucky Taurus/Virgo/Capricorn, unlucky
  Cancer/Scorpio/Pisces
- 2017–2032 Virgo Phase: lucky Gemini/Libra/Aquarius, unlucky
  Aries/Leo/Sagittarius
- 2033–2054 Libra Phase: lucky Cancer/Scorpio/Pisces, unlucky
  Taurus/Virgo/Capricorn

Outside these 4 explicit ranges, Phase defaults to AVERAGE (no data given).

**`GemLedger`** (in `Gemstones.kt`): `entries()` (8 gems + their level),
`totalValue()` (sum of value×count), `levelFor()`, and `activeStones()` — a
FLAT list of owned physical stones (a count-2 gem appears twice, count-0
skipped entirely), ascending by value, which is what the widget-face
carousel pages through.

**Gem illustrations** (`ic_gem_quartz.xml` … `ic_gem_diamond.xml`): 8
generated vector drawables, faceted-gem silhouette (pointed base, flat
crown, girdle line, top highlight), 3-tone shading (dark-left/light-right/
highlight) baked directly per gem — NOT tinted at runtime, since
`setColorFilter` would flatten multi-tone shading to one flat color. Same
files used both on the widget face (big, one per owned stone) and in the
interpretation screen's top-right illustration.

### Widget face (`widget_zodiac.xml` + 3 variants) — redesigned again this session
Structure, top to bottom in a plain vertical `LinearLayout`:
1. **Top row** (`wrap_content`, sticks to top), now THREE elements:
   - `widget_datetime`: live `TextClock`, self-ticking, no Kotlin needed to
     update it. Weekday and AM/PM dropped this session — both
     `format12Hour`/`format24Hour` set to `"M/d, h:mm"` (12-hour digits, no
     day-period suffix on either format — an explicit "am/pm format
     without am/pm" choice, not a switch to 24-hour time).
   - `widget_gem_count_pill` (new): small pill, Diamond icon then a number
     — total owned *stone count* today (not a dollar value). Reuses
     `bg_total_pill` and sits between the clock and the Total Value pill so
     the two pills read as a matched pair (same icon-then-number order).
   - `widget_total_text`: unchanged, gold pill, e.g. "◆ $1,360".
2. **Middle: the gem carousel** (`0dp` height + `weight="1"`, fills
   remaining space — see lesson 3 above). A `FrameLayout` with two
   full-size siblings, only one visible at a time:
   - **Page 0 — `widget_gem_reveal` (new this session)**: the
     "You have XX gems!" reveal slide — big bold owned-stone count
     (`widget_gem_reveal_count`), Diamond icon, "gems!" in gold, a hairline
     divider, and the app name as a footer (so a screenshot of this slide
     is self-branded — the shareability goal this session). Tap → opens
     `DescriptionActivity`, defaulting to the first owned stone, or Quartz
     if every reading is Dim.
   - **Pages 1+ — `widget_gem_carousel`**: left arrow (`widget_gem_left`) +
     3 stone slots (`widget_gem_slot1/2/3`) + right arrow
     (`widget_gem_right`), same as before. Only stones with count > 0 ever
     appear; a count-2 gem fills 2 slots.
   - `pageCountFor()` is now `1 + ceil(stoneCount / 3)` — the reveal slide
     is always page 0, so page count is never 0 even with zero stones.
   - **Reversed this session**: each stone slot now has its OWN tap target
     (opens `DescriptionActivity` to that specific gem's tab), not one
     shared tap region for the row. The old "gem appearance more important
     than fine-grained tap targets" call was explicitly overridden.
   - `widget_gem_empty_text` **removed** — its job (zero-stones messaging)
     is now just "You have 0 gems!" on the reveal slide, no separate state.
   Arrows only visible/wired if there's more than one page (unchanged
   logic, now counting the reveal slide as page 0).
3. **Bottom row** (`wrap_content`, sticks to bottom): website /
   **share** (new this session, replaces instagram) / refresh icons, equal
   width-weighted thirds. `widget_share` is now an `ImageView`
   (`ic_share.xml`, static single-tone vector, standard 3-node share glyph)
   rather than a unicode-glyph `TextView` like its neighbors — deliberate,
   for higher-fidelity rendering at small size. Tap → `ACTION_SEND` (plain
   text = the website URL) wrapped in `Intent.createChooser`, opening the
   system share sheet. `instagram_url` string and `widget_instagram` id are
   gone — fully removed, not just unwired.
4. **Border overlay** (`widget_border`, full-bleed `ImageView` sibling of
   the root `LinearLayout`): tinted via `setColorFilter` to
   `BorderPrefs.get(context)` — see Settings below. Unchanged this session.

Request codes for arrow/tap `PendingIntent`s are `appWidgetId * 100 +
purpose`: 1/2 = left/right arrow, 3 = reveal-slide tap, 4/5/6 = the 3
individual stone-slot taps (was just 1/2/3 before the per-slot tap change).
Keeps every placed instance's intents distinct — needed now that instances
can be on different pages with different per-slot gems. Global codes 5/6/7
(website/share/refresh) are unaffected — they're literal, not
`appWidgetId`-multiplied, so no collision risk (see prior note on this).

### Interpretation screen (`DescriptionActivity.kt` /
`activity_description.xml`) — hero-line wording updated this session
Same 8-tab structure, unchanged mechanics. `eventPhraseFor()` in
`ZodiacWidgetProvider.kt` reworded per explicit line-by-line spec (Quartz
and Diamond phrasing were already correct and left alone):
- Amethyst: "on Day N" → "for Day N"
- Topaz: "in {sign}" → "for {sign} Moon"
- Jade: "in {sign}" → "for {sign} Sun"
- Sapphire: "in {month}" → "for {month} month"
- Emerald: "on {month} {day}" → "for the date {day} {month}, {year}"
- Ruby: "in {year}" → "for the year {year}"
Receives 3 Intent extras from `ZodiacWidgetProvider`:
`EXTRA_INITIAL_GEM` (which tab to open first), `EXTRA_LEVELS` (8
comma-joined `LuckLevel` names, `Gem.values()` order), `EXTRA_EVENTS` (8
`"|||"`-joined event phrases, same order — see `eventPhraseFor()` in
`ZodiacWidgetProvider.kt` for the per-gem preposition/value: e.g. Quartz
"at 3 o'clock", Ruby "in 2026", Diamond "for the Virgo Phase"; **no zodiac
glyphs anywhere**, confirmed removed this session along with the
now-dead `ZODIAC_SYMBOLS`/`symbolFor` in `ZodiacSigns.kt`).

Layout, top to bottom:
1. **8 fixed tabs, always** (not just active/count>0 ones — every gem is
   reachable so a Dim reading's paragraph is still readable even though it
   never appears as a physical stone on the widget face). Each tab: a big
   white count number above a thick color bar baked to that gem's own fixed
   color (`@color/gem_*`, static XML, never runtime-tinted). Selected state
   = full alpha; unselected = dimmed alpha. Tapping a tab swaps content
   in-place (one Activity instance, not 8).
2. **Hero line** (`desc_hero`, large/bold) — replaced the old subtitle line
   entirely: `"You got {count} {gem.countedName(count)} {event phrase}."`
   e.g. "You got 2 Rubies in 2026." `Gem.countedName()`: Quartz/Jade stay
   unpluralized ("2 Quartz"), Ruby→Rubies, Topaz→Topazes, rest get a plain
   "+s".
3. **Big gem illustration** (`desc_illustration`), top-right, below the tabs.
4. **Calculation line** (`desc_calc`), de-emphasized/small — "stone(s)"
   replaced with the actual gem name: `"$400 × 2 Jade = $800"`.
5. **Mystical paragraph** (`desc_body`) — unchanged content/logic
   (`Descriptions.text(gem, level)`), per explicit "leave this alone."
6. Settings link (unchanged).

Removed this session (superseded by the above): the old `desc_title`,
`desc_subtitle`, `desc_value`, `desc_badge` views and the `tierWord()`
function.

### Widget border color — new Settings option this session
`BorderPrefs.kt` (`BorderColor` enum: GOLD/SILVER/BLUE/BROWN,
default GOLD) — mirrors `BackgroundPrefs.kt`'s exact pattern
(`SharedPreferences`, `MODE_PRIVATE`). Wired into
`activity_settings.xml`/`SettingsActivity.kt` as a 4-swatch row (same UI
pattern as the existing background-color swatches, dark checkmark since
these swatches are all light/medium tones). **Fully replaces** the old
luck-based border tint — confirmed explicit ("5- fully replace").

### Background (`BackgroundPrefs.kt`) — unchanged this session
6 colors × 4 textures, default Brown/Translucent. Not touched.

### Numerology/luck core (`LuckCalculator.kt`, `BookOfLuck.kt`,
`Numerology.kt`) — unchanged this session except `WidgetSnapshot` gained a
`phaseLevel`/`phaseEra` field (see Phase luck above).

### Settings (`SettingsActivity.kt` / `activity_settings.xml`)
Field order: Gender → Birth date → Birth time → Time zone → Widget
background color swatches → texture chips → **Widget border color swatches
(new)** → permission statuses/shortcuts.

### Permissions & security (all reviewed multiple times this session,
current final set)
- `SCHEDULE_EXACT_ALARM`, `RECEIVE_BOOT_COMPLETED`,
  `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS`. No `INTERNET`. `allowBackup=
  "false"`. Unchanged this session.
- **Exported-receiver fix** (see lesson 9): `TickReceiver` and
  `CarouselReceiver` are both dedicated, `exported="false"` receivers for
  `ACTION_TICK`/`ACTION_SCROLL`. The three widget-provider receivers and
  `BootReceiver` are the only `exported="true"` components, both for
  reasons the OS requires and neither exploitable beyond that requirement.
  `DescriptionActivity`/`SettingsActivity` stay `exported="false"`.
- Every `PendingIntent` in the codebase uses `FLAG_IMMUTABLE`.
- No hardcoded secrets anywhere (checked via grep each audit).
- No memory-leak patterns found in any audit this session: no static
  `Context`/`View` references, no dynamically-registered receivers left
  unregistered, `DescriptionActivity`'s tab-id map holds only `Int`
  resource ids, not `View` references.

### Build process
- No Gradle wrapper jar bundled — `.github/workflows/build.yml` installs
  Gradle directly via `gradle/actions/setup-gradle@v4`.
- The workflow file is **not** included when zipping — `rm -rf .github`
  from the copy before zipping, always.
- minSdk 24, compileSdk/targetSdk 34, Kotlin 1.9.24, AGP 8.5.2.
- `applicationId = "com.lifeprediction.widget.gems"` (changed this
  session from `com.lifeprediction.widget` — the original app's id — so
  the two coexist; Kotlin package unchanged).
- **R8/ProGuard minification enabled for release builds this session**
  (`isMinifyEnabled = true`, `isShrinkResources = true`,
  `proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"),
  "proguard-rules.pro")` — the default-file reference was missing before,
  which would have left R8 with no baseline ruleset if minification were
  ever turned on). `proguard-rules.pro` explicitly keeps all
  manifest-declared components (belt-and-suspenders on top of AGP's
  automatic manifest keep) and the enum `values()`/`valueOf()` methods
  `Gem`/`LuckLevel`/`BgColor`/`BgTexture`/`BorderColor` need for their
  Intent-extra/SharedPreferences round-trips. **This only affects release
  builds** — confirm what variant the Actions workflow actually builds
  before assuming this is exercised.

## Known-good verification routine (run after every change, before zipping)

```bash
# XML validity for anything touched
python3 -c "import xml.etree.ElementTree as ET; ET.parse('PATH'); print('valid')"

# ID parity across ALL FOUR widget layout files (must all be identical)
grep -o 'android:id="@+id/[a-zA-Z0-9_]*"' layout/widget_zodiac.xml | sort -u > /tmp/p.txt
grep -o 'android:id="@+id/[a-zA-Z0-9_]*"' layout-land/widget_zodiac.xml | sort -u > /tmp/l.txt
grep -o 'android:id="@+id/[a-zA-Z0-9_]*"' layout/widget_zodiac_tall.xml | sort -u > /tmp/t1.txt
grep -o 'android:id="@+id/[a-zA-Z0-9_]*"' layout-land/widget_zodiac_tall.xml | sort -u > /tmp/t2.txt
diff /tmp/p.txt /tmp/l.txt && diff /tmp/p.txt /tmp/t1.txt && diff /tmp/t1.txt /tmp/t2.txt && echo "IDENTICAL - OK"
# NOTE: use [a-zA-Z0-9_] (with digits!) — widget_gem_slot1/2/3 etc. need the
# digit class or the check silently misses them.

# DescriptionActivity <-> activity_description.xml id cross-check
grep -o 'android:id="@+id/[a-zA-Z0-9_]*"' layout/activity_description.xml | sed 's/android:id="@+id\///;s/"//' | sort -u > /tmp/layout_ids.txt
grep -o "R\.id\.[a-zA-Z0-9_]*" java/com/lifeprediction/widget/DescriptionActivity.kt | sed 's/R\.id\.//' | sort -u > /tmp/kotlin_ids.txt
comm -13 /tmp/layout_ids.txt /tmp/kotlin_ids.txt   # anything here but "content" = will crash

# Kotlin brace/paren balance (no real compiler available in this sandbox)
for f in java/com/lifeprediction/widget/*.kt; do
  python3 -c "s=open('$f').read(); b=s.count('{')-s.count('}'); p=s.count('(')-s.count(')'); print('$f', b, p) if b or p else None"
done
# Note: comments with unbalanced parens in prose (e.g. "(see X)") are
# harmless false positives — check the actual line before assuming a bug.

# Sweep for dead resources/functions
for c in $(grep -o 'name="[a-zA-Z_]*"' res/values/colors.xml | sed 's/name="//;s/"//'); do
  grep -rl "@color/$c\b\|R\.color\.$c\b" res/ java/ 2>/dev/null | grep -v colors.xml >/dev/null || echo "UNUSED color: $c"
done
# same pattern for dimens/strings/drawables, and for `fun NAME` across all .kt files
```

## Packaging routine

```bash
rm -rf /home/claude/work/pkg/*
cp -r /home/claude/work/proj/LifePredictionWidget /home/claude/work/pkg/
rm -rf /home/claude/work/pkg/LifePredictionWidget/.github   # not part of the zip
cd /home/claude/work/pkg
zip -r -q /mnt/user-data/outputs/LifePredictionWidget.zip LifePredictionWidget -x "*.DS_Store"
```
Then `present_files` on the zip.

## Status as of end of this session

**Delivered, in order, this session** (see "Widget face" and
"Interpretation screen" sections above for full detail):
1. Clock: dropped weekday + AM/PM, kept 12-hour digits (`M/d, h:mm` on both
   `format12Hour`/`format24Hour`) — explicit "am/pm format without am/pm."
2. New gem-count pill in the top row (owned stone count, Diamond icon then
   number), between the clock and the existing Total Value pill.
3. New carousel page 0: "You have XX gems!" reveal slide — big count,
   Diamond icon, app-name footer for shareability, opens
   `DescriptionActivity` on tap. Replaces the old `widget_gem_empty_text`
   fallback entirely (zero-stones case is now just "You have 0 gems!").
4. Each of the 3 stone slots now has its own tap target (reversing the
   earlier "one shared tap region for the row" design call).
5. Instagram → Share: `widget_instagram` removed, `widget_share`
   (`ic_share.xml`, static vector) added, wired to `ACTION_SEND` sharing
   the plain website URL via the system share sheet.
6. Hero-line copy reworded for Amethyst/Topaz/Jade/Sapphire/Emerald/Ruby
   per an explicit 7-line spec (Quartz/Diamond unchanged).

All 4 widget layout files regenerated from one Python template this
session (per-file sizing scaled proportionally from each file's existing
values, not guessed) to guarantee ID parity and reduce copy-paste risk
across 4 near-identical files. Known-good verification routine (XML
validity, ID parity, DescriptionActivity cross-check, brace/paren balance,
dead-resource sweep) run clean — two pre-existing findings
(`EphemerisRepository.kt` paren "imbalance", unused `ic_launcher_gems`
drawable) are both untouched-by-this-session false positives: the former
is a comment-in-prose parenthesis (per the routine's own noted caveat),
the latter is referenced from `AndroidManifest.xml`, outside the sweep's
res/+java scope.

**Not yet confirmed to build clean on a fresh GitHub Actions run** — only
static checks were possible in this sandbox. Priority items to watch for
in the next reported build/test:
- Does the reveal slide (page 0) actually fit and read well on the
  smallest widget size (1x1, `layout-land/widget_zodiac_tall.xml`)? Four
  stacked text elements plus a divider in a possibly very short flexible
  row is the single biggest layout-risk item from this session — flagged
  proactively, not yet seen on a real device.
- Does the vertical-`layout_weight` gem carousel/reveal region actually
  fill the space correctly on the person's real launcher (carried over
  open question from before)?
- Per-slot tap targets on the stone pages — untested on a real device
  (only that all 3 `PendingIntent`s are distinct and correctly built was
  statically verified).
- Share sheet behavior from a widget `PendingIntent` context (the
  `Intent.createChooser` wrapping) — standard pattern, but worth confirming
  it actually opens on the person's device/launcher combination.
- Multiple placed widget instances scrolling independently — still
  untested on a real device (carried over from before).

## Explicitly discussed, explicitly NOT to be built
(per the person's own instruction from an earlier session: "Ignore the new
ideas" — still applies unless raised again)

A separate line of discussion happened in an earlier session about turning
this into a **personalized product handed out to customers** (12 Gradle
product flavors per zodiac sign, Firebase/Play Console distribution, a
"mysterious, unexplained calculation" copy tone, a crypto-paying app
store). None of this was implemented and none of it should be treated as
in-progress. If the person wants to pick this back up, they'll say so.

Also asked about and explicitly declined: hiding the calculation logic from
decompilation beyond standard R8 minification (encrypted data tables,
native/NDK code, server-side computation) — discussed as options, only the
standard R8 minification step was actually implemented.
