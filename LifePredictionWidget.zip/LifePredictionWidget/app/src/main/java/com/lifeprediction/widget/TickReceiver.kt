package com.lifeprediction.widget

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast

/**
 * Handles the internal refresh tick (ACTION_TICK): recomputes and pushes
 * fresh colors to every placed widget, then reschedules the next tick —
 * exactly what used to happen inside ZodiacWidgetProvider.onReceive.
 *
 * This is a separate manifest-declared receiver, rather than living on the
 * three widget-provider receivers alongside APPWIDGET_UPDATE, specifically
 * so it can require the signature-level "...permission.TICK" permission
 * (see AndroidManifest.xml) without that requirement also blocking the
 * system's own APPWIDGET_UPDATE broadcasts to those receivers — the system
 * wouldn't hold a custom app-defined permission, so putting the requirement
 * there would have silently broken normal widget updates. Only an app
 * signed with this app's own certificate can hold that permission, which in
 * practice means only this app itself can ever trigger this receiver; any
 * other installed app broadcasting ACTION_TICK is rejected by the system
 * before onReceive here is even called.
 */
class TickReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ZodiacWidgetProvider.ACTION_TICK) return

        ZodiacWidgetProvider.updateAll(context)
        ZodiacWidgetProvider.scheduleNextTick(context)

        // Manual refresh-button tap: colors only actually change at a real
        // hour/sign boundary, so a silent recompute can look like the
        // button did nothing. A short Toast confirms the tap registered.
        if (intent.getBooleanExtra(ZodiacWidgetProvider.EXTRA_MANUAL, false)) {
            Toast.makeText(context, R.string.refreshed_toast, Toast.LENGTH_SHORT).show()
        }
    }
}
