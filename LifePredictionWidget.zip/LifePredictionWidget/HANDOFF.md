# LifePredictionWidget — Project Handoff (updated)

An Android home-screen widget showing time-of-day, date, and Sun/Moon zodiac
readings, scored via a personal numerology/astrology system tied to the
person's birth data. Recast this session as a "gemstone" theme: each of 8
scored elements maps to a gem (value $10–$5,000), and the widget/interpretation
screens now show gems, not colored boxes. Built entirely through Claude
conversation, deployed via GitHub Actions (the person doesn't have Android
Studio — they build on a tablet).

**Two apps now coexist on the same device, same repo:**
- **"Life Prediction"** (`applicationId com.lifeprediction.widget`) — the
  original app, box-grid widget face. Not touched this session except for one
  earlier turn (receiver-exposure fix + R8 minification — see below). Frozen
  as-is; this repo no longer builds updates for this `applicationId`.
- **"Pluto Phases Gems"** (`applicationId com.lifeprediction.widget.gems`) —
  the active line of work, same Kotlin package (`com.lifeprediction.widget`)
  and same repo, different `applicationId`/label/icon so it installs
  side-by-side rather than overwriting the original. **This is what the zip
  in this repo currently builds.**

**To continue this project**: paste this whole document into a new chat, then
attach the current project zip (already delivered this session — the person
has it in their GitHub repo; no new zip needed unless code changes further).
No memory/project files carry over between chats automatically.

## How the person works (important context)

- Non-coder, works entirely from a tablet, no Android Studio.
- Workflow: Claude edits code in `/home/claude/work/proj/LifePredictionWidget`
  → zips it (only when explicitly asked "zip it"/"create zip"/or a natural
  "start"/"continue" on already-agreed work) → person uploads the zip to
  their GitHub repo root (single-file upload, overwriting the previous one)
  → GitHub Actions (`.github/workflows/build.yml`, **not** included in the
  zip — added once, separately, via GitHub's web "create file" editor)
  builds a debug APK → person downloads the artifact, installs, tests.
- Person often pastes back real build errors — these have caught genuine bugs
  before. Always fix root cause, verify with
  `python3 -c "import xml.etree.ElementTree as ET; ET.parse(...)"` for XML
  and brace/paren balance checks for Kotlin, since there's no local
  Kotlin/Android compiler in this sandbox (no network, no SDK). **This
  session's entire redesign (see below) has never been through a real
  Gradle build** — only static checks were possible. Treat the next reported
  build result as the first real signal.
- After most code-change turns, the person separately asks "Are there any
  security vulnerabilities, memory leaks, or dangerous permission requests in
  this code?" — expects a genuine, freshly-checked answer each time, scoped
  to what actually changed, not a copy-paste of the previous answer.
- The person plans out large changes carefully before building: expect
  multi-turn "here's my proposal" → Claude flags ambiguities/risks → person
  answers → "start"/"continue" sequences. **Do not build ahead of an
  explicit go-ahead** — this person has enforced "Do not create or change
  anything until I say" more than once, and has also gotten frustrated when
  told "yes, start" was interpreted as covering more than the specific thing
  most recently confirmed (a "start" only covers what was just laid out and
  confirmed, not the whole backlog of previously-discussed ideas).
- Verify rigorously after every layout change: XML validity, ID parity
  across **all four** widget layout files (`layout/widget_zodiac.xml`,
  `layout-land/widget_zodiac.xml`, `layout/widget_zodiac_tall.xml`,
  `layout-land/widget_zodiac_tall.xml` — all four must have an identical
  view ID set, since the same Kotlin populates all of them), every
  `R.id.*` referenced in Kotlin actually exists in the layouts, and only
  `RemoteViews`-safe view types are used (see below). Also sweep for
  genuinely dead code (unused dimens/strings/drawables/colors/functions)
  whenever asked — this has turned up real leftovers almost every time it's
  been run, including this session (dead `gridOrder()`, three dead colors,
  a dead dimen, `ZODIAC_SYMBOLS`/`symbolFor` after the "no zodiac glyphs
  anywhere" requirement removed their only callers).

## Hard-won lessons (don't repeat these mistakes)

1. **`RemoteViews` only supports a small allow-list of view classes**:
   `FrameLayout`, `LinearLayout`, `RelativeLayout`, `GridLayout`, `TextView`,
   `ImageView`, `ImageButton`, `Button`, `ProgressBar`, `TextClock`, `ListView`,
   `GridView`, `StackView`, `AdapterViewFlipper`, `ViewFlipper`, `ViewStub`.
   **`Space` and plain `View` are NOT supported** in most contexts — except
   the interpretation screen's tab bars (`desc_tab_bar_*`), which use plain
   `View` deliberately: that screen is a normal `Activity`
   (`activity_description.xml`), not a `RemoteViews`-hosted layout, so the
   restriction doesn't apply there. Only widget-face layouts
   (`widget_zodiac*.xml`) need to stay within the allow-list.
2. **A `wrap_content`-sized `FrameLayout` containing a `match_parent`
   `ImageView` background nested inside ANOTHER `wrap_content` wrapper is
   unreliable** on real widget hosts. Fix: never nest more than one extra
   level of wrap-content-around-match-parent; a `match_parent`-on-
   `match_parent` `FrameLayout` containing a `match_parent` child (used for
   the whole-widget border overlay, and this session for the gem-carousel/
   empty-text overlap) is fine — both sides are match_parent, not
   wrap_content-around-match_parent.
3. **Width-based `layout_weight` + `0dp` is safe; vertical is normally
   risky** — BUT this session deliberately introduced ONE vertical use: the
   gem carousel row (`layout_height="0dp"` + `layout_weight="1"`) filling the
   space between the fixed top (date/time) and bottom (links/refresh) rows,
   per explicit request ("gems have to resize or there will be empty
   space"). This is architecturally the textbook-correct use of vertical
   weight (one flexible region between two `wrap_content` ends in an
   otherwise-plain vertical `LinearLayout`, not weight on individual leaf
   items inside a row) and is expected to work on mainstream launchers — but
   **it has never been tested on a real device/launcher**, and the earlier
   caution about vertical weight in this exact project came from real
   failures. If gems come back too small, clipped, or with dead empty
   space, this is the first place to look. All within-row splits (arrows
   vs. stone slots, the old bottom icon row) still use the proven-safe
   width-based weight only.
4. **AAPT2 gotchas that broke real builds**: (a) `<item type="dimen"
   format="float">` throws `IllegalStateException: Can not extract
   resource` — inline the literal value in XML instead. (b) Unescaped
   apostrophes in `<string>` resources throw a parse error — always escape
   as `\'` or avoid apostrophes.
5. **Kotlin `.min()`/`.max()` on collections have had inconsistent stdlib
   availability across Kotlin versions** — always use `.minOrNull()!!` /
   `.maxOrNull()!!` instead.
6. **A widget host doesn't always give an exact height even at declared
   size.** Current mitigation: `wrap_content` on fixed rows,
   `layout-land/` variants as separate, more compact files (Android
   auto-selects them by orientation qualifier).
7. **The device's local timezone offset matters for alarm scheduling.**
   Always compute hour/day boundaries in `ZoneId.systemDefault()`, not UTC.
8. **PendingIntents**: always `FLAG_IMMUTABLE`, always explicit
   component/target when the target is known.
9. **Exported `BroadcastReceiver`s and custom actions don't mix safely.**
   An `android:exported="true"` receiver (required for
   `ZodiacWidgetProvider1x1/2x1/1x2` to receive `APPWIDGET_UPDATE` from the
   system) can ALWAYS be reached by an explicit intent from any other app,
   regardless of what's declared in its `<intent-filter>` — the filter only
   gates *implicit* intent matching, not explicit component targeting. Any
   app-defined action (not a system "protected broadcast" like
   `BOOT_COMPLETED`) handled by an exported receiver is therefore reachable
   by any other installed app. Fix pattern used twice now: put the custom
   action on its own dedicated, **`android:exported="false"`** receiver
   instead (`TickReceiver` for `ACTION_TICK`, `CarouselReceiver` for
   `ACTION_SCROLL`), and have the exported widget-provider receivers only
   list `APPWIDGET_UPDATE`. `BootReceiver` stays exported (required) but is
   genuinely safe, since `BOOT_COMPLETED` **is** a protected broadcast — the
   OS itself refuses to let a non-system app send it, explicit intent or
   not, so it's not subject to this issue.
10. **R8/ProGuard needs `proguardFiles(getDefaultProguardFile(...), ...)`
    explicitly** — `isMinifyEnabled = true` alone runs R8 with no baseline
    ruleset. Now enabled for release builds; see Build process below for
    what's kept and why.

## Current architecture

### Widget sizing — THREE separate fixed-size picker entries (not resizable)
- `ZodiacWidgetProvider` (open class) — all shared logic lives here.
- `ZodiacWidgetProvider1x1` / `2x1` / `1x2` — trivial subclasses, each its
  own manifest `<receiver>`, `exported="true"` (required), intent-filter
  only lists `APPWIDGET_UPDATE` (see lesson 9). 1x2 uses the stacked/tall
  layout (`widget_zodiac_tall.xml`); 1x1/2x1 share `widget_zodiac.xml`.
- **Per-instance state, new this session**: since the gem carousel can be on
  a different page per placed widget, `buildRemoteViews(context,
  providerClass, appWidgetId)` now takes an `appWidgetId` and builds each
  instance individually — `updateAll()` loops every placed id of all three
  classes; `updateInstance(context, appWidgetId)` rebuilds just one (used
  after a carousel scroll, via `AppWidgetManager.getAppWidgetInfo(id)
  .provider` to find which of the 3 classes owns that id).
  `onDeleted` clears that instance's stored carousel page.

### The gemstone system (`Gemstones.kt`, `Descriptions.kt`)
8 elements, each mapped to a gem, each gem with a fixed value and a fixed
identity color (baked into its own vector drawable, never runtime-tinted).
**Exact final mapping — this was corrected mid-session, verify against this,
not against memory:**

| Element (what's scored)     | Gem      | Value  |
|------------------------------|----------|--------|
| Time (current hour)          | Quartz   | $10    |
| Day (day of month)           | Amethyst | $50    |
| Moon Sign (transiting)       | Topaz    | $100   |
| Sun Sign (transiting)        | Jade     | $300   |
| Month                        | Sapphire | $300   |
| Date (day+month+year digest) | Emerald  | $400   |
| Year                         | Ruby     | $600   |
| Phase (Pluto-phase era)      | Diamond  | $5,000 |

Each element's `LuckLevel` (LUCKY/AVERAGE/UNLUCKY, from the pre-existing
`LuckCalculator`/`BookOfLuck` numerology system — untouched this session)
maps to a **count**: 0 stones (unlucky/"Dim"), 1 (average/"Dormant"), 2
(lucky/"Charged") — see `LuckLevel.gemCount()`. The words
Charged/Dormant/Dim were removed from all UI text this session; only the
count and gem itself communicate the reading now. `Descriptions.text(gem,
level)` still picks between 3 mystical paragraph variants per gem based on
the underlying `LuckLevel` — that per-level paragraph selection is
unchanged, only its old tier-word label was removed.

**Phase luck** (`PlutoPhaseTable.kt`): the Diamond/Phase element compares
the person's *natal* sign directly against explicit lucky/unlucky lists for
4 eras (independent of the older per-sign Book-of-Luck cycle the other 7
elements use):
- 1990–2002 Cancer Phase: lucky Aries/Leo/Sagittarius, unlucky
  Gemini/Libra/Aquarius
- 2003–2016 Leo Phase: lucky Taurus/Virgo/Capricorn, unlucky
  Cancer/Scorpio/Pisces
- 2017–2032 Virgo Phase: lucky Gemini/Libra/Aquarius, unlucky
  Aries/Leo/Sagittarius
- 2033–2054 Libra Phase: lucky Cancer/Scorpio/Pisces, unlucky
  Taurus/Virgo/Capricorn

Outside these 4 explicit ranges, Phase defaults to AVERAGE (no data given).

**`GemLedger`** (in `Gemstones.kt`): `entries()` (8 gems + their level),
`totalValue()` (sum of value×count), `levelFor()`, and `activeStones()` — a
FLAT list of owned physical stones (a count-2 gem appears twice, count-0
skipped entirely), ascending by value, which is what the widget-face
carousel pages through.

**Gem illustrations** (`ic_gem_quartz.xml` … `ic_gem_diamond.xml`): 8
generated vector drawables, faceted-gem silhouette (pointed base, flat
crown, girdle line, top highlight), 3-tone shading (dark-left/light-right/
highlight) baked directly per gem — NOT tinted at runtime, since
`setColorFilter` would flatten multi-tone shading to one flat color. Same
files used both on the widget face (big, one per owned stone) and in the
interpretation screen's top-right illustration.

### Widget face (`widget_zodiac.xml` + 3 variants) — redesigned again this session
Structure, top to bottom in a plain vertical `LinearLayout`:
1. **Top row** (`wrap_content`, sticks to top), now THREE elements:
   - `widget_datetime`: live `TextClock`, self-ticking, no Kotlin needed to
     update it. Weekday and AM/PM dropped this session — both
     `format12Hour`/`format24Hour` set to `"M/d, h:mm"` (12-hour digits, no
     day-period suffix on either format — an explicit "am/pm format
     without am/pm" choice, not a switch to 24-hour time).
   - `widget_gem_count_pill` (new): small pill, Diamond icon then a number
     — total owned *stone count* today (not a dollar value). Reuses
     `bg_total_pill` and sits between the clock and the Total Value pill so
     the two pills read as a matched pair (same icon-then-number order).
   - `widget_total_text`: unchanged, gold pill, e.g. "◆ $1,360".
2. **Middle: the gem carousel** (`0dp` height + `weight="1"`, fills
   remaining space — see lesson 3 above). A `FrameLayout` with two
   full-size siblings, only one visible at a time:
   - **Page 0 — `widget_gem_reveal`**: small multicolored gem mark
     (`ic_gem_multicolor.xml` — 5 facets, each colored from the existing
     `gem_*` palette, reads as "the collection" rather than any one gem
     type) + big bold owned-stone count (`widget_gem_reveal_count`), then
     the app wordmark (`app_name`, small caps) below. Tap → opens
     `DescriptionActivity`, defaulting to the first owned stone, or Quartz
     if every reading is Dim.
     **Bug fixed this session**: the icon+count row was originally
     `wrap_content` width. A `wrap_content` `LinearLayout` gives its
     non-weighted children an effectively unbounded width during measure,
     so the autosizing count `TextView` had nothing to shrink against and
     could render wider than the actual widget, spilling past the card
     edge ("the number is outside the widget"). Fixed by making that row
     `match_parent` width — `LinearLayout`'s normal child-measure pass then
     gives the `TextView` a real `AT_MOST` bound, which `autoSizeText`
     needs to actually work. Worth remembering for any future RemoteViews
     autosize element: **autosize needs a bounded-width ancestor, not just
     a bounded-width TextView** — `wrap_content` anywhere in that chain
     defeats it.
     The original design (a 4-line "You have / [icon] N / gems! / divider
     / app name" card) was simplified to 2 lines this session per explicit
     redesign — fewer stacked elements is also lower overflow risk on
     small sizes generally, independent of the bug fix above.
     **Second overflow fix, same session**: the wordmark line ("Pluto
     Phases Gems", small caps) had no autosize at all — just a fixed
     `textSize`, which is fine on 2x1's extra width but genuinely doesn't
     fit an 18-character string in a 1x1 cell at any reasonable readable
     size. Gave it the same `autoSizeTextType="uniform"` treatment as the
     count TextView (floor `4sp`, ceiling lowered from the original
     9/8/8/7sp per file down to 7/6/6/5sp) so it shrinks to whatever the
     actual cell width allows, same as the count fix's underlying
     principle — this line just hadn't had autosize applied to it at all
     the first time, not a wrap_content-width mistake like the count row.
     **Third overflow root cause, same session**: even with both TextViews
     correctly bounded, they were still overflowing on 1x1 specifically.
     The real culprit was the icon: `ImageView` doesn't autosize the way
     `TextView` does, so its 22dp fixed size was structurally eating most
     of the narrow 1x1 content column on its own — the two 0.6-weighted
     arrow columns already take a large share of a narrow widget's total
     width, leaving the reveal slide's content column quite tight before
     the icon and number even compete for it. Combined with the count
     text's autoSize floor being 12sp (too high to make up the deficit),
     there often wasn't room left for even a single digit at any legal
     size. Fixed by shrinking the icon itself per file (22/20/18/18dp →
     16/16/14/14dp) and lowering the count floor to a uniform 7sp — this
     is the piece that makes it genuinely *adapt* to a narrow width rather
     than just being bounded-but-still-too-big.
   - **Pages 1+ — `widget_gem_carousel`**: left arrow (`widget_gem_left`) +
     3 stone slots (`widget_gem_slot1/2/3`) + right arrow
     (`widget_gem_right`), same as before. Only stones with count > 0 ever
     appear; a count-2 gem fills 2 slots.
   - `pageCountFor()` is now `1 + ceil(stoneCount / 3)` — the reveal slide
     is always page 0, so page count is never 0 even with zero stones.
   - **Reversed this session**: each stone slot now has its OWN tap target
     (opens `DescriptionActivity` to that specific gem's tab), not one
     shared tap region for the row. The old "gem appearance more important
     than fine-grained tap targets" call was explicitly overridden.
   - `widget_gem_empty_text` **removed** — its job (zero-stones messaging)
     is now just "You have 0 gems!" on the reveal slide, no separate state.
   Arrows only visible/wired if there's more than one page (unchanged
   logic, now counting the reveal slide as page 0). **Refresh button now
   also resets every placed instance back to page 0** (see `TickReceiver`
   below) — a manual refresh always returns to the reveal slide, not
   wherever an instance had been scrolled to.
3. **Bottom row** (`wrap_content`, sticks to bottom): website /
   **share** (new this session, replaces instagram) / refresh icons, equal
   width-weighted thirds. `widget_share` is now an `ImageView`
   (`ic_share.xml`, static single-tone vector, standard 3-node share glyph)
   rather than a unicode-glyph `TextView` like its neighbors — deliberate,
   for higher-fidelity rendering at small size. Tap → `ACTION_SEND` (plain
   text = the website URL) wrapped in `Intent.createChooser`, opening the
   system share sheet. `instagram_url` string and `widget_instagram` id are
   gone — fully removed, not just unwired.
4. **Border overlay** (`widget_border`, full-bleed `ImageView` sibling of
   the root `LinearLayout`): tinted via `setColorFilter` to
   `BorderPrefs.get(context)` — see Settings below. Unchanged this session.

Request codes for arrow/tap `PendingIntent`s are `appWidgetId * 100 +
purpose`: 1/2 = left/right arrow, 3 = reveal-slide tap, 4/5/6 = the 3
individual stone-slot taps (was just 1/2/3 before the per-slot tap change).
Keeps every placed instance's intents distinct — needed now that instances
can be on different pages with different per-slot gems. Global codes 5/6/7
(website/share/refresh) are unaffected — they're literal, not
`appWidgetId`-multiplied, so no collision risk (see prior note on this).

### Interpretation screen (`DescriptionActivity.kt` /
`activity_description.xml`) — restyled to an "ancient game" theme this
session, hero-line wording updated across two sessions
`eventPhraseFor()` in `ZodiacWidgetProvider.kt` (now `internal`, not
`private` — see below) reworded per explicit line-by-line spec:
- Quartz: "at N o'clock" → "for hour N"
- Amethyst: "on Day N" → "for day N" (lowercased "day" this session)
- Topaz: "in {sign}" → "for {sign} Moon"
- Jade: "in {sign}" → "for {sign} Sun"
- Sapphire: "in {month}" → "for {month} month"
- Emerald: "on {month} {day}" → "for the date {day} {month}, {year}"
- Ruby: "in {year}" → "for the year {year}"
- Diamond: "for the {sign} Phase" → "for the {sign} Phase ({startYear}-{endYear})"
  — uses `PlutoPhaseEra.label`. **This session**: `label` now joins the
  years with U+2011 (non-breaking hyphen), not a plain "-" — a plain
  hyphen is a legal Unicode line-break point, which let "(2017-2032)" wrap
  mid-range (e.g. "(201" / "7-2032)") on narrow layouts. Any other code
  that reads `startYear`/`endYear` directly (not through `.label`) is
  unaffected.
**`eventPhraseFor()` visibility changed `private` → `internal` this
session** so `ShareReceiver` (see below) can reuse the exact same phrasing
for the share caption instead of duplicating the `when` block — same
package, but `private` on a Kotlin class member is class-scoped, not
file-scoped, so this widening was necessary, not just tidiness.
Receives 3 Intent extras from `ZodiacWidgetProvider`:
`EXTRA_INITIAL_GEM` (which tab to open first), `EXTRA_LEVELS` (8
comma-joined `LuckLevel` names, `Gem.values()` order), `EXTRA_EVENTS` (8
`"|||"`-joined event phrases, same order).

**Visual theme, this session** — "ancient game" redesign, all via new
drawables, no new Kotlin logic (the 8-tab/hero-line/illustration/
calc-line/body structure and `DescriptionActivity.kt`'s show/hide logic
are byte-for-byte unchanged; only what each already-existing view looks
like changed):
- Screen background: `bg_ancient_stone.xml` (radial dark-stone gradient)
  replacing the flat `@color/dialog_bg`.
- Each of the 8 tabs: gold medallion frame (`bg_tab_medallion.xml`) around
  the count+bar, and the bar itself is now a rounded per-gem pill
  (`bg_tab_bar_{gem}.xml`, 8 new tiny drawables, one per `Gem`) instead of
  a flat rectangle. Selected/unselected is still just alpha, unchanged in
  Kotlin.
- Gem illustration: ornate gold-socket frame (`bg_gem_frame.xml`, a
  3-layer `layer-list` — outer gold ring, dark well, inner hairline).
- Mystical paragraph (`desc_body`): wrapped in a "stone tablet" panel
  (`bg_ancient_panel.xml`, subtle vertical gradient + border) instead of
  floating text.
- Settings link: "rune button" treatment (`bg_rune_button.xml`, a
  bordered pill) instead of bare text.
- **Font**: hero line and `desc_body` now use `@font/cormorant_garamond_semibold`
  — a *downloadable* font via Google's font provider
  (`res/font/cormorant_garamond_semibold.xml`), not a bundled font file
  (no network access in this sandbox to fetch/embed one). Resolves at
  runtime through Google Play Services; on a device without Play Services
  it silently falls back to the platform default rather than crashing —
  this is standard Android downloadable-font behavior, but **genuinely
  unverified in this sandbox** — confirm on a real device that it
  actually resolves to Cormorant Garamond and not the fallback.
  `desc_hero`'s old `textStyle="bold"` was removed since SemiBold is
  already a semibold weight — keeping both would double-bold.

Layout, top to bottom (unchanged from before this session, still applies):
1. **8 fixed tabs, always** — big count number above a color bar. Selected
   = full alpha; unselected = dimmed.
2. **Hero line** (`desc_hero`) — `"You got {count} {gem.countedName(count)} {event phrase}."`
3. **Big gem illustration** (`desc_illustration`), now in its gold-socket frame.
4. **Calculation line** (`desc_calc`) — unchanged.
5. **Mystical paragraph** (`desc_body`) — content/logic unchanged, now in
   the stone-tablet panel with the new font.
6. Settings link — now a rune button.

### Widget border color — removed this session (was redundant)
`BorderPrefs.kt` and its 4-swatch Settings row (gold/silver/blue/brown)
existed for one session, then were flagged as a redundant *second* color
control alongside the background color/texture picker and removed
entirely: `BorderPrefs.kt` deleted, the Settings section removed from both
`activity_settings.xml` and `SettingsActivity.kt`
(`pickedBorderColor`/`borderSwatchIds`/`setUpBorderSwatches()`/the
`BorderPrefs.save()` call all gone), and `colors.xml` now only has
`border_gold` (silver/blue/brown deleted as dead). The widget border is
now just a fixed gold `setColorFilter` tint in `ZodiacWidgetProvider.kt`
— same mechanism, static source instead of a user choice.
Also reworded while investigating this: the exact-alarm status strings
(`exact_alarm_enabled`/`disabled`/`not_needed`) and the battery-optimization
note literally said "color updates"/"delay color updates" — leftover copy
from the pre-gems luck-color system. Now say "updates"/"gem updates."

### Background (`BackgroundPrefs.kt`) — unchanged this session
6 colors × 4 textures, default Brown/Translucent. Not touched.

### Numerology/luck core (`LuckCalculator.kt`, `BookOfLuck.kt`,
`Numerology.kt`) — unchanged this session.

### Share button — now shares an image, not just a link (this session)
The button itself (position, icon) is unchanged; what happens on tap is
new. Old behavior: `PendingIntent.getActivity` straight to
`ACTION_SEND`/plain-text website URL. New behavior, `ShareReceiver.kt`
(new file):
- Widget's `PendingIntent` is now `getBroadcast`, targeting
  `ShareReceiver` explicitly with `ACTION_SHARE` — `exported="false"`,
  same pattern as `TickReceiver`/`CarouselReceiver`, only reachable via
  this app's own PendingIntent.
- **Why a receiver and not a direct share intent**: sharing an *image*
  means something has to draw that image first. A RemoteViews widget
  can't be screenshotted directly — it's inflated and rendered in the
  launcher's process, not this app's — so there's nothing to literally
  capture. `ShareReceiver.renderRevealBitmap()` instead redraws the
  reveal slide's look from scratch onto a standalone `Bitmap` via
  `Canvas`: same card gradient as `bg_celestial_card.xml`, same gold
  border, the 5-facet multicolor gem mark (same coordinates as
  `ic_gem_multicolor.xml`, redrawn as `Path`s since a vector drawable
  resource can't be captured into a `Bitmap` without inflating a whole
  View), the big count, and the wordmark.
- Deliberately uses `Typeface.DEFAULT_BOLD` for the shared image, NOT the
  downloadable Cormorant Garamond font used elsewhere this session —
  resolving a downloadable font synchronously inside a `BroadcastReceiver`
  risks a blocking network fetch on first use, which isn't a safe thing to
  do in a component that's supposed to return quickly. Worth revisiting if
  visual consistency with the interpretation screen's font matters more
  than that risk.
- Image is written to `context.cacheDir/shared/reveal_share.png`, exposed
  via a new `FileProvider` (`res/xml/file_paths.xml` scopes it to just
  that one cache subfolder — nothing else in app storage is exposed).
  `AndroidManifest.xml` gained the `<provider>` entry (authority
  `${applicationId}.fileprovider`, `exported="false"`,
  `grantUriPermissions="true"`) and the `<receiver>` entry for
  `ShareReceiver`.
- Caption text (`ACTION_SEND`'s `EXTRA_TEXT`, alongside the image in
  `EXTRA_STREAM`): `"I have {N} gems on {date} at {time}!"`, then one line
  per gem type with count > 0 — `"{count} {lowercased counted name} {event phrase, unchanged case}"`,
  reusing `ZodiacWidgetProvider.eventPhraseFor()` directly so the wording
  matches the interpretation screen exactly. **Only the gem name is
  lowercased**, not the event phrase — per the literal spec given
  ("XX quartz for hour 1", "XX amethysts for day 21"), which only showed
  the noun lowercased; proper nouns inside the event phrase (e.g. "Leo
  Sun", "August") are left capitalized. Blank line, then app name, then
  website URL. **Gems with count 0 are omitted** — a shareable brag post
  listing what you didn't get would read oddly; this wasn't explicitly
  specified either way, so treat it as a judgment call worth confirming if
  it doesn't match what was wanted.
- `FileProvider` comes from `androidx.core:core-ktx` (already a project
  dependency, transitively includes `androidx.core:core`) — no new Gradle
  dependency needed.

### Reveal slide animation (this session)
`android:animateLayoutChanges="true"` added to the page-swap `FrameLayout`
(the one containing `widget_gem_reveal`/`widget_gem_slots_row`). This is
the one genuine animation mechanism available inside RemoteViews — custom
`Animator`/`ObjectAnimator` code can't run here since this view tree is
hosted in the launcher's process, not the app's. The flag makes the host
itself fade/animate the `VISIBLE`↔`GONE` transition automatically,
firing whenever `applyCarousel()` changes which page is showing —
including refresh resetting back to page 0.

### Settings (`SettingsActivity.kt` / `activity_settings.xml`)
Field order: Gender → Birth date → Birth time → Time zone → Widget
background color swatches → texture chips → permission
statuses/shortcuts. (Border-color swatches removed this session — see
above.)

### Permissions & security (all reviewed multiple times this session,
current final set)
- `SCHEDULE_EXACT_ALARM`, `RECEIVE_BOOT_COMPLETED`,
  `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS`. No `INTERNET`. `allowBackup=
  "false"`. Unchanged this session.
- **Exported-receiver fix** (see lesson 9): `TickReceiver`,
  `CarouselReceiver`, and now `ShareReceiver` are all dedicated,
  `exported="false"` receivers, each only reachable via this app's own
  explicit `PendingIntent`. The three widget-provider receivers and
  `BootReceiver` are the only `exported="true"` components, both for
  reasons the OS requires and neither exploitable beyond that requirement.
  `DescriptionActivity`/`SettingsActivity` stay `exported="false"`. The
  new `FileProvider` is also `exported="false"` — reachable only via an
  explicit content-Uri grant (`FLAG_GRANT_READ_URI_PERMISSION`), not by
  any app that simply knows the authority string.
- Every `PendingIntent` in the codebase uses `FLAG_IMMUTABLE` — including
  the Share button's new `getBroadcast` PendingIntent.
- The downloadable-font mechanism (`cormorant_garamond_semibold.xml`) does
  involve a network fetch (via Google Play Services, not code this app
  writes or controls directly) — worth being aware of as the one place in
  this app where something resembling "network access" happens, even
  though there's still no `INTERNET` permission declared or needed (Play
  Services handles its own networking under its own permission grant).
- No hardcoded secrets anywhere (checked via grep each audit).
- No memory-leak patterns found in any audit this session: no static
  `Context`/`View` references, no dynamically-registered receivers left
  unregistered. `ShareReceiver`'s `Bitmap`/`Canvas` objects are local to
  `onReceive()`, not retained anywhere after the method returns.

### Build process
- No Gradle wrapper jar bundled — `.github/workflows/build.yml` installs
  Gradle directly via `gradle/actions/setup-gradle@v4`.
- The workflow file is **not** included when zipping — `rm -rf .github`
  from the copy before zipping, always.
- minSdk 24, compileSdk/targetSdk 34, Kotlin 1.9.24, AGP 8.5.2.
- `applicationId = "com.lifeprediction.widget.gems"`.
- **R8/ProGuard minification enabled for release builds**
  (`isMinifyEnabled = true`, `isShrinkResources = true`). `proguard-rules.pro`
  explicitly keeps all manifest-declared components and the enum
  `values()`/`valueOf()` methods `Gem`/`LuckLevel`/`BgColor`/`BgTexture`
  need for their Intent-extra/SharedPreferences round-trips. **`BorderColor`
  was removed from this list when the enum itself was deleted this
  session — verified via grep, `proguard-rules.pro` has no leftover
  reference.** **This only affects release builds** — confirm what variant
  the Actions workflow actually builds before assuming this is exercised.

## Known-good verification routine (run after every change, before zipping)

```bash
# XML validity for anything touched
python3 -c "import xml.etree.ElementTree as ET; ET.parse('PATH'); print('valid')"

# ID parity across ALL FOUR widget layout files (must all be identical)
grep -o 'android:id="@+id/[a-zA-Z0-9_]*"' layout/widget_zodiac.xml | sort -u > /tmp/p.txt
grep -o 'android:id="@+id/[a-zA-Z0-9_]*"' layout-land/widget_zodiac.xml | sort -u > /tmp/l.txt
grep -o 'android:id="@+id/[a-zA-Z0-9_]*"' layout/widget_zodiac_tall.xml | sort -u > /tmp/t1.txt
grep -o 'android:id="@+id/[a-zA-Z0-9_]*"' layout-land/widget_zodiac_tall.xml | sort -u > /tmp/t2.txt
diff /tmp/p.txt /tmp/l.txt && diff /tmp/p.txt /tmp/t1.txt && diff /tmp/t1.txt /tmp/t2.txt && echo "IDENTICAL - OK"
# NOTE: use [a-zA-Z0-9_] (with digits!) — widget_gem_slot1/2/3 etc. need the
# digit class or the check silently misses them.

# DescriptionActivity <-> activity_description.xml id cross-check
grep -o 'android:id="@+id/[a-zA-Z0-9_]*"' layout/activity_description.xml | sed 's/android:id="@+id\///;s/"//' | sort -u > /tmp/layout_ids.txt
grep -o "R\.id\.[a-zA-Z0-9_]*" java/com/lifeprediction/widget/DescriptionActivity.kt | sed 's/R\.id\.//' | sort -u > /tmp/kotlin_ids.txt
comm -13 /tmp/layout_ids.txt /tmp/kotlin_ids.txt   # anything here but "content" = will crash

# Kotlin brace/paren balance (no real compiler available in this sandbox)
for f in java/com/lifeprediction/widget/*.kt; do
  python3 -c "s=open('$f').read(); b=s.count('{')-s.count('}'); p=s.count('(')-s.count(')'); print('$f', b, p) if b or p else None"
done
# Note: comments with unbalanced parens in prose (e.g. "(see X)") are
# harmless false positives — check the actual line before assuming a bug.

# Sweep for dead resources/functions
for c in $(grep -o 'name="[a-zA-Z_]*"' res/values/colors.xml | sed 's/name="//;s/"//'); do
  grep -rl "@color/$c\b\|R\.color\.$c\b" res/ java/ 2>/dev/null | grep -v colors.xml >/dev/null || echo "UNUSED color: $c"
done
# same pattern for dimens/strings/drawables, and for `fun NAME` across all .kt files
```

## Packaging routine

```bash
rm -rf /home/claude/work/pkg/*
cp -r /home/claude/work/proj/LifePredictionWidget /home/claude/work/pkg/
rm -rf /home/claude/work/pkg/LifePredictionWidget/.github   # not part of the zip
cd /home/claude/work/pkg
zip -r -q /mnt/user-data/outputs/LifePredictionWidget.zip LifePredictionWidget -x "*.DS_Store"
```
Then `present_files` on the zip.

## Status as of end of this session

**Delivered, in order, this session** (see "Widget face" and
"Interpretation screen" sections above for full detail):
1. Clock: dropped weekday + AM/PM, kept 12-hour digits (`M/d, h:mm` on both
   `format12Hour`/`format24Hour`) — explicit "am/pm format without am/pm."
2. New gem-count pill in the top row (owned stone count, Diamond icon then
   number), between the clock and the existing Total Value pill.
3. New carousel page 0: "You have XX gems!" reveal slide — big count,
   Diamond icon, app-name footer for shareability, opens
   `DescriptionActivity` on tap. Replaces the old `widget_gem_empty_text`
   fallback entirely (zero-stones case is now just "You have 0 gems!").
4. Each of the 3 stone slots now has its own tap target (reversing the
   earlier "one shared tap region for the row" design call).
5. Instagram → Share: `widget_instagram` removed, `widget_share`
   (`ic_share.xml`, static vector) added, wired to `ACTION_SEND` sharing
   the plain website URL via the system share sheet.
6. Hero-line copy reworded for Amethyst/Topaz/Jade/Sapphire/Emerald/Ruby
   per an explicit 7-line spec (Diamond unchanged).

**Follow-up fixes, same session:**
7. **Bug fix**: reveal-slide count rendering outside the widget bounds —
   root cause was a `wrap_content`-width row defeating `autoSizeText`'s
   ability to shrink (see "Widget face" section above for the full
   explanation). Fixed by constraining that row to `match_parent`.
8. Reveal slide redesigned again, simplified to 2 lines: small
   multicolored gem mark (`ic_gem_multicolor.xml`, new this session) + big
   count, then the app wordmark — replacing the earlier 4-line "You have /
   N / gems! / divider / app name" version.
9. Refresh button now resets every placed instance's carousel page back to
   0 (`CarouselPrefs.resetAll()`, called from `TickReceiver` only on a
   manual tap, not the silent scheduled tick).
10. Quartz hero-line wording: "at N o'clock" → "for hour N".

**Second follow-up, same session**: the wordmark line ("Pluto Phases
Gems") on the reveal slide was overflowing on 1x1 specifically — it had no
autosize at all (just a fixed size sized for the shared 1x1/2x1 file's
more generous 2x1 case). Added `autoSizeTextType="uniform"` (floor 4sp)
and lowered the per-file ceiling substantially (9/8/8/7sp → 7/6/6/5sp).

**Third follow-up, same session**: Diamond's hero line now reads "for the
Virgo Phase (2017-2032)" instead of just "for the Virgo Phase" — switched
to `PlutoPhaseEra.label`, an existing property that already built this
exact string, just not previously wired into `eventPhraseFor()`.

**Fourth follow-up, same session**: reveal slide still overflowing on
narrow widths after the two text-autosize fixes above — the actual
remaining cause was the icon's fixed (non-adaptive) size eating most of
the already-tight 1x1 content column, compounded by the count text's
autoSize floor (12sp) being too high to compensate. Shrunk the icon per
file (22/20/18/18dp → 16/16/14/14dp) and lowered the count floor to a
uniform 7sp. This is the fix that should make the slide actually *adapt*
to width rather than just being correctly-bounded-but-still-oversized.

All 4 widget layout files regenerated from one Python template this
session (per-file sizing scaled proportionally from each file's existing
values, not guessed) to guarantee ID parity and reduce copy-paste risk
across 4 near-identical files. Known-good verification routine (XML
validity, ID parity, DescriptionActivity cross-check, brace/paren balance,
dead-resource sweep) run clean — two pre-existing findings
(`EphemerisRepository.kt` paren "imbalance", unused `ic_launcher_gems`
drawable) are both untouched-by-this-session false positives: the former
is a comment-in-prose parenthesis (per the routine's own noted caveat),
the latter is referenced from `AndroidManifest.xml`, outside the sweep's
res/+java scope.

---

## Fifth round, same overall thread (large multi-part request) — this is
## the most recent work; read this section first if picking this back up

Six requests handled in one batch, in order:

1. **Removed redundant Settings color control** — the Border Color
   4-swatch picker (added earlier this session) was flagged as a
   redundant *second* color control alongside the background
   color/texture picker, and removed entirely: `BorderPrefs.kt` deleted,
   its Settings UI section removed, border is now a fixed gold tint. Also
   found and fixed a more literal match for the same complaint — the
   exact-alarm/battery-optimization strings literally said "color
   updates," leftover copy from the pre-gems system. See "Widget border
   color — removed this session" above for the full list of touched files.
2. **Fixed `(2017-2032)` wrapping onto two lines** — `PlutoPhaseEra.label`
   now joins the years with a non-breaking hyphen (U+2011) instead of a
   plain "-", which is a legal Unicode line-break point.
3. **Lowercased "day"** in the Amethyst hero line ("for Day N" → "for day N").
4. **Animated the reveal slide** — `animateLayoutChanges="true"` on the
   page-swap container, the one real animation mechanism RemoteViews
   supports without custom code.
5. **Cormorant Garamond SemiBold + "ancient game" theme** on the
   interpretation screen — see "Interpretation screen" section above for
   the full list of new drawables (`bg_tab_medallion`, `bg_tab_bar_{gem}`
   ×8, `bg_gem_frame`, `bg_ancient_panel`, `bg_ancient_stone`,
   `bg_rune_button`) and the new `res/font/cormorant_garamond_semibold.xml`
   downloadable-font declaration. **This is the single least-verified
   piece of this whole round** — no way to confirm in this sandbox that
   the downloadable font actually resolves at runtime rather than silently
   falling back to the platform default.
6. **Share button now shares an image + multi-line caption**, not just a
   link — the biggest structural change of the six. New `ShareReceiver.kt`
   draws a standalone `Bitmap` recreating the reveal slide's look (Canvas,
   not a screenshot — RemoteViews can't be captured directly), saves it to
   cache, exposes it via a new `FileProvider`, and launches
   `ACTION_SEND` with both `EXTRA_STREAM` (the image) and `EXTRA_TEXT` (the
   caption). Caption format verified line-by-line against the two example
   lines given ("1 quartz for hour 3", "2 amethysts for day 21") — see
   "Share button" section above for the exact caption-building logic and
   the judgment calls made where the spec was ambiguous (count-0 gems
   omitted from the caption; only the gem *name* lowercased, not the whole
   event phrase).

New files this round: `ShareReceiver.kt`, `res/xml/file_paths.xml`,
`res/font/cormorant_garamond_semibold.xml`, `bg_tab_medallion.xml`,
`bg_tab_bar_{quartz,amethyst,topaz,jade,sapphire,emerald,ruby,diamond}.xml`
(8 files), `bg_gem_frame.xml`, `bg_ancient_panel.xml`,
`bg_ancient_stone.xml`, `bg_rune_button.xml`. Deleted: `BorderPrefs.kt`.
Manifest gained: the `ShareReceiver` receiver, the `FileProvider`
provider. `eventPhraseFor()` in `ZodiacWidgetProvider.kt` changed from
`private` to `internal` so `ShareReceiver` can call it directly.

Full verification routine (XML validity on every touched file, ID parity
across code widget layouts, `activity_settings.xml`/`SettingsActivity.kt`
cross-check, `activity_description.xml`/`DescriptionActivity.kt`
cross-check, Kotlin brace/paren balance, dead-resource sweep for strings/
colors/drawables) run clean after this round — including confirming
`proguard-rules.pro` has no leftover `BorderColor` reference after that
enum's deletion.



**Not yet confirmed to build clean on a fresh GitHub Actions run** — only
static checks were possible in this sandbox. Priority items to watch for
in the next reported build/test, newest first:

- **Does the downloadable Cormorant Garamond font actually resolve?**
  Highest-priority unverified item from this round. If it silently falls
  back to the platform default (e.g. no Google Play Services on the test
  device, or the font-provider query string is subtly wrong), the
  interpretation screen will look like plain sans-serif with no error or
  crash — worth deliberately checking, not just noticing if something
  looks off.
- **Does the Share button's image + caption actually work end to end?**
  Specifically: does the `FileProvider` Uri resolve and grant correctly
  across different share-target apps (Messages, WhatsApp, Instagram, ...),
  does the Canvas-drawn bitmap actually look good at real size (only
  reasoned about pixel math here, never rendered), and does the caption
  text look right in a real share sheet preview.
- Does the "ancient game" restyle (gold medallions, stone-tablet panel,
  gem-socket frame) actually look cohesive together on a real screen,
  versus reasoned about individually? This was mocked up as a preview
  before building, but the mockup and the actual RemoteViews-free (this is
  a normal Activity, no RemoteViews constraint here) Android rendering
  could differ in ways a flat SVG preview wouldn't catch (font metrics,
  actual gradient rendering, real touch-target sizing).
- Does the reveal slide (page 0) actually fit and read well on the
  smallest widget size (1x1)? Multiple rounds of fixes this session
  (match_parent-width, autosize floors, icon shrinking) should have
  resolved the reported overflow — but still the first place to check on
  a real device before assuming it's fully settled.
- Does the vertical-`layout_weight` gem carousel/reveal region actually
  fill the space correctly on the person's real launcher (carried over
  open question from early in this session)?
- Per-slot tap targets on the stone pages, and multiple placed widget
  instances scrolling independently — both still untested on a real
  device (carried over from before).

## Explicitly discussed, explicitly NOT to be built
(per the person's own instruction from an earlier session: "Ignore the new
ideas" — still applies unless raised again)

A separate line of discussion happened in an earlier session about turning
this into a **personalized product handed out to customers** (12 Gradle
product flavors per zodiac sign, Firebase/Play Console distribution, a
"mysterious, unexplained calculation" copy tone, a crypto-paying app
store). None of this was implemented and none of it should be treated as
in-progress. If the person wants to pick this back up, they'll say so.

Also asked about and explicitly declined: hiding the calculation logic from
decompilation beyond standard R8 minification (encrypted data tables,
native/NDK code, server-side computation) — discussed as options, only the
standard R8 minification step was actually implemented.
