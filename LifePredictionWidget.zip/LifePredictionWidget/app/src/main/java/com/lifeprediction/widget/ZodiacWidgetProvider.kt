package com.lifeprediction.widget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.widget.RemoteViews
import java.time.LocalDateTime
import java.time.ZoneId

/**
 * Colors are refreshed at the *exact second* they should change, not on a
 * fixed timer: every wake-up computes the earliest of (a) the next top-of-hour
 * (covers the Time box, and Date/Day/Month/Year at midnight since midnight is
 * also an hour boundary), (b) the next Sun-sign crossing, and (c) the next
 * Moon-sign crossing — then schedules a single exact alarm for whichever is
 * soonest, and repeats. Each wake is a handful of milliseconds of work, and
 * there are at most a few dozen of these a day (an hourly one, plus the rare
 * Sun/Moon sign changes), so this stays cheap even though it's precise.
 */
class ZodiacWidgetProvider : AppWidgetProvider() {

    companion object {
        const val ACTION_TICK = "com.lifeprediction.widget.ACTION_TICK"

        private fun colorFor(level: LuckLevel, context: Context): Int = when (level) {
            LuckLevel.LUCKY -> context.getColor(R.color.luck_lucky)
            LuckLevel.UNLUCKY -> context.getColor(R.color.luck_unlucky)
            LuckLevel.AVERAGE -> context.getColor(R.color.luck_average)
        }

        fun buildRemoteViews(context: Context): RemoteViews {
            val views = RemoteViews(context.packageName, R.layout.widget_zodiac)
            val snapshot = LuckCalculator.buildSnapshot(context)

            // TIME — its own colored box (by hour's verdict)
            views.setInt(R.id.widget_time_bg, "setColorFilter", colorFor(snapshot.timeLevel, context))

            // SUN box
            views.setTextViewText(
                R.id.widget_sun_text,
                "\u2600 " + symbolFor(snapshot.transitingSunSign)
            )
            views.setInt(R.id.widget_sun_bg, "setColorFilter", colorFor(snapshot.sunLevel, context))

            // MOON box
            views.setTextViewText(
                R.id.widget_moon_text,
                "\uD83C\uDF19 " + symbolFor(snapshot.transitingMoonSign)
            )
            views.setInt(R.id.widget_moon_bg, "setColorFilter", colorFor(snapshot.moonLevel, context))

            // DATE box + day/month/year text, each colored per its own reduced digit
            views.setInt(R.id.widget_date_bg, "setColorFilter", colorFor(snapshot.dateLevel, context))
            views.setTextViewText(R.id.widget_date_day, snapshot.date.dayOfMonth.toString())
            views.setTextColor(R.id.widget_date_day, colorFor(snapshot.dayLevel, context))
            views.setTextViewText(R.id.widget_date_month, snapshot.date.month.name.take(3))
            views.setTextColor(R.id.widget_date_month, colorFor(snapshot.monthLevel, context))
            views.setTextViewText(R.id.widget_date_year, snapshot.date.year.toString())
            views.setTextColor(R.id.widget_date_year, colorFor(snapshot.yearLevel, context))

            // Click targets -> description popups
            views.setOnClickPendingIntent(R.id.widget_time_box, descriptionIntent(context, Section.TIME, snapshot.timeLevel, 1))
            views.setOnClickPendingIntent(R.id.widget_sun_box, descriptionIntent(context, Section.SUN, snapshot.sunLevel, 2))
            views.setOnClickPendingIntent(R.id.widget_moon_box, descriptionIntent(context, Section.MOON, snapshot.moonLevel, 3))
            views.setOnClickPendingIntent(R.id.widget_date_box, descriptionIntent(context, Section.DATE, snapshot.dateLevel, 4))

            // Website -> opens the browser (no INTERNET permission needed here;
            // the browser app does the actual network fetch, not us)
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse(context.getString(R.string.website_url)))
            val webPending = PendingIntent.getActivity(
                context, 5, webIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_website, webPending)

            return views
        }

        private fun descriptionIntent(context: Context, section: Section, level: LuckLevel, requestCode: Int): PendingIntent {
            val intent = Intent(context, DescriptionActivity::class.java).apply {
                putExtra(DescriptionActivity.EXTRA_SECTION, section.name)
                putExtra(DescriptionActivity.EXTRA_LEVEL, level.name)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            return PendingIntent.getActivity(
                context, requestCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        /** Rebuilds and pushes fresh RemoteViews to every placed instance of this widget. */
        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, ZodiacWidgetProvider::class.java))
            if (ids.isEmpty()) return
            val views = buildRemoteViews(context)
            manager.updateAppWidget(ids, views)
        }

        /**
         * Schedules a single exact alarm for the earliest moment any displayed
         * color would actually change: the next top-of-hour, or (if sooner) the
         * exact instant the Sun or Moon crosses into a new sign today.
         */
        fun scheduleNextTick(context: Context) {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return

            val nowUtc = LocalDateTime.now(ZoneId.of("UTC"))
            val nextHour = nowUtc.withMinute(0).withSecond(0).withNano(0).plusHours(1)
            val sunCrossing = EphemerisRepository.nextSignCrossing(context, nowUtc) { it.sunDegrees }
            val moonCrossing = EphemerisRepository.nextSignCrossing(context, nowUtc) { it.moonDegrees }

            val nextWakeUtc = listOfNotNull(nextHour, sunCrossing, moonCrossing).min()
            val triggerAt = nextWakeUtc.atZone(ZoneId.of("UTC")).toInstant().toEpochMilli()

            val intent = Intent(context, ZodiacWidgetProvider::class.java).apply { action = ACTION_TICK }
            val pending = PendingIntent.getBroadcast(
                context, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val canScheduleExact = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                alarmManager.canScheduleExactAlarms()
            } else {
                true
            }

            if (canScheduleExact) {
                runCatching {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC, triggerAt, pending)
                }.onFailure {
                    alarmManager.set(AlarmManager.RTC, triggerAt, pending)
                }
            } else {
                // User hasn't granted the "Alarms & reminders" special access on
                // Android 13+. Fall back to an inexact wake — the widget still
                // refreshes, just without to-the-second precision, and it'll
                // catch up fully once the permission is granted (SettingsActivity
                // offers a shortcut to do that).
                alarmManager.set(AlarmManager.RTC, triggerAt, pending)
            }
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val views = buildRemoteViews(context)
        appWidgetIds.forEach { id -> appWidgetManager.updateAppWidget(id, views) }
        scheduleNextTick(context)
    }

    override fun onEnabled(context: Context) {
        scheduleNextTick(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_TICK) {
            updateAll(context)
            scheduleNextTick(context)
        }
    }
}
