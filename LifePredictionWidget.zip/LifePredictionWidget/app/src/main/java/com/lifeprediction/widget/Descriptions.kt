package com.lifeprediction.widget

enum class Section { TIME, DATE, SUN, MOON }

object Descriptions {

    fun title(section: Section): String = when (section) {
        Section.TIME -> "This hour"
        Section.DATE -> "Today"
        Section.SUN -> "Sun sign"
        Section.MOON -> "Moon sign"
    }

    fun text(section: Section, level: LuckLevel): String = when (section) {
        Section.DATE -> when (level) {
            LuckLevel.LUCKY -> "Today supports steady career and financial progress. It's the time to increase income, finalize agreements, or move forward with projects that have clear value."
            LuckLevel.AVERAGE -> "Today carries strong energy for action, communication, and ideas, which can express through creativity, collaboration or confrontation depending on caution and restraint."
            LuckLevel.UNLUCKY -> "This day favors caution, privacy, and consolidation rather than outward progress. Be wary of bad luck, deception and manage emotional turmoil."
        }
        Section.TIME -> when (level) {
            LuckLevel.LUCKY -> "This hour favors decisive action. Calls, meetings, and requests started now tend to land well, so use it to move something concrete forward."
            LuckLevel.AVERAGE -> "This hour is changeable — quick wins and small friction can both show up. Stay flexible and keep decisions reversible until the picture clears."
            LuckLevel.UNLUCKY -> "This hour is prone to misread signals and short tempers. Postpone anything that needs a clear head or a firm commitment if you can."
        }
        Section.SUN -> when (level) {
            LuckLevel.LUCKY -> "The Sun favors your vitality and visibility right now. Confidence, leadership, and being seen work in your favor — step forward rather than wait."
            LuckLevel.AVERAGE -> "The Sun's influence is mixed today. Your energy and drive are real but need direction, so channel ambition into one clear goal instead of several."
            LuckLevel.UNLUCKY -> "The Sun sits awkwardly for you today. Ego and pride can get in the way — lead with humility and avoid picking fights over recognition."
        }
        Section.MOON -> when (level) {
            LuckLevel.LUCKY -> "The Moon supports your emotional life and instincts. Home, family, and close relationships are favored — trust your gut on personal matters."
            LuckLevel.AVERAGE -> "The Moon brings shifting moods today. Feelings run a little stronger than usual, so give yourself room before reacting to them."
            LuckLevel.UNLUCKY -> "The Moon is unsettled for you today. Old worries and insecurities can resurface — protect your rest and avoid heavy emotional decisions."
        }
    }
}
