package com.lifeprediction.widget

import android.content.Context

/**
 * The widget's card background is no longer configurable — it's always the
 * fixed celestial gradient declared directly in the layout (bg_celestial_card).
 * The only remaining user choice is the border color, picked directly from
 * these 6 swatches (replacing the old auto-tint-by-luck-level border, and the
 * old 6-color x 4-texture background picker entirely).
 */
enum class BorderColor(val label: String, val hex: String) {
    NAVY("Navy", "#1B1340"),
    BLUE("Blue", "#123A5E"),
    CHARCOAL("Charcoal", "#1A1A1A"),
    FOREST("Forest", "#10231A"),
    BURGUNDY("Burgundy", "#33121C"),
    BROWN("Brown", "#2B1B12")
}

object BorderPrefs {
    private const val PREFS = "border_prefs"
    private const val KEY_COLOR = "border_color"

    private val DEFAULT = BorderColor.BROWN

    fun get(context: Context): BorderColor {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return runCatching { BorderColor.valueOf(prefs.getString(KEY_COLOR, null) ?: "") }
            .getOrDefault(DEFAULT)
    }

    fun save(context: Context, color: BorderColor) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_COLOR, color.name)
            .apply()
    }
}
