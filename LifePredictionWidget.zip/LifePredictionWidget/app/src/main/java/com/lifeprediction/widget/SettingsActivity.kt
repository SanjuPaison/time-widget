package com.lifeprediction.widget

import android.app.AlarmManager
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

class SettingsActivity : AppCompatActivity() {

    private var pickedDate: LocalDate = LocalDate.of(1990, 1, 1)
    private var pickedTime: LocalTime = LocalTime.of(12, 0)
    private var pickedZoneId: String = ZoneId.systemDefault().id
    private var pickedBorderColor: BorderColor = BorderColor.GOLD

    private val dateFormat = DateTimeFormatter.ofPattern("d MMMM yyyy")
    private val timeFormat = DateTimeFormatter.ofPattern("h:mm a")

    // Sorted once; used for the time-zone picker list.
    private val allZoneIds: List<String> by lazy { ZoneId.getAvailableZoneIds().sorted() }

    // id -> BorderColor for the 4 border swatches.
    private val borderSwatchIds = mapOf(
        R.id.settings_border_gold to BorderColor.GOLD,
        R.id.settings_border_silver to BorderColor.SILVER,
        R.id.settings_border_blue to BorderColor.BLUE,
        R.id.settings_border_green to BorderColor.GREEN
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val current = BirthPrefs.get(this)
        pickedDate = current.date
        pickedTime = current.time
        pickedZoneId = current.zoneId

        pickedBorderColor = BorderPrefs.get(this)

        val dateView = findViewById<TextView>(R.id.settings_date_value)
        val timeView = findViewById<TextView>(R.id.settings_time_value)
        val timezoneView = findViewById<TextView>(R.id.settings_timezone_value)

        dateView.text = pickedDate.format(dateFormat)
        timeView.text = pickedTime.format(timeFormat)
        timezoneView.text = zoneLabel(pickedZoneId)

        val genderGroup = findViewById<RadioGroup>(R.id.settings_gender_group)
        val maleRadio = findViewById<RadioButton>(R.id.settings_gender_male)
        val femaleRadio = findViewById<RadioButton>(R.id.settings_gender_female)
        if (current.gender == Gender.FEMALE) femaleRadio.isChecked = true else maleRadio.isChecked = true

        dateView.setOnClickListener {
            DatePickerDialog(
                this,
                { _, year, month, dayOfMonth ->
                    pickedDate = LocalDate.of(year, month + 1, dayOfMonth)
                    dateView.text = pickedDate.format(dateFormat)
                },
                pickedDate.year, pickedDate.monthValue - 1, pickedDate.dayOfMonth
            ).show()
        }

        timeView.setOnClickListener {
            TimePickerDialog(
                this,
                { _, hourOfDay, minute ->
                    pickedTime = LocalTime.of(hourOfDay, minute)
                    timeView.text = pickedTime.format(timeFormat)
                },
                pickedTime.hour, pickedTime.minute, false
            ).show()
        }

        timezoneView.setOnClickListener {
            val labels = allZoneIds.map { zoneLabel(it) }.toTypedArray()
            val preselect = allZoneIds.indexOf(pickedZoneId).coerceAtLeast(0)
            AlertDialog.Builder(this)
                .setTitle(R.string.birth_timezone_label)
                .setSingleChoiceItems(labels, preselect) { dialog, which ->
                    pickedZoneId = allZoneIds[which]
                    timezoneView.text = zoneLabel(pickedZoneId)
                    dialog.dismiss()
                }
                .show()
        }

        setUpBorderSwatches()

        findViewById<TextView>(R.id.settings_save).setOnClickListener {
            val gender = if (genderGroup.checkedRadioButtonId == R.id.settings_gender_female) Gender.FEMALE else Gender.MALE
            BirthPrefs.save(
                this,
                BirthData(
                    date = pickedDate,
                    time = pickedTime,
                    zoneId = pickedZoneId,
                    gender = gender
                )
            )
            BorderPrefs.save(this, pickedBorderColor)
            ZodiacWidgetProvider.updateAll(this)
            ZodiacWidgetProvider.scheduleNextTick(this)
            finish()
        }

        setUpExactAlarmStatus()
        setUpBatteryStatus()
    }

    override fun onResume() {
        super.onResume()
        // Refresh in case the user just came back from a system settings screen.
        setUpExactAlarmStatus()
        setUpBatteryStatus()
    }

    /** Shows a checkmark on whichever border color swatch is currently selected. */
    private fun setUpBorderSwatches() {
        fun refresh() {
            for ((id, color) in borderSwatchIds) {
                findViewById<TextView>(id).text = if (color == pickedBorderColor) "✓" else ""
            }
        }
        for ((id, color) in borderSwatchIds) {
            findViewById<TextView>(id).setOnClickListener {
                pickedBorderColor = color
                refresh()
            }
        }
        refresh()
    }

    private fun setUpExactAlarmStatus() {
        val statusView = findViewById<TextView>(R.id.settings_exact_alarm_status)
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            // Pre-Android 12, SCHEDULE_EXACT_ALARM works from the manifest
            // declaration alone — no runtime toggle needed.
            statusView.text = getString(R.string.exact_alarm_not_needed)
            statusView.setOnClickListener(null)
            return
        }
        val alarmManager = getSystemService(AlarmManager::class.java)
        if (alarmManager?.canScheduleExactAlarms() == true) {
            statusView.text = getString(R.string.exact_alarm_enabled)
            statusView.setOnClickListener(null)
        } else {
            statusView.text = getString(R.string.exact_alarm_disabled)
            statusView.setOnClickListener {
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
            }
        }
    }

    private fun zoneLabel(id: String): String {
        val offset = runCatching {
            ZoneId.of(id).rules.getOffset(java.time.Instant.now()).id.replace("Z", "+00:00")
        }.getOrDefault("")
        return if (offset.isNotEmpty()) "$id (UTC$offset)" else id
    }

    private fun setUpBatteryStatus() {
        val statusView = findViewById<TextView>(R.id.settings_battery_status)
        val powerManager = getSystemService(Context.POWER_SERVICE) as? PowerManager
        val isExempt = powerManager?.isIgnoringBatteryOptimizations(packageName) == true
        if (isExempt) {
            statusView.text = getString(R.string.battery_optimized_off)
            statusView.setOnClickListener(null)
        } else {
            statusView.text = getString(R.string.battery_optimized_on)
            statusView.setOnClickListener {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            }
        }
    }
}
